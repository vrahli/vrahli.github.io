Compilation
===========

The code compiles with Coq version 8.5pl2 & 8.6.1.  To compile the
code, first generate a Makefile by running `./create-makefile.sh`.
Then type `make -j X`, where X is the number of jobs you want to use.



Roadmap
=======

The model is in `model` and our formalization of PBFT is in `PBFT`.



Running
=======

To run PBFT, check out `runtime/README.md`.
