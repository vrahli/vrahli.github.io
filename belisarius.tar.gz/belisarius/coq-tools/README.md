Some useful Coq stuff
