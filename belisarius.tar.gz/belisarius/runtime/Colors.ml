let kNRM = "\x1B[0m"

(* default background & different foreground colors *)
let kRED = "\x1B[49m\x1B[31m"
let kGRN = "\x1B[49m\x1B[32m"
let kYEL = "\x1B[49m\x1B[33m"
let kBLU = "\x1B[49m\x1B[34m"
let kMAG = "\x1B[49m\x1B[35m"
let kCYN = "\x1B[49m\x1B[36m"
let kWHT = "\x1B[49m\x1B[37m"

(* default background & different (light) foreground colors *)
let kLRED = "\x1B[49m\x1B[91m"
let kLGRN = "\x1B[49m\x1B[92m"
let kLYEL = "\x1B[49m\x1B[93m"
let kLBLU = "\x1B[49m\x1B[94m"
let kLMAG = "\x1B[49m\x1B[95m"
let kLCYN = "\x1B[49m\x1B[96m"
let kLWHT = "\x1B[49m\x1B[97m"

(* diferent background colors & white foreground *)
let kBRED = "\x1B[41m\x1B[37m"
let kBGRN = "\x1B[42m\x1B[37m"
let kBYEL = "\x1B[43m\x1B[37m"
let kBBLU = "\x1B[44m\x1B[37m"
let kBMAG = "\x1B[45m\x1B[37m"
let kBCYN = "\x1B[46m\x1B[37m"
let kBWHT = "\x1B[47m\x1B[30m"
