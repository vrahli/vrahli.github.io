open Prelude;;
open PbftReplica;;
open Core;;
open Async;;


(* =====================================================

   We redefine the message type so that we can annotate
   each part with bin_io stuff, to derive the marshaling
   stuff required by rpc_parallel.

   ===================================================== *)


exception TODO of string;;


type i_operation =
| I_Opr_add of int
| I_Opr_sub of int [@@deriving bin_io]

type i_timestamp = int [@@deriving bin_io]
type i_client    = int [@@deriving bin_io]
type i_rep       = int [@@deriving bin_io]
type i_view      = int [@@deriving bin_io]
type i_result    = int [@@deriving bin_io]
type i_seq_num   = int [@@deriving bin_io]

type i_digest = int list [@@deriving bin_io]

(* TODO: it would be better if we could use Cstruct.t here!! *)
type i_token = string [@@deriving bin_io]
type i_tokens = i_token list [@@deriving bin_io]

type i_check_bcast_new_view = int [@@deriving bin_io]

type i_bare_request =
| I_null_req
| I_bare_req of i_operation * i_timestamp * i_client [@@deriving bin_io]

type i_bare_reply =
| I_bare_reply of i_view * i_timestamp * i_client * i_rep * i_result [@@deriving bin_io]

type i_bare_prepare =
| I_bare_prepare of i_view * i_seq_num * i_digest * i_rep [@@deriving bin_io]

type i_bare_commit =
| I_bare_commit of i_view * i_seq_num * i_digest * i_rep [@@deriving bin_io]

type i_bare_checkpoint =
| I_bare_checkpoint of i_view * i_seq_num * i_digest * i_rep [@@deriving bin_io]

type i_request =
| I_req of i_bare_request * i_tokens [@@deriving bin_io]

type i_reply =
| I_reply of i_bare_reply * i_tokens [@@deriving bin_io]

type i_prepare =
| I_prepare of i_bare_prepare * i_tokens [@@deriving bin_io]

type i_commit =
| I_commit of i_bare_commit * i_tokens [@@deriving bin_io]

type i_checkpoint =
| I_checkpoint of i_bare_checkpoint * i_tokens [@@deriving bin_io]

type i_debug =
| I_debug of i_rep * char list [@@deriving bin_io]

type i_start_timer =
| I_start_timer of i_bare_request * i_view [@@deriving bin_io]

type i_expired_timer =
| I_expired_timer of i_bare_request * i_view [@@deriving bin_io]

type i_bare_pre_prepare =
| I_bare_pre_prepare of i_view * i_seq_num * i_request list [@@deriving bin_io]

type i_pre_prepare =
| I_pre_prepare of i_bare_pre_prepare * i_tokens [@@deriving bin_io]

type i_sm_state = int [@@deriving bin_io]

type i_last_reply_entry =
| I_last_reply_entry of i_client * i_timestamp * i_result option [@@deriving bin_io]

type i_last_reply_state = i_last_reply_entry list [@@deriving bin_io]

type i_stable_chk_pt =
| I_stable_chk_pt of i_sm_state * i_last_reply_state [@@deriving bin_io]

type i_checkpoint_cert = i_checkpoint list [@@deriving bin_io]

type i_prepared_info =
| I_prepared_info of i_pre_prepare * i_digest * i_prepare list [@@deriving bin_io]

type i_bare_view_change =
| I_bare_view_change of i_view * i_seq_num * i_stable_chk_pt * i_checkpoint_cert * i_prepared_info list * i_rep [@@deriving bin_io]

type i_view_change =
| I_view_change of i_bare_view_change * i_tokens [@@deriving bin_io]

type i_bare_new_view =
| I_bare_new_view of i_view * i_view_change list * i_pre_prepare list * i_pre_prepare list [@@deriving bin_io]

type i_new_view =
| I_new_view of i_bare_new_view * i_tokens [@@deriving bin_io]

type i_PBFTmsg =
| I_PBFTrequest              of i_request
| I_PBFTpre_prepare          of i_pre_prepare
| I_PBFTprepare              of i_prepare
| I_PBFTcommit               of i_commit
| I_PBFTreply                of i_reply
| I_PBFTcheckpoint           of i_checkpoint
| I_PBFTcheck_ready
| I_PBFTcheck_stable
| I_PBFTcheck_bcast_new_view of i_check_bcast_new_view
| I_PBFTstart_timer          of i_start_timer
| I_PBFTexpired_timer        of i_expired_timer
| I_PBFTview_change          of i_view_change
| I_PBFTnew_view             of i_new_view
| I_PBFTdebug                of i_debug [@@deriving bin_io]

let to_i_tokens a = List.map a Cstruct.to_string
let from_i_tokens a = List.map a Cstruct.of_string

let to_i_bare_request (br : bare_Request) : i_bare_request =
  match br with
  | Bare_req (opr,ts,c) -> I_bare_req (Obj.magic opr, ts, Obj.magic c)
  | Null_req -> I_null_req

let to_i_request (r : request) : i_request =
  match r with
  | Req (br, a) -> I_req (to_i_bare_request br, to_i_tokens (Obj.magic a))

let from_i_bare_request (br : i_bare_request) : bare_Request =
  match br with
  | I_bare_req (opr,ts,c) -> Bare_req (Obj.magic opr, ts, Obj.magic c)
  | I_null_req -> Null_req

let from_i_request (r : i_request) : request =
  match r with
  | I_req (br, a) -> Req (from_i_bare_request br, Obj.magic (from_i_tokens a))

let to_i_pre_prepare (p : pre_prepare) : i_pre_prepare =
  match p with
  | Pre_prepare (Bare_pre_prepare (v,n,rs), a) -> I_pre_prepare (I_bare_pre_prepare (v,n,map to_i_request rs), to_i_tokens (Obj.magic a))

let from_i_pre_prepare (p : i_pre_prepare) : pre_prepare =
  match p with
  | I_pre_prepare (I_bare_pre_prepare (v,n,rs), a) -> Pre_prepare (Bare_pre_prepare (v,n,map from_i_request rs), Obj.magic (from_i_tokens a))

let to_i_prepare (p : prepare) : i_prepare =
  match p with
  | Prepare (Bare_prepare (v,n,d,i), a) -> I_prepare (I_bare_prepare (v,n,Obj.magic d,Obj.magic i), to_i_tokens (Obj.magic a))

let from_i_prepare (p : i_prepare) : prepare =
  match p with
  | I_prepare (I_bare_prepare (v,n,d,i), a) -> Prepare (Bare_prepare (v,n,Obj.magic d,Obj.magic i), Obj.magic (from_i_tokens a))

let to_i_commit (c : commit) : i_commit =
  match c with
  | Commit (Bare_commit (v,n,d,i), a) -> I_commit (I_bare_commit (v,n,Obj.magic d,Obj.magic i), to_i_tokens (Obj.magic a))

let from_i_commit (c : i_commit) : commit =
  match c with
  | I_commit (I_bare_commit (v,n,d,i), a) -> Commit (Bare_commit (v,n,Obj.magic d,Obj.magic i), Obj.magic (from_i_tokens a))

let to_i_reply (r : reply) : i_reply =
  match r with
  | Reply (Bare_reply (v,ts,c,i,res), a) -> I_reply (I_bare_reply (v,ts,Obj.magic c,Obj.magic i,Obj.magic res), to_i_tokens (Obj.magic a))

let from_i_reply (r : i_reply) : reply =
  match r with
  | I_reply (I_bare_reply (v,ts,c,i,res), a) -> Reply (Bare_reply (v,ts,Obj.magic c,Obj.magic i,Obj.magic res), Obj.magic (from_i_tokens a))

let to_i_checkpoint (c : checkpoint) : i_checkpoint =
  match c with
  | Checkpoint (Bare_checkpoint (v,n,d,i), a) -> I_checkpoint (I_bare_checkpoint (v,n,Obj.magic d,Obj.magic i), to_i_tokens (Obj.magic a))

let from_i_checkpoint (c : i_checkpoint) : checkpoint =
  match c with
  | I_checkpoint (I_bare_checkpoint (v,n,d,i), a) -> Checkpoint (Bare_checkpoint (v,n,Obj.magic d,Obj.magic i), Obj.magic (from_i_tokens a))

let to_i_check_bcast_new_view (c : checkBCastNewView) : i_check_bcast_new_view = c

let from_i_check_bcast_new_view (c : i_check_bcast_new_view) : checkBCastNewView = c

let to_i_start_timer (s : startTimer) : i_start_timer =
  match s with
  | Start_timer (br, v) -> I_start_timer (to_i_bare_request br, v)

let from_i_start_timer (s : i_start_timer) : startTimer =
  match s with
  | I_start_timer (br, v) -> Start_timer (from_i_bare_request br, v)

let to_i_expired_timer (s : expiredTimer) : i_expired_timer =
  match s with
  | Expired_timer (br, v) -> I_expired_timer (to_i_bare_request br, v)

let from_i_expired_timer (s : i_expired_timer) : expiredTimer =
  match s with
  | I_expired_timer (br, v) -> Expired_timer (from_i_bare_request br, v)

let to_i_sm_state (s : pBFTsm_state) : i_sm_state = Obj.magic s

let from_i_sm_state (s : i_sm_state) : pBFTsm_state = Obj.magic s

let to_i_last_reply_entry (e : lastReplyEntry) : i_last_reply_entry =
  match e with
  | { lre_client; lre_timestamp; lre_reply } -> I_last_reply_entry (Obj.magic lre_client, lre_timestamp, Obj.magic lre_reply)

let from_i_last_reply_entry (e : i_last_reply_entry) : lastReplyEntry =
  match e with
  | I_last_reply_entry (c, ts, r) ->
     { lre_client = Obj.magic c; lre_timestamp = ts; lre_reply = Obj.magic r }

let to_i_last_reply_state (l : lastReplyState) : i_last_reply_state =
  List.map l to_i_last_reply_entry

let from_i_last_reply_state (l : i_last_reply_state) : lastReplyState =
  List.map l from_i_last_reply_entry

let to_i_stable_chk_pt (s : stableChkPt) : i_stable_chk_pt =
  match s with
  | { si_state; si_lastr } -> I_stable_chk_pt (to_i_sm_state si_state, to_i_last_reply_state si_lastr)

let from_i_stable_chk_pt (s : i_stable_chk_pt) : stableChkPt =
  match s with
  | I_stable_chk_pt (sm, lastr) ->
     { si_state = from_i_sm_state sm; si_lastr = from_i_last_reply_state lastr }

let to_i_checkpoint_cert (c : checkpointCert) : i_checkpoint_cert =
  List.map c to_i_checkpoint

let from_i_checkpoint_cert (c : i_checkpoint_cert) : checkpointCert =
  List.map c from_i_checkpoint

let to_i_prepares (l : prepare list) : i_prepare list =
  List.map l to_i_prepare

let from_i_prepares (l : i_prepare list) : prepare list =
  List.map l from_i_prepare

let to_i_prepared_info (p : preparedInfo) : i_prepared_info =
  match p with
  | { prepared_info_pre_prepare; prepared_info_digest; prepared_info_prepares } ->
     I_prepared_info (to_i_pre_prepare prepared_info_pre_prepare,
                      Obj.magic prepared_info_digest,
                      to_i_prepares prepared_info_prepares)

let from_i_prepared_info (p : i_prepared_info) : preparedInfo =
  match p with
  | I_prepared_info (pre, d, preps) ->
     { prepared_info_pre_prepare = from_i_pre_prepare pre;
       prepared_info_digest      = Obj.magic d;
       prepared_info_prepares    = from_i_prepares preps }

let to_i_prepared_infos (l : preparedInfo list) : i_prepared_info list =
  List.map l to_i_prepared_info

let from_i_prepared_infos (l : i_prepared_info list) : preparedInfo list =
  List.map l from_i_prepared_info

let to_i_bare_view_change (vc : bare_ViewChange) : i_bare_view_change =
  match vc with
  | Bare_view_change (v,n,s,c,l,i) -> I_bare_view_change (v,n,to_i_stable_chk_pt s,to_i_checkpoint_cert c,to_i_prepared_infos l,Obj.magic i)

let from_i_bare_view_change (vc : i_bare_view_change) : bare_ViewChange =
  match vc with
  | I_bare_view_change (v,n,s,c,l,i) -> Bare_view_change (v,n,from_i_stable_chk_pt s,from_i_checkpoint_cert c,from_i_prepared_infos l,Obj.magic i)

let to_i_view_change (vc : viewChange) : i_view_change =
  match vc with
  | View_change (bvc, a) -> I_view_change (to_i_bare_view_change bvc, to_i_tokens (Obj.magic a))

let from_i_view_change (vc : i_view_change) : viewChange =
  match vc with
  | I_view_change (bvc, a) -> View_change (from_i_bare_view_change bvc, Obj.magic (from_i_tokens a))

let to_i_view_changes (l : viewChange list) : i_view_change list =
  List.map l to_i_view_change

let from_i_view_changes (l : i_view_change list) : viewChange list =
  List.map l from_i_view_change

let to_i_pre_prepares (l : pre_prepare list) : i_pre_prepare list =
  List.map l to_i_pre_prepare

let from_i_pre_prepares (l : i_pre_prepare list) : pre_prepare list =
  List.map l from_i_pre_prepare

let to_i_bare_new_view (nv : bare_NewView) : i_bare_new_view =
  match nv with
  | Bare_new_view (v,c,op,np) -> I_bare_new_view (v,to_i_view_changes c, to_i_pre_prepares op, to_i_pre_prepares np)

let from_i_bare_new_view (nv : i_bare_new_view) : bare_NewView =
  match nv with
  | I_bare_new_view (v,c,op,np) -> Bare_new_view (v,from_i_view_changes c, from_i_pre_prepares op, from_i_pre_prepares np)

let to_i_new_view (nv : newView) : i_new_view =
  match nv with
  | New_view (bnv, a) -> I_new_view (to_i_bare_new_view bnv, to_i_tokens (Obj.magic a))

let from_i_new_view (nv : i_new_view) : newView =
  match nv with
  | I_new_view (bnv, a) -> New_view (from_i_bare_new_view bnv, Obj.magic (from_i_tokens a))

let to_i_PBFTmsg (m : pBFTmsg) : i_PBFTmsg =
  match m with
  | PBFTrequest              r -> I_PBFTrequest              (to_i_request r)
  | PBFTpre_prepare          p -> I_PBFTpre_prepare          (to_i_pre_prepare p)
  | PBFTprepare              p -> I_PBFTprepare              (to_i_prepare p)
  | PBFTcommit               c -> I_PBFTcommit               (to_i_commit c)
  | PBFTreply                r -> I_PBFTreply                (to_i_reply r)
  | PBFTcheckpoint           c -> I_PBFTcheckpoint           (to_i_checkpoint c)
  | PBFTcheck_ready            -> I_PBFTcheck_ready
  | PBFTcheck_stable           -> I_PBFTcheck_stable
  | PBFTcheck_bcast_new_view c -> I_PBFTcheck_bcast_new_view (to_i_check_bcast_new_view c)
  | PBFTstart_timer          t -> I_PBFTstart_timer          (to_i_start_timer t)
  | PBFTexpired_timer        t -> I_PBFTexpired_timer        (to_i_expired_timer t)
  | PBFTview_change          v -> I_PBFTview_change          (to_i_view_change v)
  | PBFTnew_view             v -> I_PBFTnew_view             (to_i_new_view v)
  | _ -> raise (TODO ("to_i_PBFTmsg:" ^ Batteries.String.of_list (msg2string m)))

let from_i_PBFTmsg (m : i_PBFTmsg) : pBFTmsg =
  match m with
  | I_PBFTrequest              r -> PBFTrequest              (from_i_request r)
  | I_PBFTpre_prepare          p -> PBFTpre_prepare          (from_i_pre_prepare p)
  | I_PBFTprepare              p -> PBFTprepare              (from_i_prepare p)
  | I_PBFTcommit               c -> PBFTcommit               (from_i_commit c)
  | I_PBFTreply                r -> PBFTreply                (from_i_reply r)
  | I_PBFTcheckpoint           c -> PBFTcheckpoint           (from_i_checkpoint c)
  | I_PBFTcheck_ready            -> PBFTcheck_ready
  | I_PBFTcheck_stable           -> PBFTcheck_stable
  | I_PBFTcheck_bcast_new_view c -> PBFTcheck_bcast_new_view (from_i_check_bcast_new_view c)
  | I_PBFTstart_timer          t -> PBFTstart_timer          (from_i_start_timer t)
  | I_PBFTexpired_timer        t -> PBFTexpired_timer        (from_i_expired_timer t)
  | I_PBFTview_change          v -> PBFTview_change          (from_i_view_change v)
  | I_PBFTnew_view             v -> PBFTnew_view             (from_i_new_view v)
  | _ -> raise (TODO "from_i_PBFTmsg")

(* =====================================================
   ===================================================== *)


(*let new_view_to_bare (m : pBFTmsg) : (*pBFTBare_Msg*) (viewChange list) option =
  match m with
  | PBFTnew_view (New_view (Bare_new_view(v,c,op,np) as b, _)) -> Some c (*(PBFTmsg_bare_new_view b)*)
  | _ -> None*)

let new_view_to_bare (m : pBFTmsg) : bare_NewView option =
  match m with
  | PBFTnew_view (New_view (Bare_new_view(v,c,op,np) as b, _)) -> Some b
  | _ -> None

(*let new_view_to_bare (m : pBFTmsg) : view option =
  match m with
  | PBFTnew_view (New_view (Bare_new_view(v,c,op,np) as b, _)) -> Some v
  | _ -> None*)
