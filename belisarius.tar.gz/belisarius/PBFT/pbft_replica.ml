type __ = Obj.t
let __ = let rec f _ = Obj.repr f in Obj.repr f

(** val negb : bool -> bool **)

let negb = function
| true -> false
| false -> true

(** val option_map : ('a1 -> 'a2) -> 'a1 option -> 'a2 option **)

let option_map f1 = function
| Some a -> Some (f1 a)
| None -> None

(** val fst : ('a1 * 'a2) -> 'a1 **)

let fst = function
| (x, _) -> x

(** val snd : ('a1 * 'a2) -> 'a2 **)

let snd = function
| (_, y) -> y

(** val length : 'a1 list -> int **)

let rec length = function
| [] -> 0
| _ :: l' -> Pervasives.succ (length l')

(** val app : 'a1 list -> 'a1 list -> 'a1 list **)

let rec app l m =
  match l with
  | [] -> m
  | a :: l1 -> a :: (app l1 m)

type 'a sig0 =
  'a
  (* singleton inductive, whose constructor was exist *)



(** val pred : int -> int **)

let pred = fun n -> Pervasives.max 0 (n-1)

(** val add : int -> int -> int **)

let rec add = (+)

(** val mul : int -> int -> int **)

let rec mul = ( * )

(** val sub : int -> int -> int **)

let rec sub = fun n m -> Pervasives.max 0 (n-m)

module Nat =
 struct
  (** val sub : int -> int -> int **)

  let rec sub n m =
    (fun fO fS n -> if n=0 then fO () else fS (n-1))
      (fun _ ->
      n)
      (fun k ->
      (fun fO fS n -> if n=0 then fO () else fS (n-1))
        (fun _ ->
        n)
        (fun l ->
        sub k l)
        m)
      n

  (** val ltb : int -> int -> bool **)

  let ltb n m =
    (<=) (Pervasives.succ n) m

  (** val divmod : int -> int -> int -> int -> int * int **)

  let rec divmod x y q u =
    (fun fO fS n -> if n=0 then fO () else fS (n-1))
      (fun _ -> (q,
      u))
      (fun x' ->
      (fun fO fS n -> if n=0 then fO () else fS (n-1))
        (fun _ ->
        divmod x' y (Pervasives.succ q) y)
        (fun u' ->
        divmod x' y q u')
        u)
      x

  (** val modulo : int -> int -> int **)

  let modulo x y =
    (fun fO fS n -> if n=0 then fO () else fS (n-1))
      (fun _ ->
      y)
      (fun y' ->
      sub y' (snd (divmod x y' 0 y')))
      y
 end

(** val in_dec : ('a1 -> 'a1 -> bool) -> 'a1 -> 'a1 list -> bool **)

let rec in_dec h a = function
| [] -> false
| y :: l0 -> let s = h y a in if s then true else in_dec h a l0

(** val list_eq_dec : ('a1 -> 'a1 -> bool) -> 'a1 list -> 'a1 list -> bool **)

let rec list_eq_dec eq_dec l l' =
  match l with
  | [] ->
    (match l' with
     | [] -> true
     | _ :: _ -> false)
  | y :: l0 ->
    (match l' with
     | [] -> false
     | a0 :: l1 -> if eq_dec y a0 then list_eq_dec eq_dec l0 l1 else false)

(** val map : ('a1 -> 'a2) -> 'a1 list -> 'a2 list **)

let rec map f1 = function
| [] -> []
| a :: t -> (f1 a) :: (map f1 t)

(** val flat_map : ('a1 -> 'a2 list) -> 'a1 list -> 'a2 list **)

let rec flat_map f1 = function
| [] -> []
| x :: t -> app (f1 x) (flat_map f1 t)

(** val existsb : ('a1 -> bool) -> 'a1 list -> bool **)

let rec existsb f1 = function
| [] -> false
| a :: l0 -> (||) (f1 a) (existsb f1 l0)

(** val forallb : ('a1 -> bool) -> 'a1 list -> bool **)

let rec forallb f1 = function
| [] -> true
| a :: l0 -> (&&) (f1 a) (forallb f1 l0)

(** val filter : ('a1 -> bool) -> 'a1 list -> 'a1 list **)

let rec filter f1 = function
| [] -> []
| x :: l0 -> if f1 x then x :: (filter f1 l0) else filter f1 l0

(** val find : ('a1 -> bool) -> 'a1 list -> 'a1 option **)

let rec find f1 = function
| [] -> None
| x :: tl -> if f1 x then Some x else find f1 tl

(** val seq : int -> int -> int list **)

let rec seq start len =
  (fun fO fS n -> if n=0 then fO () else fS (n-1))
    (fun _ ->
    [])
    (fun len0 ->
    start :: (seq (Pervasives.succ start) len0))
    len

(** val append : char list -> char list -> char list **)

let rec append s1 s2 =
  match s1 with
  | [] -> s2
  | c::s1' -> c::(append s1' s2)

type 't deceq = bool

type 't deq = 't -> 't -> 't deceq

(** val is_some : 'a1 option -> bool **)

let is_some = function
| Some _ -> true
| None -> false

(** val remove_elt : 'a1 deq -> 'a1 -> 'a1 list -> 'a1 list **)

let rec remove_elt dec z = function
| [] -> []
| x :: xs -> if dec z x then remove_elt dec z xs else x :: (remove_elt dec z xs)

(** val norepeatsb : 'a1 deq -> 'a1 list -> bool **)

let rec norepeatsb d = function
| [] -> true
| x :: xs -> if in_dec d x xs then false else norepeatsb d xs

(** val mapin : 'a1 list -> ('a1 -> __ -> 'a2) -> 'a2 list **)

let rec mapin l x =
  match l with
  | [] -> []
  | x0 :: xs -> (x x0 __) :: (mapin xs (fun a _ -> x a __))

type node =
  __ deq
  (* singleton inductive, whose constructor was Build_Node *)

type name = __

(** val name_dec : node -> name deq **)

let name_dec node0 =
  node0

type msg =
| Build_Msg

type msg0 = __

type directedMsg = { dmMsg : msg0; dmDst : name list }

(** val dmMsg : node -> msg -> directedMsg -> msg0 **)

let dmMsg _ _ x = x.dmMsg

type directedMsgs = directedMsg list

type key =
| Build_Key

type key0 = __

type dKey = { dk_dst : name; dk_key : key0 }

(** val dk_dst : node -> key -> dKey -> name **)

let dk_dst _ _ x = x.dk_dst

(** val dk_key : node -> key -> dKey -> key0 **)

let dk_key _ _ x = x.dk_key

type local_key_map = dKey list

type key_map = name -> local_key_map

(** val lookup_dkey : node -> key -> local_key_map -> name -> dKey option **)

let lookup_dkey n _ km h =
  find (fun dk -> if name_dec n dk.dk_dst h then true else false) km

(** val lookup_key : node -> key -> local_key_map -> name -> key0 option **)

let lookup_key n pk km h =
  option_map (fun dk -> dk.dk_key) (lookup_dkey n pk km h)

type authTok =
  __ deq
  (* singleton inductive, whose constructor was MkAuthTok *)

type token = __

type tokens = token list

type data =
| Build_Data

type data0 = __

type authFun = { create : (data0 -> key0 -> token);
                 verify : (data0 -> key0 -> token -> bool) }

(** val create : key -> authTok -> data -> authFun -> data0 -> key0 -> token **)

let create _ _ _ x = x.create

(** val verify :
    key -> authTok -> data -> authFun -> data0 -> key0 -> token -> bool **)

let verify _ _ _ x = x.verify

(** val authenticate :
    node -> key -> authTok -> data -> authFun -> data0 -> local_key_map -> tokens **)

let authenticate _ _ _ _ authfun d km =
  map (fun dk -> authfun.create d dk.dk_key) km

type authenticatedData = { am_data : data0; am_auth : tokens }

(** val am_data : authTok -> data -> authenticatedData -> data0 **)

let am_data _ _ x = x.am_data

(** val am_auth : authTok -> data -> authenticatedData -> tokens **)

let am_auth _ _ x = x.am_auth

type dataAuth =
  name -> data0 -> name option
  (* singleton inductive, whose constructor was Build_DataAuth *)

(** val data_auth : data -> node -> dataAuth -> name -> data0 -> name option **)

let data_auth _ _ dataAuth0 =
  dataAuth0

(** val verify_authenticated_data_key :
    data -> key -> authTok -> authFun -> authenticatedData -> key0 -> bool **)

let verify_authenticated_data_key _ _ _ paf m k =
  existsb (fun token0 -> paf.verify m.am_data k token0) m.am_auth

(** val am_sender :
    data -> node -> authTok -> dataAuth -> name -> authenticatedData -> name option **)

let am_sender pd pn _ pda slf m =
  data_auth pd pn pda slf m.am_data

(** val verify_authenticated_data :
    data -> key -> node -> authTok -> authFun -> dataAuth -> name ->
    authenticatedData -> local_key_map -> bool **)

let verify_authenticated_data pd pk pn pat paf pda slf m keys =
  match am_sender pd pn pat pda slf m with
  | Some name0 ->
    (match lookup_key pn pk keys name0 with
     | Some key1 -> verify_authenticated_data_key pd pk pat paf m key1
     | None -> false)
  | None -> false

type ('s, 'i, 'o) update = 's -> 'i -> 's option * 'o

type 's mUpdate = ('s, msg0, directedMsgs) update

type ('s, 'i, 'o) stateMachine = { sm_halted : bool;
                                   sm_update : ('s, 'i, 'o) update; sm_state : 
                                   's }

(** val mkSM : ('a3, 'a1, 'a2) update -> 'a3 -> ('a3, 'a1, 'a2) stateMachine **)

let mkSM upd s =
  { sm_halted = false; sm_update = upd; sm_state = s }

type 's mStateMachine = ('s, msg0, directedMsgs) stateMachine

(** val deq_unit : unit deq **)

let deq_unit _ _ =
  true

type nat_n = int

type ('a, 'b) bijective =
  'b -> 'a
  (* singleton inductive, whose constructor was Build_bijective *)

(** val bij_inv : ('a1 -> 'a2) -> ('a1, 'a2) bijective -> 'a2 -> 'a1 **)

let bij_inv _ b =
  b

(** val nat_n_deq : int -> nat_n deq **)

let nat_n_deq _ x y =
  (=) x y

type quorum_context = { num_nodes : int; node_deq : __ deq;
                        nodes2nat : (__ -> nat_n); nodes_bij : (__, nat_n) bijective }

type node_type = __

(** val num_nodes : quorum_context -> int **)

let num_nodes x = x.num_nodes

(** val nodes2nat : quorum_context -> node_type -> nat_n **)

let nodes2nat x = x.nodes2nat

(** val nodes_bij : quorum_context -> (node_type, nat_n) bijective **)

let nodes_bij x = x.nodes_bij

(** val mk_nat_n : int -> int -> nat_n **)

let mk_nat_n x _ =
  x

(** val nodes : quorum_context -> node_type list **)

let nodes quorum_context0 =
  mapin (seq 0 quorum_context0.num_nodes) (fun n _ ->
    bij_inv quorum_context0.nodes2nat quorum_context0.nodes_bij
      (mk_nat_n n quorum_context0.num_nodes))

type pBFTcontext = { pBFTmax_in_progress : int; pBFTwater_mark_range : int;
                     pBFTcheckpoint_period : int; pBFTdigestdeq : __ deq; f : 
                     int; rep_deq : __ deq; reps2nat : (__ -> nat_n);
                     reps_bij : (__, nat_n) bijective; num_clients : int;
                     client_deq : __ deq; clients2nat : (__ -> nat_n);
                     clients_bij : (__, nat_n) bijective; pBFTopdeq : __ deq;
                     pBFTresdeq : __ deq; pBFTsm_initial_state : __;
                     pBFTsm_update : (__ -> __ -> __ -> __ * __) }

(** val pBFTmax_in_progress : pBFTcontext -> int **)

let pBFTmax_in_progress x = x.pBFTmax_in_progress

(** val pBFTwater_mark_range : pBFTcontext -> int **)

let pBFTwater_mark_range x = x.pBFTwater_mark_range

(** val pBFTcheckpoint_period : pBFTcontext -> int **)

let pBFTcheckpoint_period x = x.pBFTcheckpoint_period

type pBFTdigest = __

(** val pBFTdigestdeq : pBFTcontext -> pBFTdigest deq **)

let pBFTdigestdeq x = x.pBFTdigestdeq

(** val f : pBFTcontext -> int **)

let f x = x.f

(** val num_replicas : pBFTcontext -> int **)

let num_replicas pBFTcontext0 =
  add (mul (Pervasives.succ (Pervasives.succ (Pervasives.succ 0))) pBFTcontext0.f)
    (Pervasives.succ 0)

type rep = __

(** val rep_deq : pBFTcontext -> rep deq **)

let rep_deq x = x.rep_deq

(** val reps2nat : pBFTcontext -> rep -> nat_n **)

let reps2nat x = x.reps2nat

(** val reps_bij : pBFTcontext -> (rep, nat_n) bijective **)

let reps_bij x = x.reps_bij

(** val num_clients : pBFTcontext -> int **)

let num_clients x = x.num_clients

type client = __

(** val client_deq : pBFTcontext -> client deq **)

let client_deq x = x.client_deq

(** val clients2nat : pBFTcontext -> client -> nat_n **)

let clients2nat x = x.clients2nat

(** val clients_bij : pBFTcontext -> (client, nat_n) bijective **)

let clients_bij x = x.clients_bij

type pBFToperation = __

type pBFTresult = __

type pBFTsm_state = __

(** val pBFTsm_initial_state : pBFTcontext -> pBFTsm_state **)

let pBFTsm_initial_state x = x.pBFTsm_initial_state

(** val pBFTsm_update :
    pBFTcontext -> client -> pBFTsm_state -> pBFToperation ->
    pBFTresult * pBFTsm_state **)

let pBFTsm_update x = x.pBFTsm_update

(** val pBFT_I_Quorum : pBFTcontext -> quorum_context **)

let pBFT_I_Quorum pbft_context =
  { num_nodes = (num_replicas pbft_context); node_deq = pbft_context.rep_deq;
    nodes2nat = pbft_context.reps2nat; nodes_bij = pbft_context.reps_bij }

type pBFTnode =
| PBFTreplica of rep
| PBFTclient of client

(** val pBFTnodeDeq : pBFTcontext -> pBFTnode deq **)

let pBFTnodeDeq pbft_context x y =
  match x with
  | PBFTreplica r1 ->
    (match y with
     | PBFTreplica r2 -> pbft_context.rep_deq r1 r2
     | PBFTclient _ -> false)
  | PBFTclient c1 ->
    (match y with
     | PBFTreplica _ -> false
     | PBFTclient c2 -> pbft_context.client_deq c1 c2)

(** val pBFT_I_Node : pBFTcontext -> node **)

let pBFT_I_Node pbft_context =
  Obj.magic pBFTnodeDeq pbft_context

(** val nat_n_2Fp1_0 : pBFTcontext -> nat_n **)

let nat_n_2Fp1_0 _ =
  0

(** val replica0 : pBFTcontext -> rep **)

let replica0 pbft_context =
  bij_inv pbft_context.reps2nat pbft_context.reps_bij (nat_n_2Fp1_0 pbft_context)

(** val nat2rep : pBFTcontext -> int -> rep **)

let nat2rep pbft_context n =
  let b = pbft_context.reps_bij in
  let s = (<) n (num_replicas pbft_context) in
  if s then b (mk_nat_n n (num_replicas pbft_context)) else replica0 pbft_context

(** val reps : pBFTcontext -> rep list **)

let reps pbft_context =
  nodes (pBFT_I_Quorum pbft_context)

(** val clients : pBFTcontext -> client list **)

let clients pbft_context =
  mapin (seq 0 pbft_context.num_clients) (fun n _ ->
    bij_inv pbft_context.clients2nat pbft_context.clients_bij
      (mk_nat_n n pbft_context.num_clients))

type view =
  int
  (* singleton inductive, whose constructor was view *)

(** val view2nat : view -> int **)

let view2nat v =
  v

(** val next_view : view -> view **)

let next_view v =
  Pervasives.succ (view2nat v)

(** val pred_view : view -> view **)

let pred_view v =
  pred (view2nat v)

(** val viewDeq : view deq **)

let viewDeq x y =
  (=) x y

(** val initial_view : view **)

let initial_view =
  0

(** val viewLe : view -> view -> bool **)

let viewLe vn1 vn2 =
  (<=) (view2nat vn1) (view2nat vn2)

(** val viewLt : view -> view -> bool **)

let viewLt vn1 vn2 =
  Nat.ltb (view2nat vn1) (view2nat vn2)

(** val max_view : view -> view -> view **)

let max_view v1 v2 =
  if viewLe v1 v2 then v2 else v1

type timestamp =
  int
  (* singleton inductive, whose constructor was time_stamp *)

(** val timestamp2nat : timestamp -> int **)

let timestamp2nat t =
  t

(** val timestamp0 : timestamp **)

let timestamp0 =
  0

type seqNum =
  int
  (* singleton inductive, whose constructor was seq_num *)

(** val seqnum2nat : seqNum -> int **)

let seqnum2nat s =
  s

(** val seqNumLe : seqNum -> seqNum -> bool **)

let seqNumLe sn1 sn2 =
  (<=) (seqnum2nat sn1) (seqnum2nat sn2)

(** val seqNumLt : seqNum -> seqNum -> bool **)

let seqNumLt sn1 sn2 =
  Nat.ltb (seqnum2nat sn1) (seqnum2nat sn2)

(** val next_seq : seqNum -> seqNum **)

let next_seq n =
  Pervasives.succ (seqnum2nat n)

(** val seqNumDeq : seqNum deq **)

let seqNumDeq x y =
  (=) x y

(** val initial_sequence_number : seqNum **)

let initial_sequence_number =
  0

(** val max_seq_num : seqNum -> seqNum -> seqNum **)

let max_seq_num s1 s2 =
  if seqNumLe s1 s2 then s2 else s1

(** val pBFTprimary_nat : pBFTcontext -> view -> int **)

let pBFTprimary_nat pbft_context v =
  Nat.modulo (view2nat v) (num_replicas pbft_context)

(** val pBFTprimary : pBFTcontext -> view -> rep **)

let pBFTprimary pbft_context v =
  nat2rep pbft_context (pBFTprimary_nat pbft_context v)

(** val is_primary : pBFTcontext -> view -> rep -> bool **)

let is_primary pbft_context v r =
  if pbft_context.rep_deq r (pBFTprimary pbft_context v) then true else false

(** val pBFT_I_AuthTok : pBFTcontext -> authTok **)

let pBFT_I_AuthTok pbft_context =
  pbft_context.pBFTdigestdeq

type bare_Request =
| Null_req
| Bare_req of pBFToperation * timestamp * client

type bare_Reply =
| Bare_reply of view * timestamp * client * rep * pBFTresult

type bare_Prepare =
| Bare_prepare of view * seqNum * pBFTdigest * rep

type bare_Commit =
| Bare_commit of view * seqNum * pBFTdigest * rep

type bare_Checkpoint =
| Bare_checkpoint of view * seqNum * pBFTdigest * rep

type request =
| Req of bare_Request * tokens

type reply =
| Reply of bare_Reply * tokens

type prepare =
| Prepare of bare_Prepare * tokens

type commit =
| Commit of bare_Commit * tokens

type checkpoint =
| Checkpoint of bare_Checkpoint * tokens

type debug =
| Debug of rep * char list

type startTimer =
| Start_timer of bare_Request * view

type expiredTimer =
| Expired_timer of bare_Request * view

type bare_Pre_prepare =
| Bare_pre_prepare of view * seqNum * request list

type pre_prepare =
| Pre_prepare of bare_Pre_prepare * tokens

type preparedInfo = { prepared_info_pre_prepare : pre_prepare;
                      prepared_info_digest : pBFTdigest;
                      prepared_info_prepares : prepare list }

(** val prepared_info_pre_prepare : pBFTcontext -> preparedInfo -> pre_prepare **)

let prepared_info_pre_prepare _ x = x.prepared_info_pre_prepare

(** val prepared_info_digest : pBFTcontext -> preparedInfo -> pBFTdigest **)

let prepared_info_digest _ x = x.prepared_info_digest

(** val prepared_info_prepares : pBFTcontext -> preparedInfo -> prepare list **)

let prepared_info_prepares _ x = x.prepared_info_prepares

type checkpointCert = checkpoint list

type lastReplyEntry = { lre_client : client; lre_timestamp : timestamp;
                        lre_reply : pBFTresult option }

(** val lre_client : pBFTcontext -> lastReplyEntry -> client **)

let lre_client _ x = x.lre_client

(** val lre_timestamp : pBFTcontext -> lastReplyEntry -> timestamp **)

let lre_timestamp _ x = x.lre_timestamp

(** val lre_reply : pBFTcontext -> lastReplyEntry -> pBFTresult option **)

let lre_reply _ x = x.lre_reply

type lastReplyState = lastReplyEntry list

type stableChkPt = { si_state : pBFTsm_state; si_lastr : lastReplyState }

(** val si_state : pBFTcontext -> stableChkPt -> pBFTsm_state **)

let si_state _ x = x.si_state

(** val si_lastr : pBFTcontext -> stableChkPt -> lastReplyState **)

let si_lastr _ x = x.si_lastr

type bare_ViewChange =
| Bare_view_change of view * seqNum * stableChkPt * checkpointCert
   * preparedInfo list * rep

type viewChange =
| View_change of bare_ViewChange * tokens

type viewChangeCert = viewChange list

type bare_NewView =
| Bare_new_view of view * viewChangeCert * pre_prepare list * pre_prepare list

type newView =
| New_view of bare_NewView * tokens

type pBFTviewChangeEntry = { vce_view : view; vce_view_change : viewChange option;
                             vce_view_changes : viewChange list;
                             vce_new_view : newView option }

(** val vce_view : pBFTcontext -> pBFTviewChangeEntry -> view **)

let vce_view _ x = x.vce_view

(** val vce_view_change :
    pBFTcontext -> pBFTviewChangeEntry -> viewChange option **)

let vce_view_change _ x = x.vce_view_change

(** val vce_view_changes : pBFTcontext -> pBFTviewChangeEntry -> viewChange list **)

let vce_view_changes _ x = x.vce_view_changes

(** val vce_new_view : pBFTcontext -> pBFTviewChangeEntry -> newView option **)

let vce_new_view _ x = x.vce_new_view

type checkBCastNewView =
  int
  (* singleton inductive, whose constructor was check_bcast_new_view *)

type pBFTBare_Msg =
| PBFTmsg_bare_request of bare_Request
| PBFTmsg_bare_reply of bare_Reply
| PBFTmsg_bare_pre_prepare of bare_Pre_prepare
| PBFTmsg_bare_prepare of bare_Prepare
| PBFTmsg_bare_commit of bare_Commit
| PBFTmsg_bare_checkpoint of bare_Checkpoint
| PBFTmsg_bare_check_ready
| PBFTmsg_bare_check_bcast_new_view of checkBCastNewView
| PBFTmsg_bare_start_timer of startTimer
| PBFTmsg_bare_expired_timer of expiredTimer
| PBFTmsg_bare_view_change of bare_ViewChange
| PBFTmsg_bare_new_view of bare_NewView

(** val pBFT_I_Data : pBFTcontext -> data **)

let pBFT_I_Data _ =
  Build_Data

(** val pBFT_I_Key : pBFTcontext -> key **)

let pBFT_I_Key _ =
  Build_Key

type pBFTauth = { pBFTcreate : (data0 -> key0 -> pBFTdigest);
                  pBFTverify : (data0 -> key0 -> pBFTdigest -> bool) }

(** val pBFTcreate : pBFTcontext -> pBFTauth -> data0 -> key0 -> pBFTdigest **)

let pBFTcreate _ x = x.pBFTcreate

(** val pBFTverify :
    pBFTcontext -> pBFTauth -> data0 -> key0 -> pBFTdigest -> bool **)

let pBFTverify _ x = x.pBFTverify

(** val pBFT_I_AuthFun : pBFTcontext -> pBFTauth -> authFun **)

let pBFT_I_AuthFun _ pbft_auth =
  { create = pbft_auth.pBFTcreate; verify = pbft_auth.pBFTverify }

type pBFTkeys =
  key_map
  (* singleton inductive, whose constructor was Build_PBFTkeys *)

(** val initial_keys : pBFTcontext -> pBFTkeys -> key_map **)

let initial_keys _ pBFTkeys0 =
  pBFTkeys0

(** val bare_request2sender : pBFTcontext -> bare_Request -> client option **)

let bare_request2sender _ = function
| Null_req -> None
| Bare_req (_, _, c) -> Some c

(** val request2sender : pBFTcontext -> request -> client option **)

let request2sender pbft_context = function
| Req (b, _) -> bare_request2sender pbft_context b

(** val bare_reply2sender : pBFTcontext -> bare_Reply -> rep **)

let bare_reply2sender _ = function
| Bare_reply (_, _, _, i, _) -> i

(** val bare_pre_prepare2sender : pBFTcontext -> bare_Pre_prepare -> rep **)

let bare_pre_prepare2sender pbft_context = function
| Bare_pre_prepare (v, _, _) -> pBFTprimary pbft_context v

(** val pre_prepare2sender : pBFTcontext -> pre_prepare -> rep **)

let pre_prepare2sender pbft_context = function
| Pre_prepare (b, _) -> bare_pre_prepare2sender pbft_context b

(** val bare_prepare2sender : pBFTcontext -> bare_Prepare -> rep **)

let bare_prepare2sender _ = function
| Bare_prepare (_, _, _, i) -> i

(** val prepare2sender : pBFTcontext -> prepare -> rep **)

let prepare2sender pbft_context = function
| Prepare (b, _) -> bare_prepare2sender pbft_context b

(** val bare_commit2sender : pBFTcontext -> bare_Commit -> rep **)

let bare_commit2sender _ = function
| Bare_commit (_, _, _, i) -> i

(** val commit2sender : pBFTcontext -> commit -> rep **)

let commit2sender pbft_context = function
| Commit (b, _) -> bare_commit2sender pbft_context b

(** val bare_checkpoint2sender : pBFTcontext -> bare_Checkpoint -> rep **)

let bare_checkpoint2sender _ = function
| Bare_checkpoint (_, _, _, i) -> i

(** val checkpoint2sender : pBFTcontext -> checkpoint -> rep **)

let checkpoint2sender pbft_context = function
| Checkpoint (b, _) -> bare_checkpoint2sender pbft_context b

(** val bare_view_change2sender : pBFTcontext -> bare_ViewChange -> rep **)

let bare_view_change2sender _ = function
| Bare_view_change (_, _, _, _, _, i) -> i

(** val view_change2sender : pBFTcontext -> viewChange -> rep **)

let view_change2sender pbft_context = function
| View_change (bv, _) -> bare_view_change2sender pbft_context bv

(** val bare_new_view2sender : pBFTcontext -> bare_NewView -> rep **)

let bare_new_view2sender pbft_context = function
| Bare_new_view (v, _, _, _) -> pBFTprimary pbft_context v

(** val new_view2sender : pBFTcontext -> newView -> rep **)

let new_view2sender pbft_context = function
| New_view (b, _) -> bare_new_view2sender pbft_context b

(** val prepared_info2senders : pBFTcontext -> preparedInfo -> rep list **)

let prepared_info2senders pbft_context nfo =
  map (prepare2sender pbft_context) nfo.prepared_info_prepares

(** val prepared_info2pp_sender : pBFTcontext -> preparedInfo -> rep **)

let prepared_info2pp_sender pbft_context nfo =
  pre_prepare2sender pbft_context nfo.prepared_info_pre_prepare

(** val bare_pre_prepare2seq : pBFTcontext -> bare_Pre_prepare -> seqNum **)

let bare_pre_prepare2seq _ = function
| Bare_pre_prepare (_, n, _) -> n

(** val pre_prepare2seq : pBFTcontext -> pre_prepare -> seqNum **)

let pre_prepare2seq pbft_context = function
| Pre_prepare (b, _) -> bare_pre_prepare2seq pbft_context b

(** val bare_prepare2seq : pBFTcontext -> bare_Prepare -> seqNum **)

let bare_prepare2seq _ = function
| Bare_prepare (_, n, _, _) -> n

(** val prepare2seq : pBFTcontext -> prepare -> seqNum **)

let prepare2seq pbft_context = function
| Prepare (b, _) -> bare_prepare2seq pbft_context b

(** val bare_commit2seq : pBFTcontext -> bare_Commit -> seqNum **)

let bare_commit2seq _ = function
| Bare_commit (_, n, _, _) -> n

(** val commit2seq : pBFTcontext -> commit -> seqNum **)

let commit2seq pbft_context = function
| Commit (b, _) -> bare_commit2seq pbft_context b

(** val bare_checkpoint2seq : pBFTcontext -> bare_Checkpoint -> seqNum **)

let bare_checkpoint2seq _ = function
| Bare_checkpoint (_, n, _, _) -> n

(** val checkpoint2seq : pBFTcontext -> checkpoint -> seqNum **)

let checkpoint2seq pbft_context = function
| Checkpoint (b, _) -> bare_checkpoint2seq pbft_context b

(** val bare_view_change2seq : pBFTcontext -> bare_ViewChange -> seqNum **)

let bare_view_change2seq _ = function
| Bare_view_change (_, n, _, _, _, _) -> n

(** val view_change2seq : pBFTcontext -> viewChange -> seqNum **)

let view_change2seq pbft_context = function
| View_change (bvc, _) -> bare_view_change2seq pbft_context bvc

(** val prepared_info2seq : pBFTcontext -> preparedInfo -> seqNum **)

let prepared_info2seq pbft_context p =
  pre_prepare2seq pbft_context p.prepared_info_pre_prepare

(** val bare_request2timestamp : pBFTcontext -> bare_Request -> timestamp **)

let bare_request2timestamp _ = function
| Null_req -> timestamp0
| Bare_req (_, t, _) -> t

(** val request2timestamp : pBFTcontext -> request -> timestamp **)

let request2timestamp pbft_context = function
| Req (b, _) -> bare_request2timestamp pbft_context b

(** val bare_reply2client : pBFTcontext -> bare_Reply -> client **)

let bare_reply2client _ = function
| Bare_reply (_, _, c, _, _) -> c

(** val reply2client : pBFTcontext -> reply -> client **)

let reply2client pbft_context = function
| Reply (b, _) -> bare_reply2client pbft_context b

(** val request2bare : pBFTcontext -> request -> bare_Request **)

let request2bare _ = function
| Req (b, _) -> b

(** val bare_pre_prepare2bare_prepare :
    pBFTcontext -> bare_Pre_prepare -> pBFTdigest -> rep -> bare_Prepare **)

let bare_pre_prepare2bare_prepare _ bpp d r =
  let Bare_pre_prepare (v, s, _) = bpp in Bare_prepare (v, s, d, r)

(** val pre_prepare2bare_prepare :
    pBFTcontext -> pre_prepare -> pBFTdigest -> rep -> bare_Prepare **)

let pre_prepare2bare_prepare pbft_context p d r =
  let Pre_prepare (b, _) = p in bare_pre_prepare2bare_prepare pbft_context b d r

(** val bare_prepare2bare_commit :
    pBFTcontext -> rep -> bare_Prepare -> bare_Commit **)

let bare_prepare2bare_commit _ slf = function
| Bare_prepare (v, s, d, _) -> Bare_commit (v, s, d, slf)

(** val prepare2bare_commit : pBFTcontext -> rep -> prepare -> bare_Commit **)

let prepare2bare_commit pbft_context slf = function
| Prepare (b, _) -> bare_prepare2bare_commit pbft_context slf b

(** val bare_request2info :
    pBFTcontext -> bare_Request -> ((pBFToperation * timestamp) * client) option **)

let bare_request2info _ = function
| Null_req -> None
| Bare_req (opr, t, c) -> Some ((opr, t), c)

(** val request2info :
    pBFTcontext -> request -> ((pBFToperation * timestamp) * client) option **)

let request2info pbft_context = function
| Req (b, _) -> bare_request2info pbft_context b

(** val bare_pre_prepare2bare_commit :
    pBFTcontext -> rep -> bare_Pre_prepare -> pBFTdigest -> bare_Commit **)

let bare_pre_prepare2bare_commit _ slf b d =
  let Bare_pre_prepare (v, s, _) = b in Bare_commit (v, s, d, slf)

(** val pre_prepare2bare_commit :
    pBFTcontext -> rep -> pre_prepare -> pBFTdigest -> bare_Commit **)

let pre_prepare2bare_commit pbft_context slf pp d =
  let Pre_prepare (b, _) = pp in bare_pre_prepare2bare_commit pbft_context slf b d

(** val view_change2bare : pBFTcontext -> viewChange -> bare_ViewChange **)

let view_change2bare _ = function
| View_change (v, _) -> v

(** val bare_pre_prepare2view : pBFTcontext -> bare_Pre_prepare -> view **)

let bare_pre_prepare2view _ = function
| Bare_pre_prepare (v, _, _) -> v

(** val pre_prepare2view : pBFTcontext -> pre_prepare -> view **)

let pre_prepare2view pbft_context = function
| Pre_prepare (b, _) -> bare_pre_prepare2view pbft_context b

(** val bare_prepare2view : pBFTcontext -> bare_Prepare -> view **)

let bare_prepare2view _ = function
| Bare_prepare (v, _, _, _) -> v

(** val prepare2view : pBFTcontext -> prepare -> view **)

let prepare2view pbft_context = function
| Prepare (b, _) -> bare_prepare2view pbft_context b

(** val bare_commit2view : pBFTcontext -> bare_Commit -> view **)

let bare_commit2view _ = function
| Bare_commit (v, _, _, _) -> v

(** val commit2view : pBFTcontext -> commit -> view **)

let commit2view pbft_context = function
| Commit (b, _) -> bare_commit2view pbft_context b

(** val bare_checkpoint2view : pBFTcontext -> bare_Checkpoint -> view **)

let bare_checkpoint2view _ = function
| Bare_checkpoint (v, _, _, _) -> v

(** val checkpoint2view : pBFTcontext -> checkpoint -> view **)

let checkpoint2view pbft_context = function
| Checkpoint (b, _) -> bare_checkpoint2view pbft_context b

(** val bare_new_view2view : pBFTcontext -> bare_NewView -> view **)

let bare_new_view2view _ = function
| Bare_new_view (v0, _, _, _) -> v0

(** val new_view2view : pBFTcontext -> newView -> view **)

let new_view2view pbft_context = function
| New_view (b, _) -> bare_new_view2view pbft_context b

(** val expired_timer2view : pBFTcontext -> expiredTimer -> view **)

let expired_timer2view _ = function
| Expired_timer (_, v) -> v

(** val bare_view_change2view : pBFTcontext -> bare_ViewChange -> view **)

let bare_view_change2view _ = function
| Bare_view_change (v, _, _, _, _, _) -> v

(** val view_change2view : pBFTcontext -> viewChange -> view **)

let view_change2view pbft_context vc =
  bare_view_change2view pbft_context (view_change2bare pbft_context vc)

(** val prepared_info2view : pBFTcontext -> preparedInfo -> view **)

let prepared_info2view pbft_context p =
  pre_prepare2view pbft_context p.prepared_info_pre_prepare

(** val start_timer2expired_timer : pBFTcontext -> startTimer -> expiredTimer **)

let start_timer2expired_timer _ = function
| Start_timer (r, v) -> Expired_timer (r, v)

(** val bare_view_change2prep :
    pBFTcontext -> bare_ViewChange -> preparedInfo list **)

let bare_view_change2prep _ = function
| Bare_view_change (_, _, _, _, p, _) -> p

(** val view_change2prep : pBFTcontext -> viewChange -> preparedInfo list **)

let view_change2prep pbft_context vc =
  bare_view_change2prep pbft_context (view_change2bare pbft_context vc)

(** val bare_pre_prepare2requests :
    pBFTcontext -> bare_Pre_prepare -> request list **)

let bare_pre_prepare2requests _ = function
| Bare_pre_prepare (_, _, m) -> m

(** val pre_prepare2requests : pBFTcontext -> pre_prepare -> request list **)

let pre_prepare2requests pbft_context = function
| Pre_prepare (bpp, _) -> bare_pre_prepare2requests pbft_context bpp

(** val prepared_info2requests : pBFTcontext -> preparedInfo -> request list **)

let prepared_info2requests pbft_context p =
  pre_prepare2requests pbft_context p.prepared_info_pre_prepare

(** val bare_checkpoint2digest : pBFTcontext -> bare_Checkpoint -> pBFTdigest **)

let bare_checkpoint2digest _ = function
| Bare_checkpoint (_, _, d, _) -> d

(** val checkpoint2digest : pBFTcontext -> checkpoint -> pBFTdigest **)

let checkpoint2digest pbft_context = function
| Checkpoint (b, _) -> bare_checkpoint2digest pbft_context b

(** val prepared_info2digest : pBFTcontext -> preparedInfo -> pBFTdigest **)

let prepared_info2digest _ p =
  p.prepared_info_digest

type pBFTmsg =
| PBFTrequest of request
| PBFTpre_prepare of pre_prepare
| PBFTprepare of prepare
| PBFTcommit of commit
| PBFTreply of reply
| PBFTcheckpoint of checkpoint
| PBFTcheck_ready
| PBFTcheck_bcast_new_view of checkBCastNewView
| PBFTstart_timer of startTimer
| PBFTexpired_timer of expiredTimer
| PBFTview_change of viewChange
| PBFTnew_view of newView
| PBFTdebug of debug

(** val option_client2name : pBFTcontext -> client option -> name -> name **)

let option_client2name _ cop n =
  match cop with
  | Some c -> Obj.magic (PBFTclient c)
  | None -> n

(** val pBFTdata_auth : pBFTcontext -> name -> data0 -> name option **)

let pBFTdata_auth pbft_context n m =
  match Obj.magic m with
  | PBFTmsg_bare_request r ->
    Some (option_client2name pbft_context (bare_request2sender pbft_context r) n)
  | PBFTmsg_bare_reply r ->
    Some (Obj.magic (PBFTreplica (bare_reply2sender pbft_context r)))
  | PBFTmsg_bare_pre_prepare p ->
    Some (Obj.magic (PBFTreplica (bare_pre_prepare2sender pbft_context p)))
  | PBFTmsg_bare_prepare p ->
    Some (Obj.magic (PBFTreplica (bare_prepare2sender pbft_context p)))
  | PBFTmsg_bare_commit c ->
    Some (Obj.magic (PBFTreplica (bare_commit2sender pbft_context c)))
  | PBFTmsg_bare_checkpoint c ->
    Some (Obj.magic (PBFTreplica (bare_checkpoint2sender pbft_context c)))
  | PBFTmsg_bare_view_change v ->
    Some (Obj.magic (PBFTreplica (bare_view_change2sender pbft_context v)))
  | PBFTmsg_bare_new_view v ->
    Some
      (Obj.magic (PBFTreplica
        (pBFTprimary pbft_context (pred_view (bare_new_view2view pbft_context v)))))
  | _ -> Some n

(** val pBFT_I_DataAuth : pBFTcontext -> dataAuth **)

let pBFT_I_DataAuth pbft_context =
  pBFTdata_auth pbft_context

(** val request2auth_data : pBFTcontext -> request -> authenticatedData **)

let request2auth_data _ = function
| Req (b, a) -> { am_data = (Obj.magic (PBFTmsg_bare_request b)); am_auth = a }

(** val pre_prepare_data2auth_data_pre :
    pBFTcontext -> pre_prepare -> authenticatedData **)

let pre_prepare_data2auth_data_pre _ = function
| Pre_prepare (b, a) ->
  { am_data = (Obj.magic (PBFTmsg_bare_pre_prepare b)); am_auth = a }

(** val pre_prepare2auth_data_req :
    pBFTcontext -> pre_prepare -> authenticatedData list **)

let pre_prepare2auth_data_req pbft_context p =
  map (request2auth_data pbft_context) (pre_prepare2requests pbft_context p)

(** val pre_prepare2auth_data :
    pBFTcontext -> pre_prepare -> authenticatedData list **)

let pre_prepare2auth_data pbft_context p =
  (pre_prepare_data2auth_data_pre pbft_context p) :: (pre_prepare2auth_data_req
                                                       pbft_context p)

(** val prepare2auth_data : pBFTcontext -> prepare -> authenticatedData **)

let prepare2auth_data _ = function
| Prepare (b, a) -> { am_data = (Obj.magic (PBFTmsg_bare_prepare b)); am_auth = a }

(** val commit2auth_data : pBFTcontext -> commit -> authenticatedData **)

let commit2auth_data _ = function
| Commit (b, a) -> { am_data = (Obj.magic (PBFTmsg_bare_commit b)); am_auth = a }

(** val checkpoint2auth_data : pBFTcontext -> checkpoint -> authenticatedData **)

let checkpoint2auth_data _ = function
| Checkpoint (b, a) ->
  { am_data = (Obj.magic (PBFTmsg_bare_checkpoint b)); am_auth = a }

(** val prepares2auth_data :
    pBFTcontext -> prepare list -> authenticatedData list **)

let prepares2auth_data pbft_context l =
  map (prepare2auth_data pbft_context) l

(** val prepared_info2auth_data :
    pBFTcontext -> preparedInfo -> authenticatedData list **)

let prepared_info2auth_data pbft_context p =
  app (pre_prepare2auth_data pbft_context p.prepared_info_pre_prepare)
    (prepares2auth_data pbft_context p.prepared_info_prepares)

(** val prepared_infos2auth_data :
    pBFTcontext -> preparedInfo list -> authenticatedData list **)

let prepared_infos2auth_data pbft_context p =
  flat_map (prepared_info2auth_data pbft_context) p

(** val checkpoints2auth_data :
    pBFTcontext -> checkpoint list -> authenticatedData list **)

let checkpoints2auth_data pbft_context l =
  map (checkpoint2auth_data pbft_context) l

(** val view_change2auth_data :
    pBFTcontext -> viewChange -> authenticatedData list **)

let view_change2auth_data pbft_context = function
| View_change (v0, a) ->
  let Bare_view_change (v1, n, s, c, p, i) = v0 in
  { am_data =
  (Obj.magic (PBFTmsg_bare_view_change (Bare_view_change (v1, n, s, c, p, i))));
  am_auth =
  a } :: (app (checkpoints2auth_data pbft_context c)
           (prepared_infos2auth_data pbft_context p))

(** val view_changes2auth_data :
    pBFTcontext -> viewChange list -> authenticatedData list **)

let view_changes2auth_data pbft_context l =
  flat_map (view_change2auth_data pbft_context) l

(** val pre_prepares2auth_data :
    pBFTcontext -> pre_prepare list -> authenticatedData list **)

let pre_prepares2auth_data pbft_context l =
  flat_map (pre_prepare2auth_data pbft_context) l

(** val new_view2auth_data : pBFTcontext -> newView -> authenticatedData list **)

let new_view2auth_data pbft_context = function
| New_view (v0, a) ->
  let Bare_new_view (v1, v2, oP, nP) = v0 in
  { am_data = (Obj.magic (PBFTmsg_bare_new_view (Bare_new_view (v1, v2, oP, nP))));
  am_auth =
  a } :: (app (view_changes2auth_data pbft_context v2)
           (app (pre_prepares2auth_data pbft_context oP)
             (pre_prepares2auth_data pbft_context nP)))

(** val send_reply : pBFTcontext -> reply -> directedMsg **)

let send_reply pbft_context r =
  { dmMsg = (Obj.magic (PBFTreply r)); dmDst =
    ((Obj.magic (PBFTclient (reply2client pbft_context r))) :: []) }

(** val send_pre_prepare :
    pBFTcontext -> pre_prepare -> name list -> directedMsg **)

let send_pre_prepare _ p n =
  { dmMsg = (Obj.magic (PBFTpre_prepare p)); dmDst = n }

(** val send_prepare : pBFTcontext -> prepare -> name list -> directedMsg **)

let send_prepare _ p n =
  { dmMsg = (Obj.magic (PBFTprepare p)); dmDst = n }

(** val send_commit : pBFTcontext -> commit -> name list -> directedMsg **)

let send_commit _ c n =
  { dmMsg = (Obj.magic (PBFTcommit c)); dmDst = n }

(** val send_checkpoint : pBFTcontext -> checkpoint -> name list -> directedMsg **)

let send_checkpoint _ c n =
  { dmMsg = (Obj.magic (PBFTcheckpoint c)); dmDst = n }

(** val send_debug : pBFTcontext -> rep -> char list -> directedMsg **)

let send_debug _ n s =
  { dmMsg = (Obj.magic (PBFTdebug (Debug (n, s)))); dmDst =
    ((Obj.magic (PBFTreplica n)) :: []) }

(** val send_view_change : pBFTcontext -> viewChange -> name list -> directedMsg **)

let send_view_change _ v n =
  { dmMsg = (Obj.magic (PBFTview_change v)); dmDst = n }

(** val send_new_view : pBFTcontext -> newView -> name list -> directedMsg **)

let send_new_view _ v n =
  { dmMsg = (Obj.magic (PBFTnew_view v)); dmDst = n }

(** val send_check_ready : pBFTcontext -> name list -> directedMsg **)

let send_check_ready _ n =
  { dmMsg = (Obj.magic PBFTcheck_ready); dmDst = n }

(** val send_check_bcast_new_view :
    pBFTcontext -> checkBCastNewView -> name list -> directedMsg **)

let send_check_bcast_new_view _ c n =
  { dmMsg = (Obj.magic (PBFTcheck_bcast_new_view c)); dmDst = n }

(** val send_start_timer : pBFTcontext -> startTimer -> name list -> directedMsg **)

let send_start_timer _ t n =
  { dmMsg = (Obj.magic (PBFTstart_timer t)); dmDst = n }

(** val send_expired_timer :
    pBFTcontext -> expiredTimer -> name list -> directedMsg **)

let send_expired_timer _ t n =
  { dmMsg = (Obj.magic (PBFTexpired_timer t)); dmDst = n }

(** val verify_one_auth_data :
    pBFTcontext -> pBFTauth -> rep -> local_key_map -> authenticatedData -> bool **)

let verify_one_auth_data pbft_context pbft_auth slf km a =
  verify_authenticated_data (pBFT_I_Data pbft_context) (pBFT_I_Key pbft_context)
    (pBFT_I_Node pbft_context) (pBFT_I_AuthTok pbft_context)
    (pBFT_I_AuthFun pbft_context pbft_auth) (pBFT_I_DataAuth pbft_context)
    (Obj.magic (PBFTreplica slf)) a km

(** val verify_list_auth_data :
    pBFTcontext -> pBFTauth -> rep -> local_key_map -> authenticatedData list ->
    bool **)

let rec verify_list_auth_data pbft_context pbft_auth slf km = function
| [] -> true
| entry :: entries ->
  (&&) (verify_one_auth_data pbft_context pbft_auth slf km entry)
    (verify_list_auth_data pbft_context pbft_auth slf km entries)

(** val verify_request :
    pBFTcontext -> pBFTauth -> rep -> local_key_map -> request -> bool **)

let verify_request pbft_context pbft_auth slf km = function
| Req (b, a) ->
  verify_authenticated_data (pBFT_I_Data pbft_context) (pBFT_I_Key pbft_context)
    (pBFT_I_Node pbft_context) (pBFT_I_AuthTok pbft_context)
    (pBFT_I_AuthFun pbft_context pbft_auth) (pBFT_I_DataAuth pbft_context)
    (Obj.magic (PBFTreplica slf)) { am_data = (Obj.magic (PBFTmsg_bare_request b));
    am_auth = a } km

(** val verify_pre_prepare :
    pBFTcontext -> pBFTauth -> rep -> local_key_map -> pre_prepare -> bool **)

let verify_pre_prepare pbft_context pbft_auth slf km p =
  verify_list_auth_data pbft_context pbft_auth slf km
    (pre_prepare2auth_data pbft_context p)

(** val verify_prepare :
    pBFTcontext -> pBFTauth -> rep -> local_key_map -> prepare -> bool **)

let verify_prepare pbft_context pbft_auth slf km p =
  verify_authenticated_data (pBFT_I_Data pbft_context) (pBFT_I_Key pbft_context)
    (pBFT_I_Node pbft_context) (pBFT_I_AuthTok pbft_context)
    (pBFT_I_AuthFun pbft_context pbft_auth) (pBFT_I_DataAuth pbft_context)
    (Obj.magic (PBFTreplica slf)) (prepare2auth_data pbft_context p) km

(** val verify_commit :
    pBFTcontext -> pBFTauth -> rep -> local_key_map -> commit -> bool **)

let verify_commit pbft_context pbft_auth slf km c =
  verify_authenticated_data (pBFT_I_Data pbft_context) (pBFT_I_Key pbft_context)
    (pBFT_I_Node pbft_context) (pBFT_I_AuthTok pbft_context)
    (pBFT_I_AuthFun pbft_context pbft_auth) (pBFT_I_DataAuth pbft_context)
    (Obj.magic (PBFTreplica slf)) (commit2auth_data pbft_context c) km

(** val verify_checkpoint :
    pBFTcontext -> pBFTauth -> rep -> local_key_map -> checkpoint -> bool **)

let verify_checkpoint pbft_context pbft_auth slf km c =
  verify_authenticated_data (pBFT_I_Data pbft_context) (pBFT_I_Key pbft_context)
    (pBFT_I_Node pbft_context) (pBFT_I_AuthTok pbft_context)
    (pBFT_I_AuthFun pbft_context pbft_auth) (pBFT_I_DataAuth pbft_context)
    (Obj.magic (PBFTreplica slf)) (checkpoint2auth_data pbft_context c) km

(** val verify_view_change :
    pBFTcontext -> pBFTauth -> rep -> local_key_map -> viewChange -> bool **)

let verify_view_change pbft_context pbft_auth slf km vc =
  verify_list_auth_data pbft_context pbft_auth slf km
    (view_change2auth_data pbft_context vc)

(** val verify_new_view :
    pBFTcontext -> pBFTauth -> rep -> local_key_map -> newView -> bool **)

let verify_new_view pbft_context pbft_auth slf km nv =
  verify_list_auth_data pbft_context pbft_auth slf km
    (new_view2auth_data pbft_context nv)

(** val mk_auth_pre_prepare :
    pBFTcontext -> pBFTauth -> view -> seqNum -> request list -> local_key_map ->
    pre_prepare **)

let mk_auth_pre_prepare pbft_context pbft_auth v s d keys =
  let bpp = Bare_pre_prepare (v, s, d) in
  let toks =
    authenticate (pBFT_I_Node pbft_context) (pBFT_I_Key pbft_context)
      (pBFT_I_AuthTok pbft_context) (pBFT_I_Data pbft_context)
      (pBFT_I_AuthFun pbft_context pbft_auth)
      (Obj.magic (PBFTmsg_bare_pre_prepare bpp)) keys
  in
  Pre_prepare (bpp, toks)

(** val mk_auth_new_view :
    pBFTcontext -> pBFTauth -> view -> viewChangeCert -> pre_prepare list ->
    pre_prepare list -> local_key_map -> newView **)

let mk_auth_new_view pbft_context pbft_auth v v0 oP nP keys =
  let bnv = Bare_new_view (v, v0, oP, nP) in
  let toks =
    authenticate (pBFT_I_Node pbft_context) (pBFT_I_Key pbft_context)
      (pBFT_I_AuthTok pbft_context) (pBFT_I_Data pbft_context)
      (pBFT_I_AuthFun pbft_context pbft_auth)
      (Obj.magic (PBFTmsg_bare_new_view bnv)) keys
  in
  New_view (bnv, toks)

(** val mk_auth_reply :
    pBFTcontext -> pBFTauth -> view -> timestamp -> client -> rep -> pBFTresult ->
    local_key_map -> reply **)

let mk_auth_reply pbft_context pbft_auth v t c i r keys =
  let brep = Bare_reply (v, t, c, i, r) in
  let toks =
    authenticate (pBFT_I_Node pbft_context) (pBFT_I_Key pbft_context)
      (pBFT_I_AuthTok pbft_context) (pBFT_I_Data pbft_context)
      (pBFT_I_AuthFun pbft_context pbft_auth) (Obj.magic (PBFTmsg_bare_reply brep))
      keys
  in
  Reply (brep, toks)

(** val mk_auth_checkpoint :
    pBFTcontext -> pBFTauth -> view -> seqNum -> pBFTdigest -> rep -> local_key_map
    -> checkpoint **)

let mk_auth_checkpoint pbft_context pbft_auth v n d i keys =
  let bcp = Bare_checkpoint (v, n, d, i) in
  let toks =
    authenticate (pBFT_I_Node pbft_context) (pBFT_I_Key pbft_context)
      (pBFT_I_AuthTok pbft_context) (pBFT_I_Data pbft_context)
      (pBFT_I_AuthFun pbft_context pbft_auth)
      (Obj.magic (PBFTmsg_bare_checkpoint bcp)) keys
  in
  Checkpoint (bcp, toks)

(** val mk_auth_view_change :
    pBFTcontext -> pBFTauth -> view -> seqNum -> stableChkPt -> checkpointCert ->
    preparedInfo list -> rep -> local_key_map -> viewChange **)

let mk_auth_view_change pbft_context pbft_auth v n s c p i keys =
  let bvc = Bare_view_change (v, n, s, c, p, i) in
  let toks =
    authenticate (pBFT_I_Node pbft_context) (pBFT_I_Key pbft_context)
      (pBFT_I_AuthTok pbft_context) (pBFT_I_Data pbft_context)
      (pBFT_I_AuthFun pbft_context pbft_auth)
      (Obj.magic (PBFTmsg_bare_view_change bvc)) keys
  in
  View_change (bvc, toks)

(** val prepare2commit :
    pBFTcontext -> pBFTauth -> rep -> local_key_map -> prepare -> commit **)

let prepare2commit pbft_context pbft_auth slf keys p =
  let bc = prepare2bare_commit pbft_context slf p in
  let toks =
    authenticate (pBFT_I_Node pbft_context) (pBFT_I_Key pbft_context)
      (pBFT_I_AuthTok pbft_context) (pBFT_I_Data pbft_context)
      (pBFT_I_AuthFun pbft_context pbft_auth) (Obj.magic (PBFTmsg_bare_commit bc))
      keys
  in
  Commit (bc, toks)

(** val pre_prepare2prepare :
    pBFTcontext -> pBFTauth -> rep -> local_key_map -> pre_prepare -> pBFTdigest ->
    prepare **)

let pre_prepare2prepare pbft_context pbft_auth n keys pp d =
  let bp = pre_prepare2bare_prepare pbft_context pp d n in
  let a =
    authenticate (pBFT_I_Node pbft_context) (pBFT_I_Key pbft_context)
      (pBFT_I_AuthTok pbft_context) (pBFT_I_Data pbft_context)
      (pBFT_I_AuthFun pbft_context pbft_auth) (Obj.magic (PBFTmsg_bare_prepare bp))
      keys
  in
  Prepare (bp, a)

(** val pre_prepare2commit :
    pBFTcontext -> pBFTauth -> rep -> local_key_map -> pre_prepare -> pBFTdigest ->
    commit **)

let pre_prepare2commit pbft_context pbft_auth slf keys pp d =
  let bc = pre_prepare2bare_commit pbft_context slf pp d in
  let toks =
    authenticate (pBFT_I_Node pbft_context) (pBFT_I_Key pbft_context)
      (pBFT_I_AuthTok pbft_context) (pBFT_I_Data pbft_context)
      (pBFT_I_AuthFun pbft_context pbft_auth) (Obj.magic (PBFTmsg_bare_commit bc))
      keys
  in
  Commit (bc, toks)

(** val mk_auth_null_req : pBFTcontext -> pBFTauth -> local_key_map -> request **)

let mk_auth_null_req pbft_context pbft_auth keys =
  Req (Null_req,
    (authenticate (pBFT_I_Node pbft_context) (pBFT_I_Key pbft_context)
      (pBFT_I_AuthTok pbft_context) (pBFT_I_Data pbft_context)
      (pBFT_I_AuthFun pbft_context pbft_auth)
      (Obj.magic (PBFTmsg_bare_request Null_req)) keys))

type pBFThash = { create_hash_messages : (pBFTmsg list -> pBFTdigest);
                  verify_hash_messages : (pBFTmsg list -> pBFTdigest -> bool);
                  create_hash_state_last_reply : (pBFTsm_state -> lastReplyState ->
                                                 pBFTdigest);
                  verify_hash_state_last_reply : (pBFTsm_state -> lastReplyState ->
                                                 pBFTdigest -> bool) }

(** val create_hash_messages :
    pBFTcontext -> pBFThash -> pBFTmsg list -> pBFTdigest **)

let create_hash_messages _ x = x.create_hash_messages

(** val create_hash_state_last_reply :
    pBFTcontext -> pBFThash -> pBFTsm_state -> lastReplyState -> pBFTdigest **)

let create_hash_state_last_reply _ x = x.create_hash_state_last_reply

type timestamps_of_clients = client -> timestamp

type pBFTprimaryState = { in_progress : int; request_buffer : request list;
                          client_info : timestamps_of_clients;
                          sequence_number : seqNum }

(** val in_progress : pBFTcontext -> pBFTprimaryState -> int **)

let in_progress _ x = x.in_progress

(** val request_buffer : pBFTcontext -> pBFTprimaryState -> request list **)

let request_buffer _ x = x.request_buffer

(** val client_info : pBFTcontext -> pBFTprimaryState -> timestamps_of_clients **)

let client_info _ x = x.client_info

(** val sequence_number : pBFTcontext -> pBFTprimaryState -> seqNum **)

let sequence_number _ x = x.sequence_number

(** val buffer_request :
    pBFTcontext -> pBFTprimaryState -> request -> pBFTprimaryState **)

let buffer_request _ s r =
  { in_progress = s.in_progress; request_buffer = (r :: s.request_buffer);
    client_info = s.client_info; sequence_number = s.sequence_number }

(** val update_client_info :
    pBFTcontext -> timestamps_of_clients -> client -> timestamp ->
    timestamps_of_clients **)

let update_client_info pbft_context f1 c t x =
  if pbft_context.client_deq x c then t else f1 x

(** val update_timestamp :
    pBFTcontext -> pBFTprimaryState -> client -> timestamp -> pBFTprimaryState **)

let update_timestamp pbft_context s c t =
  { in_progress = s.in_progress; request_buffer = s.request_buffer; client_info =
    (update_client_info pbft_context s.client_info c t); sequence_number =
    s.sequence_number }

(** val update_timestamp_op :
    pBFTcontext -> pBFTprimaryState -> client option -> timestamp ->
    pBFTprimaryState **)

let update_timestamp_op pbft_context s cop t =
  match cop with
  | Some c -> update_timestamp pbft_context s c t
  | None -> s

(** val increment_in_progress :
    pBFTcontext -> pBFTprimaryState -> pBFTprimaryState **)

let increment_in_progress _ s =
  { in_progress = (Pervasives.succ s.in_progress); request_buffer =
    s.request_buffer; client_info = s.client_info; sequence_number =
    s.sequence_number }

(** val increment_seq_num : pBFTcontext -> pBFTprimaryState -> pBFTprimaryState **)

let increment_seq_num _ s =
  { in_progress = s.in_progress; request_buffer = s.request_buffer; client_info =
    s.client_info; sequence_number = (next_seq s.sequence_number) }

(** val change_seq_num :
    pBFTcontext -> pBFTprimaryState -> seqNum -> pBFTprimaryState **)

let change_seq_num _ s sn =
  { in_progress = s.in_progress; request_buffer = s.request_buffer; client_info =
    s.client_info; sequence_number = (max_seq_num s.sequence_number sn) }

(** val reset_request_buffer :
    pBFTcontext -> pBFTprimaryState -> pBFTprimaryState **)

let reset_request_buffer _ s =
  { in_progress = s.in_progress; request_buffer = []; client_info = s.client_info;
    sequence_number = s.sequence_number }

(** val decrement_in_progress :
    pBFTcontext -> pBFTprimaryState -> pBFTprimaryState **)

let decrement_in_progress _ s =
  { in_progress = (pred s.in_progress); request_buffer = s.request_buffer;
    client_info = s.client_info; sequence_number = s.sequence_number }

(** val initial_primary_state : pBFTcontext -> pBFTprimaryState **)

let initial_primary_state _ =
  { in_progress = 0; request_buffer = []; client_info = (fun _ -> 0);
    sequence_number = initial_sequence_number }

type requestData =
| Request_data of view * seqNum * pBFTdigest

(** val request_data2view : pBFTcontext -> requestData -> view **)

let request_data2view _ = function
| Request_data (v, _, _) -> v

(** val request_data2seq : pBFTcontext -> requestData -> seqNum **)

let request_data2seq _ = function
| Request_data (_, s, _) -> s

(** val request_data2digest : pBFTcontext -> requestData -> pBFTdigest **)

let request_data2digest _ = function
| Request_data (_, _, d) -> d

(** val requestData_Deq : pBFTcontext -> requestData deq **)

let requestData_Deq pbft_context x y =
  let Request_data (v1, s1, d1) = x in
  let Request_data (v2, s2, d2) = y in
  let d = viewDeq v1 v2 in
  if d
  then let d0 = seqNumDeq s1 s2 in
       if d0 then pbft_context.pBFTdigestdeq d1 d2 else false
  else false

(** val eq_request_data : pBFTcontext -> requestData -> requestData -> bool **)

let eq_request_data pbft_context rd1 rd2 =
  if requestData_Deq pbft_context rd1 rd2 then true else false

(** val bare_pre_prepare2request_data :
    pBFTcontext -> bare_Pre_prepare -> pBFTdigest -> requestData **)

let bare_pre_prepare2request_data _ bpp d =
  let Bare_pre_prepare (v, s, _) = bpp in Request_data (v, s, d)

(** val pre_prepare2request_data :
    pBFTcontext -> pre_prepare -> pBFTdigest -> requestData **)

let pre_prepare2request_data pbft_context pp d =
  let Pre_prepare (b, _) = pp in bare_pre_prepare2request_data pbft_context b d

(** val bare_prepare2request_data : pBFTcontext -> bare_Prepare -> requestData **)

let bare_prepare2request_data _ = function
| Bare_prepare (v, s, d, _) -> Request_data (v, s, d)

(** val prepare2request_data : pBFTcontext -> prepare -> requestData **)

let prepare2request_data pbft_context = function
| Prepare (b, _) -> bare_prepare2request_data pbft_context b

(** val bare_commit2request_data : pBFTcontext -> bare_Commit -> requestData **)

let bare_commit2request_data _ = function
| Bare_commit (v, s, d, _) -> Request_data (v, s, d)

(** val commit2request_data : pBFTcontext -> commit -> requestData **)

let commit2request_data pbft_context = function
| Commit (b, _) -> bare_commit2request_data pbft_context b

type logEntryPrePrepareInfo =
| Pp_info_pre_prep of tokens * (request * reply option) list
| Pp_info_no_pre_prep

(** val pp_info_is_pre_prep : pBFTcontext -> logEntryPrePrepareInfo -> bool **)

let pp_info_is_pre_prep _ = function
| Pp_info_pre_prep (_, _) -> true
| Pp_info_no_pre_prep -> false

(** val pp_info2requests : pBFTcontext -> logEntryPrePrepareInfo -> request list **)

let pp_info2requests _ = function
| Pp_info_pre_prep (_, reqs) -> map fst reqs
| Pp_info_no_pre_prep -> []

type repToks = { rt_rep : rep; rt_tokens : tokens }

(** val rt_rep : pBFTcontext -> repToks -> rep **)

let rt_rep _ x = x.rt_rep

type pBFTlogEntry = { log_entry_request_data : requestData;
                      log_entry_pre_prepare_info : logEntryPrePrepareInfo;
                      log_entry_prepares : repToks list;
                      log_entry_commits : repToks list }

(** val log_entry_request_data : pBFTcontext -> pBFTlogEntry -> requestData **)

let log_entry_request_data _ x = x.log_entry_request_data

(** val log_entry_pre_prepare_info :
    pBFTcontext -> pBFTlogEntry -> logEntryPrePrepareInfo **)

let log_entry_pre_prepare_info _ x = x.log_entry_pre_prepare_info

(** val log_entry_prepares : pBFTcontext -> pBFTlogEntry -> repToks list **)

let log_entry_prepares _ x = x.log_entry_prepares

(** val log_entry_commits : pBFTcontext -> pBFTlogEntry -> repToks list **)

let log_entry_commits _ x = x.log_entry_commits

type pBFTcheckpointEntry = { cp_sn : seqNum; cp_d : pBFTdigest;
                             cp_checkpoint : checkpoint list;
                             cp_sm_state : pBFTsm_state;
                             cp_last_reply_state : lastReplyState }

(** val cp_sn : pBFTcontext -> pBFTcheckpointEntry -> seqNum **)

let cp_sn _ x = x.cp_sn

(** val cp_d : pBFTcontext -> pBFTcheckpointEntry -> pBFTdigest **)

let cp_d _ x = x.cp_d

(** val cp_checkpoint : pBFTcontext -> pBFTcheckpointEntry -> checkpoint list **)

let cp_checkpoint _ x = x.cp_checkpoint

(** val cp_sm_state : pBFTcontext -> pBFTcheckpointEntry -> pBFTsm_state **)

let cp_sm_state _ x = x.cp_sm_state

(** val cp_last_reply_state :
    pBFTcontext -> pBFTcheckpointEntry -> lastReplyState **)

let cp_last_reply_state _ x = x.cp_last_reply_state

(** val log_entry2requests : pBFTcontext -> pBFTlogEntry -> request list **)

let log_entry2requests pbft_context entry =
  pp_info2requests pbft_context entry.log_entry_pre_prepare_info

(** val is_pre_prepared_entry : pBFTcontext -> pBFTlogEntry -> bool **)

let is_pre_prepared_entry pbft_context entry =
  let { log_entry_request_data = _; log_entry_pre_prepare_info = nfo;
    log_entry_prepares = _; log_entry_commits = _ } = entry
  in
  pp_info_is_pre_prep pbft_context nfo

(** val is_prepared_entry : pBFTcontext -> pBFTlogEntry -> bool **)

let is_prepared_entry pbft_context entry =
  let { log_entry_request_data = _; log_entry_pre_prepare_info = nfo;
    log_entry_prepares = preps; log_entry_commits = _ } = entry
  in
  (&&)
    ((<=) (mul (Pervasives.succ (Pervasives.succ 0)) pbft_context.f)
      (length preps)) (pp_info_is_pre_prep pbft_context nfo)

(** val is_committed_entry : pBFTcontext -> pBFTlogEntry -> bool **)

let is_committed_entry pbft_context entry =
  let { log_entry_request_data = _; log_entry_pre_prepare_info = _;
    log_entry_prepares = _; log_entry_commits = comms } = entry
  in
  (&&) (is_prepared_entry pbft_context entry)
    ((<=)
      (add (mul (Pervasives.succ (Pervasives.succ 0)) pbft_context.f)
        (Pervasives.succ 0)) (length comms))

(** val is_stable_checkpoint_entry : pBFTcontext -> pBFTcheckpointEntry -> bool **)

let is_stable_checkpoint_entry pbft_context entry =
  (<=) (add pbft_context.f (Pervasives.succ 0)) (length entry.cp_checkpoint)

(** val pre_prepare2pp_info :
    pBFTcontext -> pre_prepare -> logEntryPrePrepareInfo **)

let pre_prepare2pp_info _ = function
| Pre_prepare (b, a) ->
  let Bare_pre_prepare (_, _, reqs) = b in
  Pp_info_pre_prep (a, (map (fun r -> (r, None)) reqs))

(** val pre_prepare2entry :
    pBFTcontext -> pre_prepare -> pBFTdigest -> pBFTlogEntry **)

let pre_prepare2entry pbft_context pp d =
  { log_entry_request_data = (pre_prepare2request_data pbft_context pp d);
    log_entry_pre_prepare_info = (pre_prepare2pp_info pbft_context pp);
    log_entry_prepares = []; log_entry_commits = [] }

(** val prepare2rep_toks : pBFTcontext -> prepare -> repToks **)

let prepare2rep_toks _ = function
| Prepare (b, a) ->
  let Bare_prepare (_, _, _, i) = b in { rt_rep = i; rt_tokens = a }

(** val commit2rep_toks : pBFTcontext -> commit -> repToks **)

let commit2rep_toks _ = function
| Commit (b, a) ->
  let Bare_commit (_, _, _, i) = b in { rt_rep = i; rt_tokens = a }

(** val mkNewLogEntryWithPrepare :
    pBFTcontext -> pre_prepare -> pBFTdigest -> repToks -> pBFTlogEntry **)

let mkNewLogEntryWithPrepare pbft_context pp d rt =
  { log_entry_request_data = (pre_prepare2request_data pbft_context pp d);
    log_entry_pre_prepare_info = (pre_prepare2pp_info pbft_context pp);
    log_entry_prepares = (rt :: []); log_entry_commits = [] }

(** val mkNewLogEntryFromPrepare : pBFTcontext -> prepare -> pBFTlogEntry **)

let mkNewLogEntryFromPrepare pbft_context p =
  { log_entry_request_data = (prepare2request_data pbft_context p);
    log_entry_pre_prepare_info = Pp_info_no_pre_prep; log_entry_prepares =
    ((prepare2rep_toks pbft_context p) :: []); log_entry_commits = [] }

(** val mkNewLogEntryFromCommit : pBFTcontext -> commit -> pBFTlogEntry **)

let mkNewLogEntryFromCommit pbft_context c =
  { log_entry_request_data = (commit2request_data pbft_context c);
    log_entry_pre_prepare_info = Pp_info_no_pre_prep; log_entry_prepares = [];
    log_entry_commits = ((commit2rep_toks pbft_context c) :: []) }

(** val mkNewCheckpointEntryFromCheckpoint :
    pBFTcontext -> checkpoint -> pBFTsm_state -> lastReplyState ->
    pBFTcheckpointEntry **)

let mkNewCheckpointEntryFromCheckpoint pbft_context c sm lr =
  { cp_sn = (checkpoint2seq pbft_context c); cp_d =
    (checkpoint2digest pbft_context c); cp_checkpoint = (c :: []); cp_sm_state =
    sm; cp_last_reply_state = lr }

(** val in_list_rep_toks : pBFTcontext -> rep -> repToks list -> bool **)

let in_list_rep_toks pbft_context i l =
  existsb (fun rt -> if pbft_context.rep_deq i rt.rt_rep then true else false) l

(** val find_rep_toks_in_list :
    pBFTcontext -> rep -> repToks list -> repToks option **)

let rec find_rep_toks_in_list pbft_context i = function
| [] -> None
| rt :: rts ->
  if pbft_context.rep_deq i rt.rt_rep
  then Some rt
  else find_rep_toks_in_list pbft_context i rts

(** val add_checkpoint2checkpoint :
    pBFTcontext -> checkpoint -> checkpoint list -> checkpoint list option **)

let rec add_checkpoint2checkpoint pbft_context c = function
| [] -> Some (c :: [])
| c' :: cs0 ->
  if pbft_context.rep_deq (checkpoint2sender pbft_context c')
       (checkpoint2sender pbft_context c)
  then None
  else (match add_checkpoint2checkpoint pbft_context c cs0 with
        | Some l -> Some (c' :: l)
        | None -> None)

type add_commit_status =
| Add_commit_status_already_in
| Add_commit_status_added of repToks
| Add_commit_status_not_prepared
| Add_commit_status_na

(** val add_commit_if_prepared :
    pBFTcontext -> rep -> logEntryPrePrepareInfo -> repToks list -> repToks list ->
    (unit -> repToks) -> add_commit_status * repToks list **)

let add_commit_if_prepared pbft_context i nfo preps comms fc =
  if pp_info_is_pre_prep pbft_context nfo
  then if (<=) (mul (Pervasives.succ (Pervasives.succ 0)) pbft_context.f)
            (length preps)
       then if in_list_rep_toks pbft_context i comms
            then (Add_commit_status_already_in, comms)
            else let comm = fc () in
                 ((Add_commit_status_added comm), (comm :: comms))
       else (Add_commit_status_not_prepared, comms)
  else (Add_commit_status_not_prepared, comms)

(** val request_data_and_rep_toks2prepare :
    pBFTcontext -> requestData -> repToks -> prepare **)

let request_data_and_rep_toks2prepare _ rd rt =
  let Request_data (v, s, d) = rd in
  let { rt_rep = i; rt_tokens = a } = rt in
  Prepare ((Bare_prepare (v, s, d, i)), a)

(** val request_data_and_rep_toks2commit :
    pBFTcontext -> requestData -> repToks -> commit **)

let request_data_and_rep_toks2commit _ rd rt =
  let Request_data (v, s, d) = rd in
  let { rt_rep = i; rt_tokens = a } = rt in Commit ((Bare_commit (v, s, d, i)), a)

type add_prepare_status =
| Add_prepare_status_already_in
| Add_prepare_status_added of repToks
| Add_prepare_status_na

(** val add_prepare_if_not_enough :
    pBFTcontext -> rep -> repToks list -> (unit -> repToks) ->
    add_prepare_status * repToks list **)

let add_prepare_if_not_enough pbft_context i preps fp =
  if in_list_rep_toks pbft_context i preps
  then (Add_prepare_status_already_in, preps)
  else let prep = fp () in ((Add_prepare_status_added prep), (prep :: preps))

type generatedInfo = { gi_prepare : add_prepare_status;
                       gi_commit : add_commit_status; gi_entry : pBFTlogEntry }

(** val gi_entry : pBFTcontext -> generatedInfo -> pBFTlogEntry **)

let gi_entry _ x = x.gi_entry

(** val fill_out_pp_info_with_prepare :
    pBFTcontext -> rep -> pBFTlogEntry -> pre_prepare -> (unit -> repToks) -> (unit
    -> repToks) -> generatedInfo option **)

let fill_out_pp_info_with_prepare pbft_context i entry pp fp fc =
  let { log_entry_request_data = rd; log_entry_pre_prepare_info =
    log_entry_pre_prepare_info0; log_entry_prepares = preps; log_entry_commits =
    comms } = entry
  in
  (match log_entry_pre_prepare_info0 with
   | Pp_info_pre_prep (_, _) -> None
   | Pp_info_no_pre_prep ->
     let newinfo = pre_prepare2pp_info pbft_context pp in
     let (prepop, new_preps) = add_prepare_if_not_enough pbft_context i preps fp in
     let (commop, new_comms) =
       add_commit_if_prepared pbft_context i newinfo new_preps comms fc
     in
     Some { gi_prepare = prepop; gi_commit = commop; gi_entry =
     { log_entry_request_data = rd; log_entry_pre_prepare_info = newinfo;
     log_entry_prepares = new_preps; log_entry_commits = new_comms } })

(** val add_commit2entry :
    pBFTcontext -> pBFTlogEntry -> commit -> pBFTlogEntry option **)

let add_commit2entry pbft_context entry c =
  let { log_entry_request_data = bpp; log_entry_pre_prepare_info = nfo;
    log_entry_prepares = preps; log_entry_commits = comms } = entry
  in
  let rt = commit2rep_toks pbft_context c in
  let i = commit2sender pbft_context c in
  if in_list_rep_toks pbft_context i comms
  then None
  else Some { log_entry_request_data = bpp; log_entry_pre_prepare_info = nfo;
         log_entry_prepares = preps; log_entry_commits = (rt :: comms) }

(** val add_checkpoint2entry :
    pBFTcontext -> pBFTcheckpointEntry -> checkpoint -> pBFTcheckpointEntry option **)

let add_checkpoint2entry pbft_context entry c =
  let { cp_sn = sn; cp_d = d; cp_checkpoint = chs; cp_sm_state = sm_state1;
    cp_last_reply_state = lr_state } = entry
  in
  (match add_checkpoint2checkpoint pbft_context c chs with
   | Some new_chs ->
     Some { cp_sn = sn; cp_d = d; cp_checkpoint = new_chs; cp_sm_state = sm_state1;
       cp_last_reply_state = lr_state }
   | None -> None)

(** val add_prepare2entry :
    pBFTcontext -> rep -> pBFTlogEntry -> prepare -> (unit -> repToks) ->
    generatedInfo option **)

let add_prepare2entry pbft_context slf entry p fc =
  let { log_entry_request_data = bpp; log_entry_pre_prepare_info = nfo;
    log_entry_prepares = preps; log_entry_commits = comms } = entry
  in
  let fp = fun _ -> prepare2rep_toks pbft_context p in
  let i = prepare2sender pbft_context p in
  let (prepop, new_preps) = add_prepare_if_not_enough pbft_context i preps fp in
  let (commop, new_comms) =
    add_commit_if_prepared pbft_context slf nfo new_preps comms fc
  in
  Some { gi_prepare = prepop; gi_commit = commop; gi_entry =
  { log_entry_request_data = bpp; log_entry_pre_prepare_info = nfo;
  log_entry_prepares = new_preps; log_entry_commits = new_comms } }

(** val combine_replies :
    pBFTcontext -> (request * reply option) list -> reply option list ->
    (request * reply option) list **)

let rec combine_replies pbft_context l reps0 =
  match l with
  | [] ->
    (match reps0 with
     | [] -> []
     | _ :: _ -> l)
  | p :: rs ->
    let (r, _) = p in
    (match reps0 with
     | [] -> l
     | rep0 :: reps1 -> (r, rep0) :: (combine_replies pbft_context rs reps1))

(** val add_replies2info :
    pBFTcontext -> logEntryPrePrepareInfo -> reply option list ->
    logEntryPrePrepareInfo **)

let add_replies2info pbft_context nfo reps0 =
  match nfo with
  | Pp_info_pre_prep (a, reqs) ->
    Pp_info_pre_prep (a, (combine_replies pbft_context reqs reps0))
  | Pp_info_no_pre_prep -> Pp_info_no_pre_prep

(** val add_replies2entry :
    pBFTcontext -> pBFTlogEntry -> reply option list -> pBFTlogEntry **)

let add_replies2entry pbft_context entry reps0 =
  let { log_entry_request_data = bpp; log_entry_pre_prepare_info = nfo;
    log_entry_prepares = prepares; log_entry_commits = commits } = entry
  in
  { log_entry_request_data = bpp; log_entry_pre_prepare_info =
  (add_replies2info pbft_context nfo reps0); log_entry_prepares = prepares;
  log_entry_commits = commits }

type pBFTlog = pBFTlogEntry list

type pBFTcheckpoint_log = pBFTcheckpointEntry list

type pBFTcheckpointState = { chk_state_stable : pBFTcheckpointEntry;
                             chk_state_others : pBFTcheckpoint_log }

(** val chk_state_stable :
    pBFTcontext -> pBFTcheckpointState -> pBFTcheckpointEntry **)

let chk_state_stable _ x = x.chk_state_stable

(** val chk_state_others :
    pBFTcontext -> pBFTcheckpointState -> pBFTcheckpoint_log **)

let chk_state_others _ x = x.chk_state_others

(** val is_commit_for_entry : pBFTcontext -> pBFTlogEntry -> commit -> bool **)

let is_commit_for_entry pbft_context entry c =
  eq_request_data pbft_context entry.log_entry_request_data
    (commit2request_data pbft_context c)

(** val similar_sn_and_checkpoint_sn :
    pBFTcontext -> seqNum -> pBFTdigest -> checkpoint -> bool **)

let similar_sn_and_checkpoint_sn pbft_context sn d c =
  if seqNumDeq sn (checkpoint2seq pbft_context c)
  then if pbft_context.pBFTdigestdeq d (checkpoint2digest pbft_context c)
       then true
       else false
  else false

(** val is_checkpoint_for_entry :
    pBFTcontext -> pBFTcheckpointEntry -> checkpoint -> bool **)

let is_checkpoint_for_entry pbft_context entry c =
  similar_sn_and_checkpoint_sn pbft_context entry.cp_sn entry.cp_d c

(** val is_prepare_for_entry : pBFTcontext -> pBFTlogEntry -> prepare -> bool **)

let is_prepare_for_entry pbft_context entry p =
  eq_request_data pbft_context entry.log_entry_request_data
    (prepare2request_data pbft_context p)

(** val own_view_change2initial_entry :
    pBFTcontext -> viewChange -> pBFTviewChangeEntry **)

let own_view_change2initial_entry pbft_context vc =
  { vce_view = (view_change2view pbft_context vc); vce_view_change = (Some vc);
    vce_view_changes = []; vce_new_view = None }

(** val other_view_change2initial_entry :
    pBFTcontext -> viewChange -> pBFTviewChangeEntry **)

let other_view_change2initial_entry pbft_context vc =
  { vce_view = (view_change2view pbft_context vc); vce_view_change = None;
    vce_view_changes = (vc :: []); vce_new_view = None }

(** val add_own_view_change2entry :
    pBFTcontext -> viewChange -> pBFTviewChangeEntry -> pBFTviewChangeEntry **)

let add_own_view_change2entry _ vc e =
  let { vce_view = v; vce_view_change = vce_view_change0; vce_view_changes = vcs;
    vce_new_view = nv } = e
  in
  (match vce_view_change0 with
   | Some _ -> e
   | None ->
     { vce_view = v; vce_view_change = (Some vc); vce_view_changes = vcs;
       vce_new_view = nv })

type pBFTviewChangeState = pBFTviewChangeEntry list

(** val initial_view_change_state : pBFTcontext -> pBFTviewChangeState **)

let initial_view_change_state _ =
  []

(** val add_own_view_change_to_state :
    pBFTcontext -> viewChange -> pBFTviewChangeEntry list ->
    (pBFTviewChangeEntry * int) * pBFTviewChangeState **)

let rec add_own_view_change_to_state pbft_context vc = function
| [] ->
  let entry = own_view_change2initial_entry pbft_context vc in
  ((entry, 0), (entry :: []))
| entry :: entries ->
  if viewDeq (view_change2view pbft_context vc) entry.vce_view
  then let new_entry = add_own_view_change2entry pbft_context vc entry in
       ((new_entry, 0), (new_entry :: entries))
  else let (p, new_entries) = add_own_view_change_to_state pbft_context vc entries
       in
       let (changed_entry, changed_entry_pos) = p in
       ((changed_entry, (Pervasives.succ changed_entry_pos)),
       (entry :: new_entries))

(** val start_view_change :
    pBFTcontext -> viewChange -> pBFTviewChangeState ->
    (pBFTviewChangeEntry * int) * pBFTviewChangeState **)

let start_view_change pbft_context vc s =
  add_own_view_change_to_state pbft_context vc s

(** val add_view_change2view_changes :
    pBFTcontext -> viewChange -> viewChange list -> viewChange list option **)

let rec add_view_change2view_changes pbft_context vc = function
| [] -> Some (vc :: [])
| vc' :: vcs0 ->
  if pbft_context.rep_deq (view_change2sender pbft_context vc')
       (view_change2sender pbft_context vc)
  then None
  else (match add_view_change2view_changes pbft_context vc vcs0 with
        | Some l -> Some (vc' :: l)
        | None -> None)

(** val add_other_view_change2entry :
    pBFTcontext -> viewChange -> pBFTviewChangeEntry -> pBFTviewChangeEntry option **)

let add_other_view_change2entry pbft_context vc e =
  let { vce_view = v; vce_view_change = ovc; vce_view_changes = vcs; vce_new_view =
    nv } = e
  in
  (match add_view_change2view_changes pbft_context vc vcs with
   | Some new_vcs ->
     Some { vce_view = v; vce_view_change = ovc; vce_view_changes = new_vcs;
       vce_new_view = nv }
   | None -> None)

(** val add_other_view_change :
    pBFTcontext -> viewChange -> pBFTviewChangeState ->
    ((pBFTviewChangeEntry * int) * pBFTviewChangeState) option **)

let rec add_other_view_change pbft_context vc = function
| [] ->
  let entry = other_view_change2initial_entry pbft_context vc in
  Some ((entry, 0), (entry :: []))
| entry :: entries ->
  if viewDeq (view_change2view pbft_context vc) entry.vce_view
  then (match add_other_view_change2entry pbft_context vc entry with
        | Some new_entry -> Some ((new_entry, 0), (new_entry :: entries))
        | None -> None)
  else (match add_other_view_change pbft_context vc entries with
        | Some p -> let (p0, new_entries) = p in Some (p0, (entry :: new_entries))
        | None -> None)

(** val update_last_reply_entry_timestamp_and_result :
    pBFTcontext -> lastReplyEntry -> timestamp -> pBFTresult -> lastReplyEntry **)

let update_last_reply_entry_timestamp_and_result _ e t r =
  let { lre_client = c; lre_timestamp = _; lre_reply = _ } = e in
  { lre_client = c; lre_timestamp = t; lre_reply = (Some r) }

(** val find_last_reply_entry_corresponding_to_client :
    pBFTcontext -> lastReplyState -> client -> lastReplyEntry option **)

let rec find_last_reply_entry_corresponding_to_client pbft_context lrs c =
  match lrs with
  | [] -> None
  | entry :: entries ->
    if pbft_context.client_deq c entry.lre_client
    then Some entry
    else find_last_reply_entry_corresponding_to_client pbft_context entries c

(** val update_last_reply_timestamp_and_result :
    pBFTcontext -> lastReplyState -> client -> timestamp -> pBFTresult ->
    lastReplyState **)

let rec update_last_reply_timestamp_and_result pbft_context s c t r =
  match s with
  | [] -> []
  | entry :: entries ->
    if pbft_context.client_deq c entry.lre_client
    then (update_last_reply_entry_timestamp_and_result pbft_context entry t r) :: entries
    else entry :: (update_last_reply_timestamp_and_result pbft_context entries c t
                    r)

type pBFTstate = { local_keys : local_key_map; current_view : view; log : pBFTlog;
                   cp_state : pBFTcheckpointState; sm_state0 : pBFTsm_state;
                   next_to_execute : seqNum; ready : seqNum list;
                   last_reply_state : lastReplyState;
                   view_change_state : pBFTviewChangeState;
                   primary_state : pBFTprimaryState }

(** val local_keys : pBFTcontext -> pBFTstate -> local_key_map **)

let local_keys _ x = x.local_keys

(** val current_view : pBFTcontext -> pBFTstate -> view **)

let current_view _ x = x.current_view

(** val log : pBFTcontext -> pBFTstate -> pBFTlog **)

let log _ x = x.log

(** val cp_state : pBFTcontext -> pBFTstate -> pBFTcheckpointState **)

let cp_state _ x = x.cp_state

(** val sm_state0 : pBFTcontext -> pBFTstate -> pBFTsm_state **)

let sm_state0 _ x = x.sm_state0

(** val next_to_execute : pBFTcontext -> pBFTstate -> seqNum **)

let next_to_execute _ x = x.next_to_execute

(** val ready : pBFTcontext -> pBFTstate -> seqNum list **)

let ready _ x = x.ready

(** val last_reply_state : pBFTcontext -> pBFTstate -> lastReplyState **)

let last_reply_state _ x = x.last_reply_state

(** val view_change_state : pBFTcontext -> pBFTstate -> pBFTviewChangeState **)

let view_change_state _ x = x.view_change_state

(** val primary_state : pBFTcontext -> pBFTstate -> pBFTprimaryState **)

let primary_state _ x = x.primary_state

(** val initial_ready : seqNum list **)

let initial_ready =
  []

(** val initial_next_to_execute : seqNum **)

let initial_next_to_execute =
  Pervasives.succ 0

(** val other_replicas : pBFTcontext -> rep -> rep list **)

let other_replicas pbft_context r =
  remove_elt pbft_context.rep_deq r (reps pbft_context)

(** val other_names : pBFTcontext -> rep -> name list **)

let other_names pbft_context r =
  map (Obj.magic (fun x -> PBFTreplica x)) (other_replicas pbft_context r)

(** val initial_last_reply : pBFTcontext -> lastReplyState **)

let initial_last_reply pbft_context =
  map (fun c -> { lre_client = c; lre_timestamp = 0; lre_reply = None })
    (clients pbft_context)

(** val initial_checkpoint_entry :
    pBFTcontext -> pBFThash -> pBFTcheckpointEntry **)

let initial_checkpoint_entry pbft_context pbft_hash =
  let smst = pbft_context.pBFTsm_initial_state in
  let lastr = initial_last_reply pbft_context in
  let digest0 = pbft_hash.create_hash_state_last_reply smst lastr in
  { cp_sn = initial_sequence_number; cp_d = digest0; cp_checkpoint = [];
  cp_sm_state = smst; cp_last_reply_state = lastr }

(** val initial_checkpoint_state :
    pBFTcontext -> pBFThash -> pBFTcheckpointState **)

let initial_checkpoint_state pbft_context pbft_hash =
  { chk_state_stable = (initial_checkpoint_entry pbft_context pbft_hash);
    chk_state_others = [] }

(** val initial_state : pBFTcontext -> pBFTkeys -> pBFThash -> rep -> pBFTstate **)

let initial_state pbft_context pbft_keys pbft_hash r =
  { local_keys = (initial_keys pbft_context pbft_keys (Obj.magic (PBFTreplica r)));
    current_view = initial_view; log = []; cp_state =
    (initial_checkpoint_state pbft_context pbft_hash); sm_state0 =
    pbft_context.pBFTsm_initial_state; next_to_execute = initial_next_to_execute;
    ready = initial_ready; last_reply_state = (initial_last_reply pbft_context);
    view_change_state = (initial_view_change_state pbft_context); primary_state =
    (initial_primary_state pbft_context) }

(** val update_primary_state :
    pBFTcontext -> pBFTstate -> pBFTprimaryState -> pBFTstate **)

let update_primary_state _ s ps =
  { local_keys = s.local_keys; current_view = s.current_view; log = s.log;
    cp_state = s.cp_state; sm_state0 = s.sm_state0; next_to_execute =
    s.next_to_execute; ready = s.ready; last_reply_state = s.last_reply_state;
    view_change_state = s.view_change_state; primary_state = ps }

(** val increment_view : pBFTcontext -> pBFTstate -> pBFTstate **)

let increment_view _ s =
  { local_keys = s.local_keys; current_view = (next_view s.current_view); log =
    s.log; cp_state = s.cp_state; sm_state0 = s.sm_state0; next_to_execute =
    s.next_to_execute; ready = s.ready; last_reply_state = s.last_reply_state;
    view_change_state = s.view_change_state; primary_state = s.primary_state }

(** val update_view : pBFTcontext -> pBFTstate -> view -> pBFTstate **)

let update_view _ s v =
  { local_keys = s.local_keys; current_view = (max_view s.current_view v); log =
    s.log; cp_state = s.cp_state; sm_state0 = s.sm_state0; next_to_execute =
    s.next_to_execute; ready = s.ready; last_reply_state = s.last_reply_state;
    view_change_state = s.view_change_state; primary_state = s.primary_state }

(** val change_view_change_state :
    pBFTcontext -> pBFTstate -> pBFTviewChangeState -> pBFTstate **)

let change_view_change_state _ s vcstate =
  { local_keys = s.local_keys; current_view = s.current_view; log = s.log;
    cp_state = s.cp_state; sm_state0 = s.sm_state0; next_to_execute =
    s.next_to_execute; ready = s.ready; last_reply_state = s.last_reply_state;
    view_change_state = vcstate; primary_state = s.primary_state }

(** val similar_entry_and_pre_prepare :
    pBFTcontext -> pBFTlogEntry -> pre_prepare -> pBFTdigest -> bool **)

let similar_entry_and_pre_prepare pbft_context entry pp d =
  let { log_entry_request_data = rd; log_entry_pre_prepare_info = _;
    log_entry_prepares = _; log_entry_commits = _ } = entry
  in
  eq_request_data pbft_context rd (pre_prepare2request_data pbft_context pp d)

(** val change_pre_prepare_info :
    pBFTcontext -> pre_prepare -> logEntryPrePrepareInfo -> logEntryPrePrepareInfo **)

let change_pre_prepare_info pbft_context pp nfo = match nfo with
| Pp_info_pre_prep (_, _) -> nfo
| Pp_info_no_pre_prep -> pre_prepare2pp_info pbft_context pp

(** val change_pre_prepare_info_of_entry :
    pBFTcontext -> pre_prepare -> pBFTlogEntry -> pBFTlogEntry **)

let change_pre_prepare_info_of_entry pbft_context pp entry =
  let { log_entry_request_data = rd; log_entry_pre_prepare_info = nfo;
    log_entry_prepares = preps; log_entry_commits = comms } = entry
  in
  { log_entry_request_data = rd; log_entry_pre_prepare_info =
  (change_pre_prepare_info pbft_context pp nfo); log_entry_prepares = preps;
  log_entry_commits = comms }

(** val add_new_pre_prepare2log :
    pBFTcontext -> pre_prepare -> pBFTdigest -> pBFTlog -> pBFTlog **)

let rec add_new_pre_prepare2log pbft_context pp d = function
| [] -> (pre_prepare2entry pbft_context pp d) :: []
| entry :: entries ->
  if similar_entry_and_pre_prepare pbft_context entry pp d
  then (change_pre_prepare_info_of_entry pbft_context pp entry) :: entries
  else entry :: (add_new_pre_prepare2log pbft_context pp d entries)

(** val log_new_pre_prepare :
    pBFTcontext -> pBFTstate -> pre_prepare -> pBFTdigest -> pBFTstate **)

let log_new_pre_prepare pbft_context s pp d =
  { local_keys = s.local_keys; current_view = s.current_view; log =
    (add_new_pre_prepare2log pbft_context pp d s.log); cp_state = s.cp_state;
    sm_state0 = s.sm_state0; next_to_execute = s.next_to_execute; ready = s.ready;
    last_reply_state = s.last_reply_state; view_change_state = s.view_change_state;
    primary_state = s.primary_state }

(** val log_pre_prepares :
    pBFTcontext -> pBFTlog -> seqNum -> (pre_prepare * pBFTdigest) list -> pBFTlog **)

let rec log_pre_prepares pbft_context l lwm = function
| [] -> l
| p0 :: pps ->
  let (pp, d) = p0 in
  if Nat.ltb (seqnum2nat lwm) (seqnum2nat (pre_prepare2seq pbft_context pp))
  then log_pre_prepares pbft_context (add_new_pre_prepare2log pbft_context pp d l)
         lwm pps
  else log_pre_prepares pbft_context l lwm pps

(** val low_water_mark : pBFTcontext -> pBFTstate -> seqNum **)

let low_water_mark _ state =
  state.cp_state.chk_state_stable.cp_sn

(** val log_pre_prepares_of_new_view :
    pBFTcontext -> pBFTstate -> (pre_prepare * pBFTdigest) list -> pBFTstate **)

let log_pre_prepares_of_new_view pbft_context s p =
  { local_keys = s.local_keys; current_view = s.current_view; log =
    (log_pre_prepares pbft_context s.log (low_water_mark pbft_context s) p);
    cp_state = s.cp_state; sm_state0 = s.sm_state0; next_to_execute =
    s.next_to_execute; ready = s.ready; last_reply_state = s.last_reply_state;
    view_change_state = s.view_change_state; primary_state = s.primary_state }

(** val add_new_view_to_entry :
    pBFTcontext -> pBFTviewChangeEntry -> newView -> pBFTviewChangeEntry **)

let add_new_view_to_entry _ e nv =
  let { vce_view = v; vce_view_change = ovc; vce_view_changes = vcs; vce_new_view =
    vce_new_view0 } = e
  in
  (match vce_new_view0 with
   | Some _ -> e
   | None ->
     { vce_view = v; vce_view_change = ovc; vce_view_changes = vcs; vce_new_view =
       (Some nv) })

(** val new_view2entry : pBFTcontext -> newView -> pBFTviewChangeEntry **)

let new_view2entry pbft_context nv =
  { vce_view = (new_view2view pbft_context nv); vce_view_change = None;
    vce_view_changes = []; vce_new_view = (Some nv) }

(** val log_new_view :
    pBFTcontext -> pBFTviewChangeState -> newView -> pBFTviewChangeState **)

let rec log_new_view pbft_context state nv =
  match state with
  | [] -> (new_view2entry pbft_context nv) :: []
  | entry :: entries ->
    if viewDeq (new_view2view pbft_context nv) entry.vce_view
    then (add_new_view_to_entry pbft_context entry nv) :: entries
    else entry :: (log_new_view pbft_context entries nv)

(** val log_new_view_and_entry :
    pBFTcontext -> pBFTviewChangeState -> newView -> pBFTviewChangeEntry ->
    pBFTviewChangeState **)

let rec log_new_view_and_entry pbft_context state nv e =
  match state with
  | [] -> (add_new_view_to_entry pbft_context e nv) :: []
  | entry :: entries ->
    if viewDeq (new_view2view pbft_context nv) entry.vce_view
    then (add_new_view_to_entry pbft_context e nv) :: entries
    else entry :: (log_new_view_and_entry pbft_context entries nv e)

(** val log_new_view_state : pBFTcontext -> pBFTstate -> newView -> pBFTstate **)

let log_new_view_state pbft_context s nv =
  { local_keys = s.local_keys; current_view = s.current_view; log = s.log;
    cp_state = s.cp_state; sm_state0 = s.sm_state0; next_to_execute =
    s.next_to_execute; ready = s.ready; last_reply_state = s.last_reply_state;
    view_change_state = (log_new_view pbft_context s.view_change_state nv);
    primary_state = s.primary_state }

(** val log_new_view_and_entry_state :
    pBFTcontext -> pBFTstate -> newView -> pBFTviewChangeEntry -> pBFTstate **)

let log_new_view_and_entry_state pbft_context s nv e =
  { local_keys = s.local_keys; current_view = s.current_view; log = s.log;
    cp_state = s.cp_state; sm_state0 = s.sm_state0; next_to_execute =
    s.next_to_execute; ready = s.ready; last_reply_state = s.last_reply_state;
    view_change_state =
    (log_new_view_and_entry pbft_context s.view_change_state nv e); primary_state =
    s.primary_state }

(** val add2ready : seqNum list -> seqNum -> seqNum list **)

let rec add2ready l s =
  match l with
  | [] -> s :: []
  | sn :: sns ->
    if seqNumLt s sn
    then s :: (sn :: sns)
    else if seqNumDeq s sn then l else sn :: (add2ready sns s)

(** val add_to_ready : pBFTcontext -> pBFTstate -> seqNum -> pBFTstate **)

let add_to_ready _ s e =
  { local_keys = s.local_keys; current_view = s.current_view; log = s.log;
    cp_state = s.cp_state; sm_state0 = s.sm_state0; next_to_execute =
    s.next_to_execute; ready = (add2ready s.ready e); last_reply_state =
    s.last_reply_state; view_change_state = s.view_change_state; primary_state =
    s.primary_state }

(** val update_ready : pBFTcontext -> pBFTstate -> seqNum list -> pBFTstate **)

let update_ready _ s l =
  { local_keys = s.local_keys; current_view = s.current_view; log = s.log;
    cp_state = s.cp_state; sm_state0 = s.sm_state0; next_to_execute =
    s.next_to_execute; ready = l; last_reply_state = s.last_reply_state;
    view_change_state = s.view_change_state; primary_state = s.primary_state }

(** val increment_next_to_execute : pBFTcontext -> pBFTstate -> pBFTstate **)

let increment_next_to_execute _ s =
  { local_keys = s.local_keys; current_view = s.current_view; log = s.log;
    cp_state = s.cp_state; sm_state0 = s.sm_state0; next_to_execute =
    (next_seq s.next_to_execute); ready = s.ready; last_reply_state =
    s.last_reply_state; view_change_state = s.view_change_state; primary_state =
    s.primary_state }

(** val change_next_to_execute : pBFTcontext -> pBFTstate -> seqNum -> pBFTstate **)

let change_next_to_execute _ s sn =
  { local_keys = s.local_keys; current_view = s.current_view; log = s.log;
    cp_state = s.cp_state; sm_state0 = s.sm_state0; next_to_execute = sn; ready =
    s.ready; last_reply_state = s.last_reply_state; view_change_state =
    s.view_change_state; primary_state = s.primary_state }

(** val change_sm_state : pBFTcontext -> pBFTstate -> pBFTsm_state -> pBFTstate **)

let change_sm_state _ s smstate =
  { local_keys = s.local_keys; current_view = s.current_view; log = s.log;
    cp_state = s.cp_state; sm_state0 = smstate; next_to_execute =
    s.next_to_execute; ready = s.ready; last_reply_state = s.last_reply_state;
    view_change_state = s.view_change_state; primary_state = s.primary_state }

(** val change_last_reply_state :
    pBFTcontext -> pBFTstate -> lastReplyState -> pBFTstate **)

let change_last_reply_state _ s lastr =
  { local_keys = s.local_keys; current_view = s.current_view; log = s.log;
    cp_state = s.cp_state; sm_state0 = s.sm_state0; next_to_execute =
    s.next_to_execute; ready = s.ready; last_reply_state = lastr;
    view_change_state = s.view_change_state; primary_state = s.primary_state }

(** val similar_entry : pBFTcontext -> pBFTlogEntry -> pBFTlogEntry -> bool **)

let similar_entry pbft_context e1 e2 =
  eq_request_data pbft_context e1.log_entry_request_data e2.log_entry_request_data

(** val change_entry : pBFTcontext -> pBFTlog -> pBFTlogEntry -> pBFTlog **)

let rec change_entry pbft_context log0 e =
  match log0 with
  | [] -> []
  | entry :: entries ->
    if similar_entry pbft_context entry e
    then e :: entries
    else entry :: (change_entry pbft_context entries e)

(** val decrement_requests_in_progress : pBFTcontext -> pBFTstate -> pBFTstate **)

let decrement_requests_in_progress pbft_context s =
  { local_keys = s.local_keys; current_view = s.current_view; log = s.log;
    cp_state = s.cp_state; sm_state0 = s.sm_state0; next_to_execute =
    s.next_to_execute; ready = s.ready; last_reply_state = s.last_reply_state;
    view_change_state = s.view_change_state; primary_state =
    (decrement_in_progress pbft_context s.primary_state) }

(** val increment_sequence_number : pBFTcontext -> pBFTstate -> pBFTstate **)

let increment_sequence_number pbft_context s =
  { local_keys = s.local_keys; current_view = s.current_view; log = s.log;
    cp_state = s.cp_state; sm_state0 = s.sm_state0; next_to_execute =
    s.next_to_execute; ready = s.ready; last_reply_state = s.last_reply_state;
    view_change_state = s.view_change_state; primary_state =
    (increment_seq_num pbft_context s.primary_state) }

(** val change_sequence_number : pBFTcontext -> pBFTstate -> seqNum -> pBFTstate **)

let change_sequence_number pbft_context s sn =
  { local_keys = s.local_keys; current_view = s.current_view; log = s.log;
    cp_state = s.cp_state; sm_state0 = s.sm_state0; next_to_execute =
    s.next_to_execute; ready = s.ready; last_reply_state = s.last_reply_state;
    view_change_state = s.view_change_state; primary_state =
    (change_seq_num pbft_context s.primary_state sn) }

(** val change_log_entry : pBFTcontext -> pBFTstate -> pBFTlogEntry -> pBFTstate **)

let change_log_entry pbft_context s e =
  { local_keys = s.local_keys; current_view = s.current_view; log =
    (change_entry pbft_context s.log e); cp_state = s.cp_state; sm_state0 =
    s.sm_state0; next_to_execute = s.next_to_execute; ready = s.ready;
    last_reply_state = s.last_reply_state; view_change_state = s.view_change_state;
    primary_state = s.primary_state }

(** val add_new_commit2log :
    pBFTcontext -> pBFTlog -> commit -> generatedInfo option * pBFTlog **)

let rec add_new_commit2log pbft_context log0 c =
  match log0 with
  | [] ->
    let entry = mkNewLogEntryFromCommit pbft_context c in
    let prepst = Add_prepare_status_na in
    let commst = Add_commit_status_added (commit2rep_toks pbft_context c) in
    ((Some { gi_prepare = prepst; gi_commit = commst; gi_entry = entry }),
    (entry :: []))
  | entry :: entries ->
    if is_commit_for_entry pbft_context entry c
    then if Nat.ltb (length entry.log_entry_commits)
              (add (mul (Pervasives.succ (Pervasives.succ 0)) pbft_context.f)
                (Pervasives.succ 0))
         then (match add_commit2entry pbft_context entry c with
               | Some new_entry ->
                 let prepst = Add_prepare_status_na in
                 let commst = Add_commit_status_added
                   (commit2rep_toks pbft_context c)
                 in
                 ((Some { gi_prepare = prepst; gi_commit = commst; gi_entry =
                 new_entry }), (new_entry :: entries))
               | None -> (None, log0))
         else (None, log0)
    else let (b, l) = add_new_commit2log pbft_context entries c in
         (b, (entry :: l))

(** val add_new_checkpoint2cp_log :
    pBFTcontext -> pBFTcheckpoint_log -> pBFTsm_state -> lastReplyState ->
    checkpoint -> pBFTcheckpointEntry option * pBFTcheckpoint_log **)

let rec add_new_checkpoint2cp_log pbft_context log0 sm lr c =
  match log0 with
  | [] ->
    let entry = mkNewCheckpointEntryFromCheckpoint pbft_context c sm lr in
    ((Some entry), (entry :: []))
  | entry :: entries ->
    if is_checkpoint_for_entry pbft_context entry c
    then (match add_checkpoint2entry pbft_context entry c with
          | Some new_entry -> ((Some new_entry), (new_entry :: entries))
          | None -> (None, log0))
    else let (b, l) = add_new_checkpoint2cp_log pbft_context entries sm lr c in
         (b, (entry :: l))

(** val add_new_checkpoint2cp_state :
    pBFTcontext -> pBFTcheckpointState -> pBFTsm_state -> lastReplyState ->
    checkpoint -> pBFTcheckpointEntry option * pBFTcheckpointState **)

let add_new_checkpoint2cp_state pbft_context cp_state0 sm lr c =
  let (entryop, new_cp_log) =
    add_new_checkpoint2cp_log pbft_context cp_state0.chk_state_others sm lr c
  in
  let new_cp_state = { chk_state_stable = cp_state0.chk_state_stable;
    chk_state_others = new_cp_log }
  in
  (entryop, new_cp_state)

(** val update_stable_sp_log :
    pBFTcontext -> pBFTcheckpointState -> pBFTcheckpointEntry -> pBFTcheckpointState **)

let update_stable_sp_log _ state entry =
  { chk_state_stable = entry; chk_state_others = state.chk_state_others }

(** val add_new_prepare2log :
    pBFTcontext -> rep -> pBFTlog -> prepare -> (unit -> repToks) -> generatedInfo
    option * pBFTlog **)

let rec add_new_prepare2log pbft_context slf log0 p fc =
  match log0 with
  | [] ->
    let entry = mkNewLogEntryFromPrepare pbft_context p in
    let prepst = Add_prepare_status_added (prepare2rep_toks pbft_context p) in
    let commst = Add_commit_status_na in
    ((Some { gi_prepare = prepst; gi_commit = commst; gi_entry = entry }),
    (entry :: []))
  | entry :: entries ->
    if is_prepare_for_entry pbft_context entry p
    then if Nat.ltb (length entry.log_entry_prepares)
              (mul (Pervasives.succ (Pervasives.succ 0)) pbft_context.f)
         then (match add_prepare2entry pbft_context slf entry p fc with
               | Some gi -> ((Some gi), (gi.gi_entry :: entries))
               | None -> (None, log0))
         else (None, log0)
    else let (b, l) = add_new_prepare2log pbft_context slf entries p fc in
         (b, (entry :: l))

(** val update_log_checkpoint_stable :
    pBFTcontext -> pBFTstate -> pBFTcheckpointEntry -> pBFTstate **)

let update_log_checkpoint_stable pbft_context s entry =
  { local_keys = s.local_keys; current_view = s.current_view; log = s.log;
    cp_state = (update_stable_sp_log pbft_context s.cp_state entry); sm_state0 =
    s.sm_state0; next_to_execute = s.next_to_execute; ready = s.ready;
    last_reply_state = s.last_reply_state; view_change_state = s.view_change_state;
    primary_state = s.primary_state }

(** val update_log : pBFTcontext -> pBFTstate -> pBFTlog -> pBFTstate **)

let update_log _ s l =
  { local_keys = s.local_keys; current_view = s.current_view; log = l; cp_state =
    s.cp_state; sm_state0 = s.sm_state0; next_to_execute = s.next_to_execute;
    ready = s.ready; last_reply_state = s.last_reply_state; view_change_state =
    s.view_change_state; primary_state = s.primary_state }

(** val update_checkpoint_state :
    pBFTcontext -> pBFTstate -> pBFTcheckpointState -> pBFTstate **)

let update_checkpoint_state _ s cp_state0 =
  { local_keys = s.local_keys; current_view = s.current_view; log = s.log;
    cp_state = cp_state0; sm_state0 = s.sm_state0; next_to_execute =
    s.next_to_execute; ready = s.ready; last_reply_state = s.last_reply_state;
    view_change_state = s.view_change_state; primary_state = s.primary_state }

(** val add_new_pre_prepare_and_prepare2log :
    pBFTcontext -> rep -> pBFTlog -> pre_prepare -> pBFTdigest -> (unit -> repToks)
    -> (unit -> repToks) -> generatedInfo option * pBFTlog **)

let rec add_new_pre_prepare_and_prepare2log pbft_context i log0 pp d fp fc =
  match log0 with
  | [] ->
    let prep = fp () in
    let entry = mkNewLogEntryWithPrepare pbft_context pp d prep in
    let prepst = Add_prepare_status_added prep in
    let commst = Add_commit_status_na in
    ((Some { gi_prepare = prepst; gi_commit = commst; gi_entry = entry }),
    (entry :: []))
  | entry :: entries ->
    if similar_entry_and_pre_prepare pbft_context entry pp d
    then (match fill_out_pp_info_with_prepare pbft_context i entry pp fp fc with
          | Some gi -> ((Some gi), (gi.gi_entry :: entries))
          | None -> (None, log0))
    else let (b, entries') =
           add_new_pre_prepare_and_prepare2log pbft_context i entries pp d fp fc
         in
         (b, (entry :: entries'))

(** val valid_timestamp :
    pBFTcontext -> pBFTprimaryState -> client option -> timestamp -> bool **)

let valid_timestamp _ state cop ts =
  match cop with
  | Some client2 ->
    Nat.ltb (timestamp2nat (state.client_info client2)) (timestamp2nat ts)
  | None -> true

(** val check_between_water_marks : pBFTcontext -> seqNum -> seqNum -> bool **)

let check_between_water_marks pbft_context low s =
  (&&) (seqNumLt low s)
    (seqNumLe s (add (seqnum2nat low) pbft_context.pBFTwater_mark_range))

(** val check_new_request :
    pBFTcontext -> rep -> seqNum -> pBFTprimaryState -> request ->
    pBFTprimaryState * request list option **)

let check_new_request pbft_context _ low state r =
  if (||) ((<=) pbft_context.pBFTmax_in_progress state.in_progress)
       (negb
         (check_between_water_marks pbft_context low
           (next_seq state.sequence_number)))
  then let buf = buffer_request pbft_context state r in (buf, None)
  else let sender = request2sender pbft_context r in
       let timestamp1 = request2timestamp pbft_context r in
       if valid_timestamp pbft_context state sender timestamp1
       then let all_requests = r :: state.request_buffer in
            let state_ts = update_timestamp_op pbft_context state sender timestamp1
            in
            let state_inc = increment_in_progress pbft_context state_ts in
            let state_res = reset_request_buffer pbft_context state_inc in
            (state_res, (Some all_requests))
       else (state, None)

(** val broadcast2others :
    pBFTcontext -> rep -> (name list -> directedMsg) -> directedMsg **)

let broadcast2others pbft_context slf f1 =
  f1 (other_names pbft_context slf)

(** val bare_new_view2cert : pBFTcontext -> bare_NewView -> viewChangeCert **)

let bare_new_view2cert _ = function
| Bare_new_view (_, c, _, _) -> c

(** val new_view2cert : pBFTcontext -> newView -> viewChangeCert **)

let new_view2cert pbft_context = function
| New_view (b, _) -> bare_new_view2cert pbft_context b

(** val bare_new_view2oprep : pBFTcontext -> bare_NewView -> pre_prepare list **)

let bare_new_view2oprep _ = function
| Bare_new_view (_, _, oP, _) -> oP

(** val new_view2oprep : pBFTcontext -> newView -> pre_prepare list **)

let new_view2oprep pbft_context = function
| New_view (b, _) -> bare_new_view2oprep pbft_context b

(** val bare_new_view2nprep : pBFTcontext -> bare_NewView -> pre_prepare list **)

let bare_new_view2nprep _ = function
| Bare_new_view (_, _, _, nP) -> nP

(** val new_view2nprep : pBFTcontext -> newView -> pre_prepare list **)

let new_view2nprep pbft_context = function
| New_view (b, _) -> bare_new_view2nprep pbft_context b

(** val view_change_cert2max_seq_vc :
    pBFTcontext -> viewChangeCert -> (seqNum * viewChange) option **)

let rec view_change_cert2max_seq_vc pbft_context = function
| [] -> None
| vc :: vcs ->
  let n1 = view_change2seq pbft_context vc in
  (match view_change_cert2max_seq_vc pbft_context vcs with
   | Some p ->
     let (n2, vc2) = p in if seqNumLt n1 n2 then Some (n2, vc2) else Some (n1, vc)
   | None -> Some (n1, vc))

(** val view_change_cert2max_seq :
    pBFTcontext -> viewChangeCert -> seqNum option **)

let view_change_cert2max_seq pbft_context l =
  match view_change_cert2max_seq_vc pbft_context l with
  | Some p -> let (sn, _) = p in Some sn
  | None -> None

(** val pre_prepares2max_seq : pBFTcontext -> pre_prepare list -> seqNum **)

let rec pre_prepares2max_seq pbft_context = function
| [] -> 0
| p :: ps ->
  max_seq_num (pre_prepare2seq pbft_context p)
    (pre_prepares2max_seq pbft_context ps)

(** val view_change_cert2prep :
    pBFTcontext -> viewChangeCert -> preparedInfo list **)

let rec view_change_cert2prep pbft_context = function
| [] -> []
| vc :: vcs ->
  app (view_change2prep pbft_context vc) (view_change_cert2prep pbft_context vcs)

(** val prepared_info2request_data : pBFTcontext -> preparedInfo -> requestData **)

let prepared_info2request_data pbft_context p =
  pre_prepare2request_data pbft_context p.prepared_info_pre_prepare
    p.prepared_info_digest

(** val requests2digest : pBFTcontext -> pBFThash -> request list -> pBFTdigest **)

let requests2digest _ pbft_hash rs =
  pbft_hash.create_hash_messages (map (fun x -> PBFTrequest x) rs)

(** val pre_prepare2digest :
    pBFTcontext -> pBFThash -> pre_prepare -> pBFTdigest **)

let pre_prepare2digest pbft_context pbft_hash p =
  requests2digest pbft_context pbft_hash (pre_prepare2requests pbft_context p)

(** val prepared_info_has_correct_digest :
    pBFTcontext -> pBFThash -> preparedInfo -> bool **)

let prepared_info_has_correct_digest pbft_context pbft_hash p =
  if pbft_context.pBFTdigestdeq (prepared_info2digest pbft_context p)
       (requests2digest pbft_context pbft_hash
         (prepared_info2requests pbft_context p))
  then true
  else false

(** val info_is_prepared : pBFTcontext -> pBFThash -> preparedInfo -> bool **)

let info_is_prepared pbft_context pbft_hash p =
  let preps = p.prepared_info_prepares in
  let l = prepared_info2senders pbft_context p in
  let ppview = prepared_info2view pbft_context p in
  let ppsender = prepared_info2pp_sender pbft_context p in
  let rd = prepared_info2request_data pbft_context p in
  (&&)
    ((&&)
      ((&&)
        ((&&)
          ((&&)
            ((<=) (mul (Pervasives.succ (Pervasives.succ 0)) pbft_context.f)
              (length l))
            (if pbft_context.rep_deq ppsender (pBFTprimary pbft_context ppview)
             then true
             else false))
          (prepared_info_has_correct_digest pbft_context pbft_hash p))
        (norepeatsb pbft_context.rep_deq l))
      (forallb (fun r -> if pbft_context.rep_deq r ppsender then false else true)
        l))
    (forallb (fun prep ->
      if requestData_Deq pbft_context (prepare2request_data pbft_context prep) rd
      then true
      else false) preps)

(** val same_digests : pBFTcontext -> pBFTdigest -> pBFTdigest -> bool **)

let same_digests pbft_context d1 d2 =
  if pbft_context.pBFTdigestdeq d1 d2 then true else false

(** val last_prepared_info :
    pBFTcontext -> pBFThash -> preparedInfo -> preparedInfo list -> bool **)

let last_prepared_info pbft_context pbft_hash p l =
  let s = prepared_info2seq pbft_context p in
  let v = prepared_info2view pbft_context p in
  let d = prepared_info2digest pbft_context p in
  forallb (fun nfo ->
    let s' = prepared_info2seq pbft_context nfo in
    let v' = prepared_info2view pbft_context nfo in
    let d' = prepared_info2digest pbft_context nfo in
    if info_is_prepared pbft_context pbft_hash nfo
    then if seqNumDeq s s'
         then if (=) (view2nat v') (view2nat v)
              then same_digests pbft_context d d'
              else Nat.ltb (view2nat v') (view2nat v)
         else true
    else true) l

(** val valid_prepared_info :
    pBFTcontext -> pBFThash -> preparedInfo list -> preparedInfo -> bool **)

let valid_prepared_info pbft_context pbft_hash l p =
  (&&) (info_is_prepared pbft_context pbft_hash p)
    (last_prepared_info pbft_context pbft_hash p l)

(** val bare_view_change2cert : pBFTcontext -> bare_ViewChange -> checkpointCert **)

let bare_view_change2cert _ = function
| Bare_view_change (_, _, _, c, _, _) -> c

(** val view_change2cert : pBFTcontext -> viewChange -> checkpointCert **)

let view_change2cert pbft_context = function
| View_change (bv, _) -> bare_view_change2cert pbft_context bv

(** val same_seq_nums : seqNum -> seqNum -> bool **)

let same_seq_nums s1 s2 =
  if seqNumDeq s1 s2 then true else false

(** val stableChkPt2digest :
    pBFTcontext -> pBFThash -> stableChkPt -> pBFTdigest **)

let stableChkPt2digest _ pbft_hash s =
  pbft_hash.create_hash_state_last_reply s.si_state s.si_lastr

(** val correct_view_change_preps :
    pBFTcontext -> pBFThash -> seqNum -> view -> preparedInfo list -> bool **)

let correct_view_change_preps pbft_context pbft_hash n v preps =
  forallb (fun p ->
    (&&)
      ((&&) (valid_prepared_info pbft_context pbft_hash preps p)
        ((<=) (view2nat (prepared_info2view pbft_context p)) (view2nat v)))
      (check_between_water_marks pbft_context n (prepared_info2seq pbft_context p)))
    preps

(** val correct_view_change_cert_one :
    pBFTcontext -> pBFThash -> seqNum -> view -> stableChkPt -> checkpoint -> bool **)

let correct_view_change_cert_one pbft_context pbft_hash n v s c =
  (&&)
    ((&&) (same_seq_nums n (checkpoint2seq pbft_context c))
      (Nat.ltb (view2nat (checkpoint2view pbft_context c)) (view2nat v)))
    (same_digests pbft_context (checkpoint2digest pbft_context c)
      (stableChkPt2digest pbft_context pbft_hash s))

(** val correct_view_change_cert :
    pBFTcontext -> pBFThash -> seqNum -> view -> stableChkPt -> checkpointCert ->
    bool **)

let correct_view_change_cert pbft_context pbft_hash n v s c =
  (&&)
    ((&&) (forallb (correct_view_change_cert_one pbft_context pbft_hash n v s) c)
      (norepeatsb pbft_context.rep_deq (map (checkpoint2sender pbft_context) c)))
    ((<=) (add pbft_context.f (Pervasives.succ 0)) (length c))

(** val same_views : view -> view -> bool **)

let same_views v1 v2 =
  if viewDeq v1 v2 then true else false

(** val bare_view_change2stable : pBFTcontext -> bare_ViewChange -> stableChkPt **)

let bare_view_change2stable _ = function
| Bare_view_change (_, _, s, _, _, _) -> s

(** val view_change2stable : pBFTcontext -> viewChange -> stableChkPt **)

let view_change2stable pbft_context = function
| View_change (b, _) -> bare_view_change2stable pbft_context b

(** val correct_view_change :
    pBFTcontext -> pBFThash -> view -> viewChange -> bool **)

let correct_view_change pbft_context pbft_hash v vc =
  let vc_view = view_change2view pbft_context vc in
  let vc_seq = view_change2seq pbft_context vc in
  let preps = view_change2prep pbft_context vc in
  let cert = view_change2cert pbft_context vc in
  let chk = view_change2stable pbft_context vc in
  (&&)
    ((&&) (same_views v vc_view)
      (correct_view_change_preps pbft_context pbft_hash vc_seq vc_view preps))
    (correct_view_change_cert pbft_context pbft_hash vc_seq vc_view chk cert)

(** val oexists_last_prepared :
    pBFTcontext -> pBFThash -> pre_prepare -> pBFTdigest -> preparedInfo list ->
    bool **)

let oexists_last_prepared pbft_context pbft_hash p d ps =
  let s = pre_prepare2seq pbft_context p in
  existsb (fun nfo ->
    let s' = prepared_info2seq pbft_context nfo in
    let d' = prepared_info2digest pbft_context nfo in
    if pbft_context.pBFTdigestdeq d d'
    then if seqNumDeq s s'
         then valid_prepared_info pbft_context pbft_hash ps nfo
         else false
    else false) ps

(** val correct_new_view_opre_prepare :
    pBFTcontext -> pBFThash -> view -> seqNum -> preparedInfo list -> pre_prepare
    -> bool **)

let correct_new_view_opre_prepare pbft_context pbft_hash nvview maxV ps p =
  let sender = pre_prepare2sender pbft_context p in
  let view0 = pre_prepare2view pbft_context p in
  let reqs = pre_prepare2requests pbft_context p in
  let s = pre_prepare2seq pbft_context p in
  if viewDeq view0 nvview
  then if pbft_context.rep_deq sender (pBFTprimary pbft_context view0)
       then if seqNumLt maxV s
            then let digest0 = requests2digest pbft_context pbft_hash reqs in
                 oexists_last_prepared pbft_context pbft_hash p digest0 ps
            else false
       else false
  else false

(** val correct_new_view_opre_prepare_op :
    pBFTcontext -> pBFThash -> view -> seqNum option -> preparedInfo list ->
    pre_prepare -> bool **)

let correct_new_view_opre_prepare_op pbft_context pbft_hash nvview maxVop ps =
  match maxVop with
  | Some maxV ->
    correct_new_view_opre_prepare pbft_context pbft_hash nvview maxV ps
  | None -> (fun _ -> false)

(** val nexists_last_prepared :
    pBFTcontext -> pBFThash -> pre_prepare -> preparedInfo list -> bool **)

let nexists_last_prepared pbft_context pbft_hash p ps =
  let s = pre_prepare2seq pbft_context p in
  existsb (fun nfo ->
    let s' = prepared_info2seq pbft_context nfo in
    if seqNumDeq s s'
    then valid_prepared_info pbft_context pbft_hash ps nfo
    else false) ps

(** val is_null_req : pBFTcontext -> request list -> bool **)

let is_null_req _ = function
| [] -> false
| r :: l ->
  let Req (b, _) = r in
  (match b with
   | Null_req ->
     (match l with
      | [] -> true
      | _ :: _ -> false)
   | Bare_req (_, _, _) -> false)

(** val correct_new_view_npre_prepare :
    pBFTcontext -> pBFThash -> view -> seqNum -> seqNum -> preparedInfo list ->
    pre_prepare -> bool **)

let correct_new_view_npre_prepare pbft_context pbft_hash nvview maxV maxO ps p =
  let sender = pre_prepare2sender pbft_context p in
  let view0 = pre_prepare2view pbft_context p in
  let reqs = pre_prepare2requests pbft_context p in
  let s = pre_prepare2seq pbft_context p in
  if viewDeq view0 nvview
  then if is_null_req pbft_context reqs
       then if pbft_context.rep_deq sender (pBFTprimary pbft_context view0)
            then if seqNumLt maxV s
                 then if seqNumLt s maxO
                      then negb (nexists_last_prepared pbft_context pbft_hash p ps)
                      else false
                 else false
            else false
       else false
  else false

(** val correct_new_view_npre_prepare_op :
    pBFTcontext -> pBFThash -> view -> seqNum option -> seqNum -> preparedInfo list
    -> pre_prepare -> bool **)

let correct_new_view_npre_prepare_op pbft_context pbft_hash nvview maxVop maxO ps =
  match maxVop with
  | Some maxV ->
    correct_new_view_npre_prepare pbft_context pbft_hash nvview maxV maxO ps
  | None -> (fun _ -> false)

(** val max_seq_num_op : seqNum -> seqNum option -> seqNum **)

let max_seq_num_op sn = function
| Some sn' -> max_seq_num sn sn'
| None -> sn

(** val preparedInfos2max_seq :
    pBFTcontext -> (preparedInfo -> bool) -> preparedInfo list -> seqNum option **)

let rec preparedInfos2max_seq pbft_context f1 = function
| [] -> None
| p :: ps ->
  let n = prepared_info2seq pbft_context p in
  let nop = preparedInfos2max_seq pbft_context f1 ps in
  if f1 p then Some (max_seq_num_op n nop) else nop

(** val view_change2max_seq_preps :
    pBFTcontext -> (preparedInfo -> bool) -> viewChange -> seqNum option **)

let view_change2max_seq_preps pbft_context f1 vc =
  preparedInfos2max_seq pbft_context f1 (view_change2prep pbft_context vc)

(** val view_change_cert2max_seq_preps_vc :
    pBFTcontext -> (preparedInfo -> bool) -> viewChangeCert ->
    (seqNum * viewChange) option **)

let rec view_change_cert2max_seq_preps_vc pbft_context f1 = function
| [] -> None
| vc :: vcs ->
  (match view_change2max_seq_preps pbft_context f1 vc with
   | Some n1 ->
     (match view_change_cert2max_seq_preps_vc pbft_context f1 vcs with
      | Some p ->
        let (n2, vc2) = p in
        if seqNumLt n1 n2 then Some (n2, vc2) else Some (n1, vc)
      | None -> Some (n1, vc))
   | None -> view_change_cert2max_seq_preps_vc pbft_context f1 vcs)

(** val view_change_cert2max_seq_preps :
    pBFTcontext -> (preparedInfo -> bool) -> viewChangeCert -> seqNum option **)

let view_change_cert2max_seq_preps pbft_context f1 l =
  match view_change_cert2max_seq_preps_vc pbft_context f1 l with
  | Some p -> let (sn, _) = p in Some sn
  | None -> None

(** val from_min_to_max : seqNum -> seqNum -> seqNum list **)

let from_min_to_max mins maxs =
  if Nat.ltb (seqnum2nat maxs) (seqnum2nat mins)
  then []
  else map (fun x -> x)
         (seq (Pervasives.succ (seqnum2nat mins))
           (sub (seqnum2nat maxs) (seqnum2nat mins)))

(** val from_min_to_max_op : seqNum option -> seqNum option -> seqNum list **)

let from_min_to_max_op minop maxop =
  match minop with
  | Some mins ->
    (match maxop with
     | Some maxs -> from_min_to_max mins maxs
     | None -> [])
  | None -> []

(** val from_min_to_max_of_view_changes_cert :
    pBFTcontext -> pBFThash -> viewChangeCert -> seqNum list **)

let from_min_to_max_of_view_changes_cert pbft_context pbft_hash v =
  let minsn = view_change_cert2max_seq pbft_context v in
  let preps = view_change_cert2prep pbft_context v in
  let f1 = valid_prepared_info pbft_context pbft_hash preps in
  let maxop = view_change_cert2max_seq_preps pbft_context f1 v in
  from_min_to_max_op minsn maxop

(** val view_change_entry2view_changes :
    pBFTcontext -> pBFTviewChangeEntry -> viewChange list **)

let view_change_entry2view_changes _ e =
  let { vce_view = _; vce_view_change = vce_view_change0; vce_view_changes = vcs;
    vce_new_view = _ } = e
  in
  (match vce_view_change0 with
   | Some vc -> vc :: vcs
   | None -> vcs)

(** val from_min_to_max_of_view_changes :
    pBFTcontext -> pBFThash -> pBFTviewChangeEntry -> seqNum list **)

let from_min_to_max_of_view_changes pbft_context pbft_hash entry =
  let v = view_change_entry2view_changes pbft_context entry in
  from_min_to_max_of_view_changes_cert pbft_context pbft_hash v

(** val exists_prepared_info_in_pre_prepares :
    pBFTcontext -> pBFThash -> preparedInfo -> pre_prepare list -> bool **)

let exists_prepared_info_in_pre_prepares pbft_context pbft_hash nfo oP =
  existsb (fun pp ->
    (&&)
      (same_digests pbft_context (prepared_info2digest pbft_context nfo)
        (pre_prepare2digest pbft_context pbft_hash pp))
      (same_seq_nums (prepared_info2seq pbft_context nfo)
        (pre_prepare2seq pbft_context pp))) oP

(** val sequence_number_is_accounted_for :
    pBFTcontext -> pBFThash -> preparedInfo list -> seqNum -> pre_prepare list ->
    preparedInfo -> bool **)

let sequence_number_is_accounted_for pbft_context pbft_hash p maxV oP nfo =
  if valid_prepared_info pbft_context pbft_hash p nfo
  then let n = prepared_info2seq pbft_context nfo in
       if Nat.ltb (seqnum2nat maxV) (seqnum2nat n)
       then exists_prepared_info_in_pre_prepares pbft_context pbft_hash nfo oP
       else true
  else true

(** val all_sequence_numbers_are_accounted_for :
    pBFTcontext -> pBFThash -> preparedInfo list -> seqNum -> pre_prepare list ->
    bool **)

let all_sequence_numbers_are_accounted_for pbft_context pbft_hash p maxV oP =
  forallb (sequence_number_is_accounted_for pbft_context pbft_hash p maxV oP) p

(** val all_sequence_numbers_are_accounted_for_op :
    pBFTcontext -> pBFThash -> preparedInfo list -> seqNum option -> pre_prepare
    list -> bool **)

let all_sequence_numbers_are_accounted_for_op pbft_context pbft_hash p maxVop oP =
  match maxVop with
  | Some maxV ->
    all_sequence_numbers_are_accounted_for pbft_context pbft_hash p maxV oP
  | None -> false

(** val correct_new_view : pBFTcontext -> pBFThash -> newView -> bool **)

let correct_new_view pbft_context pbft_hash nv =
  let sender = new_view2sender pbft_context nv in
  let nvview = new_view2view pbft_context nv in
  let v = new_view2cert pbft_context nv in
  let oP = new_view2oprep pbft_context nv in
  let nP = new_view2nprep pbft_context nv in
  let maxVop = view_change_cert2max_seq pbft_context v in
  let maxO = pre_prepares2max_seq pbft_context oP in
  let vcPreps = view_change_cert2prep pbft_context v in
  if pbft_context.rep_deq sender (pBFTprimary pbft_context nvview)
  then if (<=)
            (add (mul (Pervasives.succ (Pervasives.succ 0)) pbft_context.f)
              (Pervasives.succ 0)) (length v)
       then if norepeatsb pbft_context.rep_deq
                 (map (view_change2sender pbft_context) v)
            then if forallb (correct_view_change pbft_context pbft_hash nvview) v
                 then if forallb
                           (correct_new_view_opre_prepare_op pbft_context pbft_hash
                             nvview maxVop vcPreps) oP
                      then if forallb
                                (correct_new_view_npre_prepare_op pbft_context
                                  pbft_hash nvview maxVop maxO vcPreps) nP
                           then if norepeatsb seqNumDeq
                                     (map (pre_prepare2seq pbft_context)
                                       (app oP nP))
                                then all_sequence_numbers_are_accounted_for_op
                                       pbft_context pbft_hash vcPreps maxVop oP
                                else false
                           else false
                      else false
                 else false
            else false
       else false
  else false

(** val has_new_view1 :
    pBFTcontext -> pBFThash -> pBFTviewChangeState -> view -> bool **)

let has_new_view1 pbft_context pbft_hash state v =
  existsb (fun entry ->
    if viewDeq v entry.vce_view
    then (match entry.vce_new_view with
          | Some nv -> correct_new_view pbft_context pbft_hash nv
          | None -> false)
    else false) state

(** val has_new_view :
    pBFTcontext -> pBFThash -> pBFTviewChangeState -> view -> bool **)

let has_new_view pbft_context pbft_hash state v =
  if viewDeq v initial_view
  then true
  else has_new_view1 pbft_context pbft_hash state v

(** val pBFThandle_request :
    pBFTcontext -> pBFTauth -> pBFThash -> rep -> (pBFTstate, request,
    directedMsgs) update **)

let pBFThandle_request pbft_context pbft_auth pbft_hash slf state r =
  let keys = state.local_keys in
  let cview = state.current_view in
  let low = low_water_mark pbft_context state in
  if has_new_view pbft_context pbft_hash state.view_change_state cview
  then if verify_request pbft_context pbft_auth slf keys r
       then if is_primary pbft_context cview slf
            then let (new_primary_state, reqsop) =
                   check_new_request pbft_context slf low state.primary_state r
                 in
                 let upd_state =
                   update_primary_state pbft_context state new_primary_state
                 in
                 (match reqsop with
                  | Some reqs ->
                    let upd_seq_num =
                      increment_sequence_number pbft_context upd_state
                    in
                    let next_seq_num = upd_seq_num.primary_state.sequence_number in
                    let digest0 = requests2digest pbft_context pbft_hash reqs in
                    let pp =
                      mk_auth_pre_prepare pbft_context pbft_auth cview next_seq_num
                        reqs keys
                    in
                    let upd_log_pp =
                      log_new_pre_prepare pbft_context upd_seq_num pp digest0
                    in
                    ((Some upd_log_pp),
                    ((broadcast2others pbft_context slf
                       (send_pre_prepare pbft_context pp)) :: []))
                  | None -> ((Some upd_state), []))
            else let start = Start_timer ((request2bare pbft_context r), cview) in
                 ((Some state),
                 ((send_start_timer pbft_context start
                    ((Obj.magic (PBFTreplica slf)) :: [])) :: []))
       else ((Some state), [])
  else ((Some state), [])

(** val pre_prepare2rep_toks_of_prepare :
    pBFTcontext -> pBFTauth -> rep -> local_key_map -> pre_prepare -> pBFTdigest ->
    repToks **)

let pre_prepare2rep_toks_of_prepare pbft_context pbft_auth n keys pp d =
  prepare2rep_toks pbft_context
    (pre_prepare2prepare pbft_context pbft_auth n keys pp d)

(** val pre_prepare2rep_toks_of_commit :
    pBFTcontext -> pBFTauth -> rep -> local_key_map -> pre_prepare -> pBFTdigest ->
    repToks **)

let pre_prepare2rep_toks_of_commit pbft_context pbft_auth n keys pp d =
  commit2rep_toks pbft_context
    (pre_prepare2commit pbft_context pbft_auth n keys pp d)

(** val entry2seq : pBFTcontext -> pBFTlogEntry -> seqNum **)

let entry2seq pbft_context e =
  let { log_entry_request_data = bp; log_entry_pre_prepare_info = _;
    log_entry_prepares = _; log_entry_commits = _ } = e
  in
  request_data2seq pbft_context bp

(** val find_entry : pBFTcontext -> pBFTlog -> seqNum -> pBFTlogEntry option **)

let rec find_entry pbft_context log0 s =
  match log0 with
  | [] -> None
  | entry :: entries ->
    if seqNumDeq s (entry2seq pbft_context entry)
    then Some entry
    else find_entry pbft_context entries s

(** val reply2request :
    pBFTcontext -> pBFTauth -> rep -> view -> local_key_map -> request ->
    pBFTsm_state -> lastReplyState -> (reply option * pBFTsm_state) * lastReplyState **)

let reply2request pbft_context pbft_auth slf view0 keys req state lastr =
  match request2info pbft_context req with
  | Some p ->
    let (p0, c) = p in
    let (opr, ts) = p0 in
    (match find_last_reply_entry_corresponding_to_client pbft_context lastr c with
     | Some entry ->
       if (<=) (timestamp2nat entry.lre_timestamp) (timestamp2nat ts)
       then if Nat.ltb (timestamp2nat entry.lre_timestamp) (timestamp2nat ts)
            then let (result0, new_state) = pbft_context.pBFTsm_update c state opr
                 in
                 let rep0 =
                   mk_auth_reply pbft_context pbft_auth view0 ts c slf result0 keys
                 in
                 let new_lastr =
                   update_last_reply_timestamp_and_result pbft_context lastr c ts
                     result0
                 in
                 (((Some rep0), new_state), new_lastr)
            else (match entry.lre_reply with
                  | Some res ->
                    let rep0 =
                      mk_auth_reply pbft_context pbft_auth view0 ts c slf res keys
                    in
                    (((Some rep0), state), lastr)
                  | None -> ((None, state), lastr))
       else ((None, state), lastr)
     | None -> ((None, state), lastr))
  | None -> ((None, state), lastr)

(** val reply2requests :
    pBFTcontext -> pBFTauth -> rep -> view -> local_key_map -> request list ->
    pBFTsm_state -> lastReplyState -> (reply option
    list * pBFTsm_state) * lastReplyState **)

let rec reply2requests pbft_context pbft_auth slf view0 keys reqs state lastr =
  match reqs with
  | [] -> (([], state), lastr)
  | r :: rs ->
    let (p, lr1) =
      reply2request pbft_context pbft_auth slf view0 keys r state lastr
    in
    let (rep0, st1) = p in
    let (p0, lr2) = reply2requests pbft_context pbft_auth slf view0 keys rs st1 lr1
    in
    let (reps0, st2) = p0 in (((rep0 :: reps0), st2), lr2)

(** val list_option2list : 'a1 option list -> 'a1 list **)

let rec list_option2list = function
| [] -> []
| o :: l0 ->
  (match o with
   | Some t -> t :: (list_option2list l0)
   | None -> list_option2list l0)

(** val time_for_checkpoint : pBFTcontext -> seqNum -> bool **)

let time_for_checkpoint pbft_context sn =
  if (=) (Nat.modulo (seqnum2nat sn) pbft_context.pBFTcheckpoint_period) 0
  then true
  else false

(** val check_broadcast_checkpoint :
    pBFTcontext -> pBFTauth -> pBFThash -> rep -> seqNum -> view -> local_key_map
    -> pBFTstate -> pBFTstate * directedMsgs **)

let check_broadcast_checkpoint pbft_context pbft_auth pbft_hash slf sn vn keys s =
  if time_for_checkpoint pbft_context sn
  then let digest0 =
         pbft_hash.create_hash_state_last_reply s.sm_state0 s.last_reply_state
       in
       let cp = mk_auth_checkpoint pbft_context pbft_auth vn sn digest0 slf keys in
       let lr = s.last_reply_state in
       let (_, new_cp_state) =
         add_new_checkpoint2cp_state pbft_context s.cp_state s.sm_state0 lr cp
       in
       let new_state = update_checkpoint_state pbft_context s new_cp_state in
       (new_state,
       ((broadcast2others pbft_context slf (send_checkpoint pbft_context cp)) :: []))
  else (s, [])

(** val execute_requests :
    pBFTcontext -> pBFTauth -> pBFThash -> rep -> view -> local_key_map ->
    pBFTstate -> seqNum list -> (directedMsgs * seqNum list) * pBFTstate **)

let execute_requests pbft_context pbft_auth pbft_hash slf view0 keys state ready0 = match ready0 with
| [] -> (([], []), state)
| sn :: sns ->
  if seqNumDeq sn state.next_to_execute
  then let new_state1 = increment_next_to_execute pbft_context state in
       (match find_entry pbft_context state.log sn with
        | Some entry ->
          if is_committed_entry pbft_context entry
          then let reqs = log_entry2requests pbft_context entry in
               let (p, new_lastr) =
                 reply2requests pbft_context pbft_auth slf view0 keys reqs
                   new_state1.sm_state0 new_state1.last_reply_state
               in
               let (reps1, new_sm_state) = p in
               let new_state2 =
                 change_sm_state pbft_context new_state1 new_sm_state
               in
               let new_state3 =
                 change_last_reply_state pbft_context new_state2 new_lastr
               in
               let new_entry = add_replies2entry pbft_context entry reps1 in
               let new_state4 = change_log_entry pbft_context new_state3 new_entry
               in
               let (new_state5, cp1) =
                 check_broadcast_checkpoint pbft_context pbft_auth pbft_hash slf sn
                   view0 keys new_state4
               in
               let cr =
                 send_check_ready pbft_context
                   ((Obj.magic (PBFTreplica slf)) :: [])
               in
               let replies = map (send_reply pbft_context) (list_option2list reps1)
               in
               (((app replies (cr :: cp1)), sns), new_state5)
          else (([], ready0), state)
        | None -> (([], ready0), state))
  else (([], ready0), state)

(** val find_and_execute_requests :
    pBFTcontext -> pBFTauth -> pBFThash -> rep -> view -> local_key_map ->
    pBFTstate -> directedMsgs * pBFTstate **)

let find_and_execute_requests pbft_context pbft_auth pbft_hash slf view0 keys state =
  let (p, new_state1) =
    execute_requests pbft_context pbft_auth pbft_hash slf view0 keys state
      state.ready
  in
  let (outs, still_ready) = p in
  let new_state2 = update_ready pbft_context new_state1 still_ready in
  (outs, new_state2)

(** val decrement_requests_in_progress_if_primary :
    pBFTcontext -> rep -> view -> pBFTstate -> pBFTstate **)

let decrement_requests_in_progress_if_primary pbft_context slf view0 state =
  if is_primary pbft_context view0 slf
  then decrement_requests_in_progress pbft_context state
  else state

(** val nat2string : int -> char list **)

let nat2string n =
  (fun fO fS n -> if n=0 then fO () else fS (n-1))
    (fun _ ->
    '0'::[])
    (fun n0 ->
    (fun fO fS n -> if n=0 then fO () else fS (n-1))
      (fun _ ->
      '1'::[])
      (fun n1 ->
      (fun fO fS n -> if n=0 then fO () else fS (n-1))
        (fun _ ->
        '2'::[])
        (fun n2 ->
        (fun fO fS n -> if n=0 then fO () else fS (n-1))
          (fun _ ->
          '3'::[])
          (fun n3 ->
          (fun fO fS n -> if n=0 then fO () else fS (n-1))
            (fun _ ->
            '4'::[])
            (fun n4 ->
            (fun fO fS n -> if n=0 then fO () else fS (n-1))
              (fun _ ->
              '5'::[])
              (fun n5 ->
              (fun fO fS n -> if n=0 then fO () else fS (n-1))
                (fun _ ->
                '6'::[])
                (fun n6 ->
                (fun fO fS n -> if n=0 then fO () else fS (n-1))
                  (fun _ ->
                  '7'::[])
                  (fun n7 ->
                  (fun fO fS n -> if n=0 then fO () else fS (n-1))
                    (fun _ ->
                    '8'::[])
                    (fun n8 ->
                    (fun fO fS n -> if n=0 then fO () else fS (n-1))
                      (fun _ ->
                      '9'::[])
                      (fun _ ->
                      '-'::[])
                      n8)
                    n7)
                  n6)
                n5)
              n4)
            n3)
          n2)
        n1)
      n0)
    n

(** val sn2string : seqNum -> char list **)

let sn2string s =
  append ('|'::[]) (append (nat2string s) ('|'::[]))

(** val prepare2rep_toks_of_commit :
    pBFTcontext -> pBFTauth -> rep -> local_key_map -> prepare -> repToks **)

let prepare2rep_toks_of_commit pbft_context pbft_auth slf keys p =
  commit2rep_toks pbft_context (prepare2commit pbft_context pbft_auth slf keys p)

(** val check_broadcast_prepare :
    pBFTcontext -> rep -> requestData -> generatedInfo option -> directedMsgs **)

let check_broadcast_prepare pbft_context slf rd = function
| Some g ->
  let { gi_prepare = prepst; gi_commit = _; gi_entry = entry } = g in
  if is_pre_prepared_entry pbft_context entry
  then (match prepst with
        | Add_prepare_status_added prep ->
          (broadcast2others pbft_context slf
            (send_prepare pbft_context
              (request_data_and_rep_toks2prepare pbft_context rd prep))) :: []
        | _ -> [])
  else []
| None -> []

(** val check_broadcast_commit :
    pBFTcontext -> rep -> requestData -> generatedInfo option -> directedMsgs **)

let check_broadcast_commit pbft_context slf rd = function
| Some g ->
  let { gi_prepare = _; gi_commit = commst; gi_entry = entry } = g in
  if is_prepared_entry pbft_context entry
  then (match commst with
        | Add_commit_status_added comm ->
          (broadcast2others pbft_context slf
            (send_commit pbft_context
              (request_data_and_rep_toks2commit pbft_context rd comm))) :: []
        | _ -> [])
  else []
| None -> []

(** val check_send_replies :
    pBFTcontext -> rep -> view -> local_key_map -> generatedInfo option ->
    pBFTstate -> seqNum -> directedMsgs * pBFTstate **)

let check_send_replies pbft_context slf _ _ entryop state sn =
  match entryop with
  | Some g ->
    let { gi_prepare = _; gi_commit = _; gi_entry = entry } = g in
    if is_committed_entry pbft_context entry
    then let ready_state = add_to_ready pbft_context state sn in
         let cr =
           send_check_ready pbft_context ((Obj.magic (PBFTreplica slf)) :: [])
         in
         ((cr :: []), ready_state)
    else ([], state)
  | None -> ([], state)

(** val own_prepare_is_already_in_entry_with_different_digest :
    pBFTcontext -> rep -> seqNum -> view -> pBFTdigest -> pBFTlogEntry -> prepare
    option **)

let own_prepare_is_already_in_entry_with_different_digest pbft_context i s v d e =
  let rd = e.log_entry_request_data in
  if seqNumDeq (request_data2seq pbft_context rd) s
  then if viewDeq (request_data2view pbft_context rd) v
       then if pbft_context.pBFTdigestdeq (request_data2digest pbft_context rd) d
            then None
            else let preps = e.log_entry_prepares in
                 (match find_rep_toks_in_list pbft_context i preps with
                  | Some rt ->
                    Some (request_data_and_rep_toks2prepare pbft_context rd rt)
                  | None -> None)
       else None
  else None

(** val own_prepare_is_already_logged_with_different_digest :
    pBFTcontext -> rep -> seqNum -> view -> pBFTdigest -> pBFTlog -> prepare option **)

let rec own_prepare_is_already_logged_with_different_digest pbft_context i s v d = function
| [] -> None
| entry :: entries ->
  (match own_prepare_is_already_in_entry_with_different_digest pbft_context i s v d
           entry with
   | Some prep -> Some prep
   | None ->
     own_prepare_is_already_logged_with_different_digest pbft_context i s v d
       entries)

(** val pBFThandle_pre_prepare :
    pBFTcontext -> pBFTauth -> pBFThash -> rep -> (pBFTstate, pre_prepare,
    directedMsgs) update **)

let pBFThandle_pre_prepare pbft_context pbft_auth pbft_hash slf state pp =
  let keys = state.local_keys in
  let cview = state.current_view in
  let lwm = low_water_mark pbft_context state in
  let sender = pre_prepare2sender pbft_context pp in
  let ppsn = pre_prepare2seq pbft_context pp in
  let ppview = pre_prepare2view pbft_context pp in
  if has_new_view pbft_context pbft_hash state.view_change_state cview
  then if pbft_context.rep_deq slf sender
       then ((Some state), [])
       else if is_primary pbft_context cview sender
            then if is_primary pbft_context cview slf
                 then ((Some state), [])
                 else if verify_pre_prepare pbft_context pbft_auth slf keys pp
                      then if viewDeq ppview cview
                           then if check_between_water_marks pbft_context lwm ppsn
                                then let digest0 =
                                       pre_prepare2digest pbft_context pbft_hash pp
                                     in
                                     (match own_prepare_is_already_logged_with_different_digest
                                              pbft_context slf ppsn ppview digest0
                                              state.log with
                                      | Some _ -> ((Some state), [])
                                      | None ->
                                        let fp = fun _ ->
                                          pre_prepare2rep_toks_of_prepare
                                            pbft_context pbft_auth slf keys pp
                                            digest0
                                        in
                                        let fc = fun _ ->
                                          pre_prepare2rep_toks_of_commit
                                            pbft_context pbft_auth slf keys pp
                                            digest0
                                        in
                                        let (entryop, new_log) =
                                          add_new_pre_prepare_and_prepare2log
                                            pbft_context slf state.log pp digest0
                                            fp fc
                                        in
                                        let new_state =
                                          update_log pbft_context state new_log
                                        in
                                        let rd =
                                          pre_prepare2request_data pbft_context pp
                                            digest0
                                        in
                                        let preps =
                                          check_broadcast_prepare pbft_context slf
                                            rd entryop
                                        in
                                        let comms =
                                          check_broadcast_commit pbft_context slf
                                            rd entryop
                                        in
                                        let (reps0, new_state') =
                                          check_send_replies pbft_context slf cview
                                            keys entryop new_state ppsn
                                        in
                                        ((Some new_state'),
                                        (app preps (app comms reps0))))
                                else ((Some state), [])
                           else ((Some state), [])
                      else ((Some state), [])
            else ((Some state), [])
  else ((Some state), [])

(** val pBFThandle_prepare :
    pBFTcontext -> pBFTauth -> rep -> (pBFTstate, prepare, directedMsgs) update **)

let pBFThandle_prepare pbft_context pbft_auth slf state p =
  let keys = state.local_keys in
  let cview = state.current_view in
  let lwm = low_water_mark pbft_context state in
  let sender = prepare2sender pbft_context p in
  let psn = prepare2seq pbft_context p in
  if pbft_context.rep_deq slf sender
  then ((Some state), [])
  else if is_primary pbft_context cview sender
       then ((Some state), [])
       else if verify_prepare pbft_context pbft_auth slf keys p
            then if viewDeq (prepare2view pbft_context p) cview
                 then if check_between_water_marks pbft_context lwm psn
                      then let fc = fun _ ->
                             prepare2rep_toks_of_commit pbft_context pbft_auth slf
                               keys p
                           in
                           let (entryop, new_log) =
                             add_new_prepare2log pbft_context slf state.log p fc
                           in
                           let new_state = update_log pbft_context state new_log in
                           let rd = prepare2request_data pbft_context p in
                           let comms =
                             check_broadcast_commit pbft_context slf rd entryop
                           in
                           let (reps0, new_state') =
                             check_send_replies pbft_context slf cview keys entryop
                               new_state psn
                           in
                           ((Some new_state'), (app comms reps0))
                      else ((Some state), [])
                 else ((Some state), [])
            else ((Some state), [])

(** val pBFThandle_commit :
    pBFTcontext -> pBFTauth -> rep -> (pBFTstate, commit, directedMsgs) update **)

let pBFThandle_commit pbft_context pbft_auth slf state c =
  let keys = state.local_keys in
  let view0 = state.current_view in
  let lwm = low_water_mark pbft_context state in
  let sender = commit2sender pbft_context c in
  let csn = commit2seq pbft_context c in
  if pbft_context.rep_deq slf sender
  then ((Some state), [])
  else if verify_commit pbft_context pbft_auth slf keys c
       then if viewDeq (commit2view pbft_context c) view0
            then if check_between_water_marks pbft_context lwm csn
                 then let (entryop, new_log) =
                        add_new_commit2log pbft_context state.log c
                      in
                      let new_state = update_log pbft_context state new_log in
                      let (reps0, new_state') =
                        check_send_replies pbft_context slf view0 keys entryop
                          new_state csn
                      in
                      ((Some new_state'), reps0)
                 else ((Some state), [])
            else ((Some state), [])
       else ((Some state), [])

(** val clear_log_checkpoint : pBFTcontext -> pBFTlog -> seqNum -> pBFTlog **)

let rec clear_log_checkpoint pbft_context l sn =
  match l with
  | [] -> []
  | entry :: log' ->
    let sn' = entry2seq pbft_context entry in
    if seqNumLe sn' sn
    then clear_log_checkpoint pbft_context log' sn
    else entry :: (clear_log_checkpoint pbft_context log' sn)

(** val trim_checkpoint_log :
    pBFTcontext -> seqNum -> pBFTcheckpoint_log -> pBFTcheckpoint_log **)

let rec trim_checkpoint_log pbft_context s = function
| [] -> []
| entry :: entries ->
  if Nat.ltb (seqnum2nat entry.cp_sn) (seqnum2nat s)
  then trim_checkpoint_log pbft_context s entries
  else entry :: (trim_checkpoint_log pbft_context s entries)

(** val trim_checkpoint_state :
    pBFTcontext -> seqNum -> pBFTcheckpointState -> pBFTcheckpointState **)

let trim_checkpoint_state pbft_context sn st =
  let { chk_state_stable = stable; chk_state_others = others } = st in
  { chk_state_stable = stable; chk_state_others =
  (trim_checkpoint_log pbft_context sn others) }

(** val trim_checkpoint : pBFTcontext -> pBFTstate -> seqNum -> pBFTstate **)

let trim_checkpoint pbft_context s sn =
  { local_keys = s.local_keys; current_view = s.current_view; log = s.log;
    cp_state = (trim_checkpoint_state pbft_context sn s.cp_state); sm_state0 =
    s.sm_state0; next_to_execute = s.next_to_execute; ready = s.ready;
    last_reply_state = s.last_reply_state; view_change_state = s.view_change_state;
    primary_state = s.primary_state }

(** val check_stable :
    pBFTcontext -> rep -> pBFTstate -> pBFTcheckpointEntry option -> pBFTstate
    option **)

let check_stable pbft_context _ s = function
| Some entry ->
  if is_stable_checkpoint_entry pbft_context entry
  then let new_state1 = update_log_checkpoint_stable pbft_context s entry in
       let new_log = clear_log_checkpoint pbft_context new_state1.log entry.cp_sn
       in
       let new_state2 = update_log pbft_context new_state1 new_log in
       let new_state3 = trim_checkpoint pbft_context new_state2 entry.cp_sn in
       Some new_state3
  else None
| None -> None

(** val str_concat : char list list -> char list **)

let rec str_concat = function
| [] -> []
| s :: ss -> append s (str_concat ss)

(** val print_entry : pBFTcontext -> pBFTlogEntry -> char list **)

let print_entry pbft_context entry =
  append (sn2string (request_data2seq pbft_context entry.log_entry_request_data))
    (';'::(' '::[]))

(** val print_log : pBFTcontext -> pBFTlog -> char list **)

let rec print_log pbft_context = function
| [] -> []
| entry :: entries ->
  append (print_entry pbft_context entry) (print_log pbft_context entries)

(** val debug_checkpoint :
    pBFTcontext -> rep -> pBFTstate -> pBFTstate -> directedMsgs **)

let debug_checkpoint pbft_context slf old_state new_state =
  let str =
    str_concat
      (('o'::('l'::('d'::(' '::('s'::('e'::('q'::(' '::('n'::('u'::('m'::(' '::('o'::('f'::(' '::('s'::('t'::('a'::('b'::('l'::('e'::(' '::('c'::('h'::('k'::('p'::('o'::('i'::('n'::('t'::(':'::[]))))))))))))))))))))))))))))))) :: (
      (sn2string (low_water_mark pbft_context old_state)) :: ((','::[]) :: (('n'::('e'::('w'::(' '::('s'::('e'::('q'::(' '::('n'::('u'::('m'::(' '::('o'::('f'::(' '::('s'::('t'::('a'::('b'::('l'::('e'::(' '::('c'::('h'::('k'::('p'::('o'::('i'::('n'::('t'::(':'::[]))))))))))))))))))))))))))))))) :: (
      (sn2string (low_water_mark pbft_context new_state)) :: ((','::[]) :: (('o'::('l'::('d'::(' '::('l'::('o'::('g'::(' '::('s'::('i'::('z'::('e'::(':'::[]))))))))))))) :: (
      (nat2string (length old_state.log)) :: ((','::[]) :: (('n'::('e'::('w'::(' '::('l'::('o'::('g'::(' '::('s'::('i'::('z'::('e'::(':'::[]))))))))))))) :: (
      (nat2string (length new_state.log)) :: ((','::[]) :: (('p'::('r'::('i'::('n'::('t'::(' '::('n'::('e'::('w'::(' '::('l'::('o'::('g'::(':'::[])))))))))))))) :: (
      (print_log pbft_context new_state.log) :: []))))))))))))))
  in
  (send_debug pbft_context slf str) :: []

(** val pBFThandle_checkpoint :
    pBFTcontext -> pBFTauth -> rep -> (pBFTstate, checkpoint, directedMsgs) update **)

let pBFThandle_checkpoint pbft_context pbft_auth slf state c =
  let keys = state.local_keys in
  let lwm = low_water_mark pbft_context state in
  let view0 = state.current_view in
  let lr = state.last_reply_state in
  let sender = checkpoint2sender pbft_context c in
  let csn = checkpoint2seq pbft_context c in
  let cvn = checkpoint2view pbft_context c in
  if pbft_context.rep_deq slf sender
  then ((Some state), [])
  else if verify_checkpoint pbft_context pbft_auth slf keys c
       then if check_between_water_marks pbft_context lwm csn
            then if viewLe cvn view0
                 then let (entryop, new_cp_state) =
                        add_new_checkpoint2cp_state pbft_context state.cp_state
                          state.sm_state0 lr c
                      in
                      let new_state =
                        update_checkpoint_state pbft_context state new_cp_state
                      in
                      (match check_stable pbft_context slf new_state entryop with
                       | Some new_state' ->
                         ((Some new_state'),
                           (debug_checkpoint pbft_context slf state new_state'))
                       | None -> ((Some new_state), []))
                 else ((Some state), [])
            else ((Some state), [])
       else ((Some state), [])

(** val checkpoint_certificate_of_last_stable_checkpoint :
    pBFTcontext -> pBFTstate -> checkpoint list **)

let checkpoint_certificate_of_last_stable_checkpoint _ state =
  state.cp_state.chk_state_stable.cp_checkpoint

(** val stable_chkpt_of_last_stable_checkpoint :
    pBFTcontext -> pBFTstate -> stableChkPt **)

let stable_chkpt_of_last_stable_checkpoint _ state =
  let entry = state.cp_state.chk_state_stable in
  { si_state = entry.cp_sm_state; si_lastr = entry.cp_last_reply_state }

(** val request_data2pre_prepare :
    pBFTcontext -> requestData -> request list -> tokens -> pre_prepare **)

let request_data2pre_prepare _ rd reqs a =
  let Request_data (v, s, _) = rd in
  Pre_prepare ((Bare_pre_prepare (v, s, reqs)), a)

(** val entry2prepared_info : pBFTcontext -> pBFTlogEntry -> preparedInfo option **)

let entry2prepared_info pbft_context entry =
  let { log_entry_request_data = rd; log_entry_pre_prepare_info =
    log_entry_pre_prepare_info0; log_entry_prepares = preps; log_entry_commits =
    _ } = entry
  in
  (match log_entry_pre_prepare_info0 with
   | Pp_info_pre_prep (a, reqs) ->
     if (<=) (mul (Pervasives.succ (Pervasives.succ 0)) pbft_context.f)
          (length preps)
     then Some { prepared_info_pre_prepare =
            (request_data2pre_prepare pbft_context rd (map fst reqs) a);
            prepared_info_digest = (request_data2digest pbft_context rd);
            prepared_info_prepares =
            (map (request_data_and_rep_toks2prepare pbft_context rd) preps) }
     else None
   | Pp_info_no_pre_prep -> None)

(** val gather_prepared_messages :
    pBFTcontext -> pBFTlog -> seqNum -> preparedInfo list **)

let rec gather_prepared_messages pbft_context l sn =
  match l with
  | [] -> []
  | entry :: entries ->
    if Nat.ltb (seqnum2nat sn) (seqnum2nat (entry2seq pbft_context entry))
    then (match entry2prepared_info pbft_context entry with
          | Some nfo -> nfo :: (gather_prepared_messages pbft_context entries sn)
          | None -> gather_prepared_messages pbft_context entries sn)
    else gather_prepared_messages pbft_context entries sn

(** val find_pre_prepare_certificate_in_prepared_infos :
    pBFTcontext -> (preparedInfo -> bool) -> seqNum -> preparedInfo list ->
    preparedInfo option **)

let rec find_pre_prepare_certificate_in_prepared_infos pbft_context f1 sn = function
| [] -> None
| ppinfo :: preps0 ->
  if seqNumDeq sn (prepared_info2seq pbft_context ppinfo)
  then if f1 ppinfo
       then Some ppinfo
       else find_pre_prepare_certificate_in_prepared_infos pbft_context f1 sn
              preps0
  else find_pre_prepare_certificate_in_prepared_infos pbft_context f1 sn preps0

(** val create_new_prepare_message :
    pBFTcontext -> pBFTauth -> pBFThash -> seqNum -> view -> local_key_map ->
    preparedInfo list -> bool * (pre_prepare * pBFTdigest) **)

let create_new_prepare_message pbft_context pbft_auth pbft_hash sn nview keys p =
  let f1 = valid_prepared_info pbft_context pbft_hash p in
  (match find_pre_prepare_certificate_in_prepared_infos pbft_context f1 sn p with
   | Some prepared_info ->
     let reqs = prepared_info2requests pbft_context prepared_info in
     let digest0 = prepared_info2digest pbft_context prepared_info in
     let pp = mk_auth_pre_prepare pbft_context pbft_auth nview sn reqs keys in
     (true, (pp, digest0))
   | None ->
     let nreq = mk_auth_null_req pbft_context pbft_auth keys in
     let digest0 = requests2digest pbft_context pbft_hash (nreq :: []) in
     let pp = mk_auth_pre_prepare pbft_context pbft_auth nview sn (nreq :: []) keys
     in
     (false, (pp, digest0)))

(** val create_new_prepare_messages :
    pBFTcontext -> pBFTauth -> pBFThash -> seqNum list -> view -> local_key_map ->
    preparedInfo list -> (pre_prepare * pBFTdigest)
    list * (pre_prepare * pBFTdigest) list **)

let rec create_new_prepare_messages pbft_context pbft_auth pbft_hash l nview keys p =
  match l with
  | [] -> ([], [])
  | s :: ss ->
    let (b, p0) =
      create_new_prepare_message pbft_context pbft_auth pbft_hash s nview keys p
    in
    let (oP, nP) =
      create_new_prepare_messages pbft_context pbft_auth pbft_hash ss nview keys p
    in
    if b then ((p0 :: oP), nP) else (oP, (p0 :: nP))

(** val valid_view : view -> view -> bool **)

let valid_view vc_view cur_view =
  (<=) (view2nat cur_view) (view2nat vc_view)

(** val gather_valid_prepared_messages :
    pBFTcontext -> pBFThash -> pBFTlog -> seqNum -> preparedInfo list **)

let gather_valid_prepared_messages pbft_context pbft_hash l sn =
  let ps = gather_prepared_messages pbft_context l sn in
  filter (valid_prepared_info pbft_context pbft_hash ps) ps

(** val mk_current_view_change :
    pBFTcontext -> pBFTauth -> pBFThash -> rep -> view -> pBFTstate -> viewChange **)

let mk_current_view_change pbft_context pbft_auth pbft_hash i v state =
  let keys = state.local_keys in
  let sn = low_water_mark pbft_context state in
  let c = checkpoint_certificate_of_last_stable_checkpoint pbft_context state in
  let p = gather_valid_prepared_messages pbft_context pbft_hash state.log sn in
  let stchk = stable_chkpt_of_last_stable_checkpoint pbft_context state in
  mk_auth_view_change pbft_context pbft_auth v sn stchk c p i keys

(** val refresh_view_change :
    pBFTcontext -> pBFTauth -> pBFThash -> viewChange -> pBFTstate -> viewChange **)

let refresh_view_change pbft_context pbft_auth pbft_hash vc state =
  let i = view_change2sender pbft_context vc in
  let v = view_change2view pbft_context vc in
  mk_current_view_change pbft_context pbft_auth pbft_hash i v state

(** val replace_own_view_change_in_entry :
    pBFTcontext -> viewChange -> pBFTviewChangeEntry -> pBFTviewChangeEntry **)

let replace_own_view_change_in_entry _ vc e =
  let { vce_view = v; vce_view_change = _; vce_view_changes = vcs; vce_new_view =
    nv } = e
  in
  { vce_view = v; vce_view_change = (Some vc); vce_view_changes = vcs;
  vce_new_view = nv }

(** val view_changed_entry :
    pBFTcontext -> pBFTauth -> pBFThash -> pBFTstate -> pBFTviewChangeEntry ->
    (viewChange * pBFTviewChangeEntry) option **)

let view_changed_entry pbft_context pbft_auth pbft_hash state entry =
  let current_view0 = state.current_view in
  let entry_view = entry.vce_view in
  if viewLe current_view0 entry_view
  then if viewLt initial_view entry_view
       then (match entry.vce_view_change with
             | Some vc ->
               if is_some entry.vce_new_view
               then None
               else if (<=)
                         (mul (Pervasives.succ (Pervasives.succ 0)) pbft_context.f)
                         (length entry.vce_view_changes)
                    then if norepeatsb pbft_context.rep_deq
                              (map (view_change2sender pbft_context)
                                (view_change_entry2view_changes pbft_context entry))
                         then let vc' =
                                refresh_view_change pbft_context pbft_auth
                                  pbft_hash vc state
                              in
                              let entry' =
                                replace_own_view_change_in_entry pbft_context vc'
                                  entry
                              in
                              if forallb
                                   (correct_view_change pbft_context pbft_hash
                                     entry_view)
                                   (view_change_entry2view_changes pbft_context
                                     entry')
                              then Some (vc', entry')
                              else None
                         else None
                    else None
             | None -> None)
       else None
  else None

(** val check_broadcast_new_view :
    pBFTcontext -> pBFTauth -> pBFThash -> rep -> pBFTstate -> pBFTviewChangeEntry
    -> (((newView * pBFTviewChangeEntry) * (pre_prepare * pBFTdigest)
    list) * (pre_prepare * pBFTdigest) list) option **)

let check_broadcast_new_view pbft_context pbft_auth pbft_hash slf state entry =
  let view0 = entry.vce_view in
  let keys = state.local_keys in
  if is_primary pbft_context view0 slf
  then (match view_changed_entry pbft_context pbft_auth pbft_hash state entry with
        | Some p ->
          let (vc', entry') = p in
          let l = from_min_to_max_of_view_changes pbft_context pbft_hash entry' in
          let v = view_change_entry2view_changes pbft_context entry' in
          let p0 = view_change_cert2prep pbft_context v in
          let nview = view_change2view pbft_context vc' in
          let (oP, nP) =
            create_new_prepare_messages pbft_context pbft_auth pbft_hash l nview
              keys p0
          in
          let nv =
            mk_auth_new_view pbft_context pbft_auth nview v (map fst oP)
              (map fst nP) keys
          in
          Some (((nv, entry'), oP), nP)
        | None -> None)
  else None

(** val select : int -> 'a1 list -> 'a1 option **)

let rec select n = function
| [] -> None
| x :: xs ->
  ((fun fO fS n -> if n=0 then fO () else fS (n-1))
     (fun _ -> Some
     x)
     (fun m ->
     select m xs)
     n)

(** val checkBCastNewView2entry :
    pBFTcontext -> checkBCastNewView -> pBFTviewChangeState -> pBFTviewChangeEntry
    option **)

let checkBCastNewView2entry _ c s =
  select c s

(** val max_O : pBFTcontext -> (pre_prepare * pBFTdigest) list -> seqNum **)

let rec max_O pbft_context = function
| [] -> 0
| p0 :: ps ->
  let (p, _) = p0 in
  max_seq_num (pre_prepare2seq pbft_context p) (max_O pbft_context ps)

(** val extract_seq_and_digest_from_checkpoint_certificate :
    pBFTcontext -> checkpointCert -> (seqNum * pBFTdigest) option **)

let extract_seq_and_digest_from_checkpoint_certificate pbft_context = function
| [] -> None
| c0 :: _ ->
  Some ((checkpoint2seq pbft_context c0), (checkpoint2digest pbft_context c0))

(** val contains_our_own_checkpoint_message :
    pBFTcontext -> rep -> checkpointCert -> bool **)

let rec contains_our_own_checkpoint_message pbft_context slf = function
| [] -> false
| c0 :: cs ->
  if pbft_context.rep_deq (checkpoint2sender pbft_context c0) slf
  then true
  else contains_our_own_checkpoint_message pbft_context slf cs

(** val log_checkpoint_cert_from_new_view :
    pBFTcontext -> pBFTauth -> pBFThash -> rep -> pBFTstate -> view -> seqNum ->
    checkpointCert -> stableChkPt -> pBFTstate * checkpoint option **)

let log_checkpoint_cert_from_new_view pbft_context pbft_auth pbft_hash slf state v maxV c s =
  match extract_seq_and_digest_from_checkpoint_certificate pbft_context c with
  | Some p ->
    let (sn, digest0) = p in
    let keys = state.local_keys in
    let smst = s.si_state in
    let lastr = s.si_lastr in
    if contains_our_own_checkpoint_message pbft_context slf c
    then let entry = { cp_sn = sn; cp_d = digest0; cp_checkpoint = c; cp_sm_state =
           smst; cp_last_reply_state = lastr }
         in
         ((update_log_checkpoint_stable pbft_context state entry), None)
    else let digest1 = pbft_hash.create_hash_state_last_reply smst lastr in
         let cp = mk_auth_checkpoint pbft_context pbft_auth v maxV digest1 slf keys
         in
         let entry = { cp_sn = sn; cp_d = digest1; cp_checkpoint = (cp :: c);
           cp_sm_state = smst; cp_last_reply_state = lastr }
         in
         ((update_log_checkpoint_stable pbft_context state entry), (Some cp))
  | None -> (state, None)

(** val update_checkpoint_from_new_view :
    pBFTcontext -> pBFTstate -> stableChkPt -> seqNum -> pBFTstate **)

let update_checkpoint_from_new_view pbft_context state s maxV =
  if (<=) (seqnum2nat state.next_to_execute) (seqnum2nat maxV)
  then let new_state1 = change_last_reply_state pbft_context state s.si_lastr in
       let new_state2 = change_sm_state pbft_context new_state1 s.si_state in
       change_next_to_execute pbft_context new_state2 (next_seq maxV)
  else state

(** val broadcast_checkpoint_op :
    pBFTcontext -> rep -> checkpoint option -> directedMsgs **)

let broadcast_checkpoint_op pbft_context slf = function
| Some c ->
  (broadcast2others pbft_context slf (send_checkpoint pbft_context c)) :: []
| None -> []

(** val update_state_new_view :
    pBFTcontext -> pBFTauth -> pBFThash -> rep -> pBFTstate -> newView ->
    pBFTstate * directedMsgs **)

let update_state_new_view pbft_context pbft_auth pbft_hash slf state nv =
  let sn = low_water_mark pbft_context state in
  let v = new_view2cert pbft_context nv in
  (match view_change_cert2max_seq_vc pbft_context v with
   | Some p ->
     let (maxV, vc) = p in
     if Nat.ltb (seqnum2nat sn) (seqnum2nat maxV)
     then let c = view_change2cert pbft_context vc in
          let s = view_change2stable pbft_context vc in
          let v0 = view_change2view pbft_context vc in
          let (new_state1, cpop) =
            log_checkpoint_cert_from_new_view pbft_context pbft_auth pbft_hash slf
              state v0 maxV c s
          in
          let new_log = clear_log_checkpoint pbft_context new_state1.log maxV in
          let new_state2 = update_log pbft_context new_state1 new_log in
          let new_state3 = trim_checkpoint pbft_context new_state2 maxV in
          let new_state4 =
            update_checkpoint_from_new_view pbft_context new_state3 s maxV
          in
          let out = broadcast_checkpoint_op pbft_context slf cpop in
          (new_state4, out)
     else (state, [])
   | None -> (state, []))

(** val pBFThandle_check_bcast_new_view :
    pBFTcontext -> pBFTauth -> pBFThash -> rep -> (pBFTstate, checkBCastNewView,
    directedMsgs) update **)

let pBFThandle_check_bcast_new_view pbft_context pbft_auth pbft_hash slf state c =
  match checkBCastNewView2entry pbft_context c state.view_change_state with
  | Some entry ->
    (match check_broadcast_new_view pbft_context pbft_auth pbft_hash slf state
             entry with
     | Some p ->
       let (p0, npreps) = p in
       let (p1, opreps) = p0 in
       let (nv, entry') = p1 in
       let new_state2 = log_new_view_and_entry_state pbft_context state nv entry'
       in
       let new_state3 =
         log_pre_prepares_of_new_view pbft_context new_state2 (app opreps npreps)
       in
       let new_state4 =
         change_sequence_number pbft_context new_state3 (max_O pbft_context opreps)
       in
       let new_state5 =
         update_view pbft_context new_state4 (new_view2view pbft_context nv)
       in
       let (new_state6, chks) =
         update_state_new_view pbft_context pbft_auth pbft_hash slf new_state5 nv
       in
       let nviews =
         (broadcast2others pbft_context slf (send_new_view pbft_context nv)) :: []
       in
       ((Some new_state6), (app nviews chks))
     | None -> ((Some state), []))
  | None -> ((Some state), [])

(** val pBFThandle_expired_timer :
    pBFTcontext -> pBFTauth -> pBFThash -> rep -> (pBFTstate, expiredTimer,
    directedMsgs) update **)

let pBFThandle_expired_timer pbft_context pbft_auth pbft_hash slf state t =
  let view0 = state.current_view in
  if viewDeq view0 (expired_timer2view pbft_context t)
  then let nview = next_view view0 in
       let vc =
         mk_current_view_change pbft_context pbft_auth pbft_hash slf nview state
       in
       let (p, new_vc_state) =
         start_view_change pbft_context vc state.view_change_state
       in
       let (_, changed_entry_pos) = p in
       let new_state =
         increment_view pbft_context
           (change_view_change_state pbft_context state new_vc_state)
       in
       let check =
         send_check_bcast_new_view pbft_context changed_entry_pos
           ((Obj.magic (PBFTreplica slf)) :: [])
       in
       let vcs =
         (broadcast2others pbft_context slf (send_view_change pbft_context vc)) :: []
       in
       ((Some new_state), (check :: vcs))
  else ((Some state), [])

(** val pBFThandle_view_change :
    pBFTcontext -> pBFTauth -> pBFThash -> rep -> (pBFTstate, viewChange,
    directedMsgs) update **)

let pBFThandle_view_change pbft_context pbft_auth pbft_hash slf state vc =
  let keys = state.local_keys in
  let view0 = state.current_view in
  let sender = view_change2sender pbft_context vc in
  let vc_view = view_change2view pbft_context vc in
  if pbft_context.rep_deq sender slf
  then ((Some state), [])
  else if verify_view_change pbft_context pbft_auth slf keys vc
       then if valid_view vc_view view0
            then if correct_view_change pbft_context pbft_hash vc_view vc
                 then (match add_other_view_change pbft_context vc
                               state.view_change_state with
                       | Some p ->
                         let (p0, new_vc_state) = p in
                         let (_, modified_entry_pos) = p0 in
                         let new_state =
                           change_view_change_state pbft_context state new_vc_state
                         in
                         let check =
                           send_check_bcast_new_view pbft_context
                             modified_entry_pos
                             ((Obj.magic (PBFTreplica slf)) :: [])
                         in
                         ((Some new_state), (check :: []))
                       | None -> ((Some state), []))
                 else ((Some state), [])
            else ((Some state), [])
       else ((Some state), [])

(** val add_digest :
    pBFTcontext -> pBFThash -> pre_prepare -> pre_prepare * pBFTdigest **)

let add_digest pbft_context pbft_hash p =
  (p, (pre_prepare2digest pbft_context pbft_hash p))

(** val add_prepare_to_log_from_new_view_pre_prepare :
    pBFTcontext -> pBFTauth -> rep -> pBFTstate -> (pre_prepare * pBFTdigest) ->
    pBFTstate * directedMsgs **)

let add_prepare_to_log_from_new_view_pre_prepare pbft_context pbft_auth slf state = function
| (pp, digest0) ->
  let view0 = state.current_view in
  let keys = state.local_keys in
  let sn = low_water_mark pbft_context state in
  let ppsn = pre_prepare2seq pbft_context pp in
  if Nat.ltb (seqnum2nat sn) (seqnum2nat ppsn)
  then let fp = fun _ ->
         pre_prepare2rep_toks_of_prepare pbft_context pbft_auth slf keys pp digest0
       in
       let fc = fun _ ->
         pre_prepare2rep_toks_of_commit pbft_context pbft_auth slf keys pp digest0
       in
       let (entryop, new_log) =
         add_new_pre_prepare_and_prepare2log pbft_context slf state.log pp digest0
           fp fc
       in
       let new_state = update_log pbft_context state new_log in
       let rd = pre_prepare2request_data pbft_context pp digest0 in
       let preps = check_broadcast_prepare pbft_context slf rd entryop in
       let comms = check_broadcast_commit pbft_context slf rd entryop in
       let (reps0, new_state') =
         check_send_replies pbft_context slf view0 keys entryop new_state ppsn
       in
       (new_state', (app preps (app comms reps0)))
  else (state, [])

(** val add_prepares_to_log_from_new_view_pre_prepares :
    pBFTcontext -> pBFTauth -> rep -> pBFTstate -> (pre_prepare * pBFTdigest) list
    -> pBFTstate * directedMsgs **)

let rec add_prepares_to_log_from_new_view_pre_prepares pbft_context pbft_auth slf state = function
| [] -> (state, [])
| ppd :: ppds ->
  let (new_state1, out1) =
    add_prepare_to_log_from_new_view_pre_prepare pbft_context pbft_auth slf state
      ppd
  in
  let (new_state2, out2) =
    add_prepares_to_log_from_new_view_pre_prepares pbft_context pbft_auth slf
      new_state1 ppds
  in
  (new_state2, (app out1 out2))

(** val trim_message_with_low_water_mark : pBFTcontext -> seqNum -> msg0 -> bool **)

let trim_message_with_low_water_mark pbft_context lwm m =
  match Obj.magic m with
  | PBFTprepare p ->
    Nat.ltb (seqnum2nat lwm) (seqnum2nat (prepare2seq pbft_context p))
  | PBFTcommit c ->
    Nat.ltb (seqnum2nat lwm) (seqnum2nat (commit2seq pbft_context c))
  | _ -> true

(** val trim_output_with_low_water_mark :
    pBFTcontext -> seqNum -> directedMsg -> bool **)

let trim_output_with_low_water_mark pbft_context lwm m =
  trim_message_with_low_water_mark pbft_context lwm m.dmMsg

(** val trim_outputs_with_low_water_mark :
    pBFTcontext -> directedMsgs -> pBFTstate -> directedMsgs **)

let trim_outputs_with_low_water_mark pbft_context msgs s =
  filter
    (trim_output_with_low_water_mark pbft_context (low_water_mark pbft_context s))
    msgs

(** val pBFThandle_new_view :
    pBFTcontext -> pBFTauth -> pBFThash -> rep -> (pBFTstate, newView,
    directedMsgs) update **)

let pBFThandle_new_view pbft_context pbft_auth pbft_hash slf state nv =
  let keys = state.local_keys in
  let cview = state.current_view in
  let nvview = new_view2view pbft_context nv in
  let sender = new_view2sender pbft_context nv in
  let oP = new_view2oprep pbft_context nv in
  let nP = new_view2nprep pbft_context nv in
  if pbft_context.rep_deq sender slf
  then ((Some state), [])
  else if verify_new_view pbft_context pbft_auth slf keys nv
       then if viewLt initial_view nvview
            then if viewLe cview nvview
                 then if correct_new_view pbft_context pbft_hash nv
                      then if has_new_view pbft_context pbft_hash
                                state.view_change_state nvview
                           then ((Some state), [])
                           else let new_state1 =
                                  update_view pbft_context state nvview
                                in
                                let pre_preps =
                                  map (fun p ->
                                    add_digest pbft_context pbft_hash p)
                                    (app oP nP)
                                in
                                let (new_state2, out) =
                                  add_prepares_to_log_from_new_view_pre_prepares
                                    pbft_context pbft_auth slf new_state1 pre_preps
                                in
                                let new_state3 =
                                  log_new_view_state pbft_context new_state2 nv
                                in
                                let (new_state4, chks) =
                                  update_state_new_view pbft_context pbft_auth
                                    pbft_hash slf new_state3 nv
                                in
                                let out2 =
                                  app
                                    (trim_outputs_with_low_water_mark pbft_context
                                      out new_state4) chks
                                in
                                ((Some new_state4), out2)
                      else ((Some state), [])
                 else ((Some state), [])
            else ((Some state), [])
       else ((Some state), [])

(** val pBFThandle_start_timer :
    pBFTcontext -> rep -> (pBFTstate, startTimer, directedMsgs) update **)

let pBFThandle_start_timer pbft_context slf state t =
  let t0 = start_timer2expired_timer pbft_context t in
  ((Some state),
  ((send_expired_timer pbft_context t0 ((Obj.magic (PBFTreplica slf)) :: [])) :: []))

(** val pBFThandle_reply :
    pBFTcontext -> rep -> (pBFTstate, reply, directedMsgs) update **)

let pBFThandle_reply _ _ state _ =
  ((Some state), [])

(** val pBFThandle_debug :
    pBFTcontext -> rep -> (pBFTstate, debug, directedMsgs) update **)

let pBFThandle_debug _ _ state _ =
  ((Some state), [])

(** val pBFThandle_check_ready :
    pBFTcontext -> pBFTauth -> pBFThash -> rep -> pBFTstate -> pBFTstate
    option * directedMsgs **)

let pBFThandle_check_ready pbft_context pbft_auth pbft_hash slf state =
  let keys = state.local_keys in
  let view0 = state.current_view in
  let (outs, new_state) =
    find_and_execute_requests pbft_context pbft_auth pbft_hash slf view0 keys state
  in
  let decr_state =
    decrement_requests_in_progress_if_primary pbft_context slf view0 new_state
  in
  ((Some decr_state), outs)

(** val pBFTreplica_update :
    pBFTcontext -> pBFTauth -> pBFThash -> rep -> pBFTstate mUpdate **)

let pBFTreplica_update pbft_context pbft_auth pbft_hash slf state m =
  match Obj.magic m with
  | PBFTrequest r ->
    pBFThandle_request pbft_context pbft_auth pbft_hash slf state r
  | PBFTpre_prepare p ->
    pBFThandle_pre_prepare pbft_context pbft_auth pbft_hash slf state p
  | PBFTprepare p -> pBFThandle_prepare pbft_context pbft_auth slf state p
  | PBFTcommit c -> pBFThandle_commit pbft_context pbft_auth slf state c
  | PBFTreply r -> pBFThandle_reply pbft_context slf state r
  | PBFTcheckpoint c -> pBFThandle_checkpoint pbft_context pbft_auth slf state c
  | PBFTcheck_ready ->
    pBFThandle_check_ready pbft_context pbft_auth pbft_hash slf state
  | PBFTcheck_bcast_new_view c ->
    pBFThandle_check_bcast_new_view pbft_context pbft_auth pbft_hash slf state c
  | PBFTstart_timer t -> pBFThandle_start_timer pbft_context slf state t
  | PBFTexpired_timer t ->
    pBFThandle_expired_timer pbft_context pbft_auth pbft_hash slf state t
  | PBFTview_change v ->
    pBFThandle_view_change pbft_context pbft_auth pbft_hash slf state v
  | PBFTnew_view v ->
    pBFThandle_new_view pbft_context pbft_auth pbft_hash slf state v
  | PBFTdebug d -> pBFThandle_debug pbft_context slf state d

(** val pBFTreplicaSM :
    pBFTcontext -> pBFTauth -> pBFTkeys -> pBFThash -> rep -> pBFTstate
    mStateMachine **)

let pBFTreplicaSM pbft_context pbft_auth pbft_keys pbft_hash slf =
  mkSM (pBFTreplica_update pbft_context pbft_auth pbft_hash slf)
    (initial_state pbft_context pbft_keys pbft_hash slf)

type digest = int list

(** val digest_deq : digest deq **)

let digest_deq x y =
  list_eq_dec (=) x y

(** val f0 : int **)

let f0 =
  Pervasives.succ 0

(** val nreps : int **)

let nreps =
  add (mul (Pervasives.succ (Pervasives.succ (Pervasives.succ 0))) f0)
    (Pervasives.succ 0)

type replica = nat_n

(** val replica_deq : int -> replica deq **)

let replica_deq _ =
  nat_n_deq nreps

(** val reps2nat0 : int -> replica -> nat_n **)

let reps2nat0 _ n =
  n

(** val bijective_reps2nat : int -> (replica, nat_n) bijective **)

let bijective_reps2nat _ n =
  n

type client0 = unit

(** val client1 : client0 **)

let client1 =
  ()

(** val natn1 : nat_n **)

let natn1 =
  0

(** val clients2nat0 : client0 -> nat_n **)

let clients2nat0 _ =
  natn1

(** val bijective_clients2nat : (client0, nat_n) bijective **)

let bijective_clients2nat _ =
  client1

type operation =
| Opr_add of int
| Opr_sub of int

(** val operation_deq : operation deq **)

let operation_deq x y =
  match x with
  | Opr_add n ->
    (match y with
     | Opr_add m -> (=) n m
     | Opr_sub _ -> false)
  | Opr_sub n ->
    (match y with
     | Opr_add _ -> false
     | Opr_sub m -> (=) n m)

type smState = int

type result = int

(** val operation_upd : client0 -> smState -> operation -> result * smState **)

let operation_upd _ state = function
| Opr_add m -> let k = add state m in (k, k)
| Opr_sub m -> let k = sub state m in (k, k)

(** val pBFT_I_context : pBFTcontext **)

let pBFT_I_context =
  { pBFTmax_in_progress = (Pervasives.succ (Pervasives.succ (Pervasives.succ
    (Pervasives.succ (Pervasives.succ (Pervasives.succ (Pervasives.succ
    (Pervasives.succ (Pervasives.succ (Pervasives.succ 0))))))))));
    pBFTwater_mark_range = (Pervasives.succ (Pervasives.succ (Pervasives.succ
    (Pervasives.succ (Pervasives.succ (Pervasives.succ (Pervasives.succ
    (Pervasives.succ (Pervasives.succ (Pervasives.succ (Pervasives.succ
    (Pervasives.succ (Pervasives.succ (Pervasives.succ (Pervasives.succ
    (Pervasives.succ (Pervasives.succ (Pervasives.succ (Pervasives.succ
    (Pervasives.succ (Pervasives.succ (Pervasives.succ (Pervasives.succ
    (Pervasives.succ (Pervasives.succ (Pervasives.succ (Pervasives.succ
    (Pervasives.succ (Pervasives.succ (Pervasives.succ (Pervasives.succ
    (Pervasives.succ (Pervasives.succ (Pervasives.succ (Pervasives.succ
    (Pervasives.succ (Pervasives.succ (Pervasives.succ (Pervasives.succ
    (Pervasives.succ 0))))))))))))))))))))))))))))))))))))))));
    pBFTcheckpoint_period = (Pervasives.succ (Pervasives.succ 0)); pBFTdigestdeq =
    (Obj.magic digest_deq); f = f0; rep_deq =
    (Obj.magic replica_deq (Pervasives.succ 0)); reps2nat =
    (Obj.magic reps2nat0 (Pervasives.succ 0)); reps_bij =
    (Obj.magic bijective_reps2nat (Pervasives.succ 0)); num_clients =
    (Pervasives.succ 0); client_deq = (Obj.magic deq_unit); clients2nat =
    (Obj.magic clients2nat0); clients_bij = (Obj.magic bijective_clients2nat);
    pBFTopdeq = (Obj.magic operation_deq); pBFTresdeq = (Obj.magic (=));
    pBFTsm_initial_state = (Obj.magic 0); pBFTsm_update =
    (Obj.magic operation_upd) }

(** val pBFT_I_auth : pBFTauth **)

let pBFT_I_auth =
  { pBFTcreate = (fun _ _ -> Obj.magic []); pBFTverify = (fun _ _ _ -> true) }

(** val reps_local_key_map : local_key_map **)

let reps_local_key_map =
  map (fun m -> { dk_dst = (Obj.magic (PBFTreplica m)); dk_key = (Obj.magic []) })
    (reps pBFT_I_context)

(** val pBFT_I_keys : pBFTkeys **)

let pBFT_I_keys _ =
  { dk_dst = (Obj.magic (PBFTclient (Obj.magic client1))); dk_key =
    (Obj.magic []) } :: reps_local_key_map

(** val pBFT_I_hash : pBFThash **)

let pBFT_I_hash =
  { create_hash_messages = (fun _ -> Obj.magic []); verify_hash_messages =
    (fun _ _ -> true); create_hash_state_last_reply = (fun _ _ -> Obj.magic []);
    verify_hash_state_last_reply = (fun _ _ _ -> true) }

(** val local_replica : rep -> pBFTstate mStateMachine **)

let local_replica =
  pBFTreplicaSM pBFT_I_context pBFT_I_auth pBFT_I_keys pBFT_I_hash
